from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from RPA.Outlook.Application import Application
from datetime import datetime, timedelta
import pandas as pd
import time
import pyperclip

def getEBridgeCreds():
    path = r"D:\Users\jason.kristanto\Desktop\PROJECTS\FinanceRPA\compareDataFP-Ebridge\EBridgeCredentials.xlsx"
    df = pd.read_excel(path)
    return df

def get_first_date_of_last_month():
    today = datetime.today()
    # Subtracting the current day of the month to get to the first day of the current month
    first_day_of_current_month = today.replace(day=1)
    # Subtracting one day from the first day of the current month to get the last day of the previous month
    last_day_of_previous_month = first_day_of_current_month - timedelta(days=1)
    # Replacing the day to the first day of the previous month
    first_day_of_previous_month = last_day_of_previous_month.replace(day=1)
    return first_day_of_previous_month.strftime('%d/%m/%Y')

def downloadDataEBridge():
    credentialsdf = getEBridgeCreds()

    edge_options = Options()
    edge_options.add_experimental_option('detach', True)    #keep browser open after program ends
    website = 'https://tweb.toyota.co.id/E-FAKTUR/Login'

    mainlist = []
    
    for index, row in credentialsdf.iterrows():
        driver = webdriver.Edge(options=edge_options)
        # actions = ActionChains(driver)
        wait = WebDriverWait(driver, 60)
        driver.get(website)

        customer = row['Username'].split('.')[0]
        print('\nCurrent customer:', customer)

        #enter username
        usernametextbox = wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="UserName"]')))
        usernametextbox.send_keys(row['Username'])

        #enter password
        passwordtextbox = driver.find_element(By.XPATH, '//*[@id="Password"]')
        passwordtextbox.send_keys(row['Password'])

        #maximize window
        driver.maximize_window()

        #click login
        loginbutton = driver.find_element(By.XPATH, '//*[@id="LoginBtn"]') 
        loginbutton.click()

        #click VAT IN
        vatin = wait.until(EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div[1]/div[2]/ul/li[1]/a")))
        vatin.click()

        #click tax invoice
        taxinvoice = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/div[2]/ul/li[1]/ul/li[3]/a')))
        taxinvoice.click()

        time.sleep(10)

        #insert tax invoice data from
        insertfromdate = False
        while not insertfromdate:
            try:
                fromtextbox = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[1]/div[1]/div/div[3]/div/input')))
                time.sleep(1)
                fromtextbox.click()
                time.sleep(1)
                fromtextbox.send_keys(get_first_date_of_last_month())
                time.sleep(1)
                break
            except:
                continue
        

        #insert tax invoice data to
        totextbox = driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[1]/div[1]/div/div[5]/div/input')
        time.sleep(1)
        totextbox.click()
        time.sleep(1)
        totextbox.send_keys(datetime.now().strftime('%d/%m/%Y'))
        time.sleep(1)

        #click search
        searchbutton = driver.find_element(By.XPATH, '//*[@id="SearchForm"]/div[5]/div[2]/input')
        searchbutton.click()
        time.sleep(2)

        rows = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[1]')))
        time.sleep(2)
        rows = driver.find_elements(By.XPATH, '/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr')
        driver.execute_script("window.scrollTo(0, 1000);")
        time.sleep(1)

        for i in range(len(rows)):
            taxinvoiceno = driver.find_element(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[{i + 1}]/td[1]').text
            suppliercode = driver.find_element(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[{i + 1}]/td[3]').text
            supplierinvoiceno = driver.find_element(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[{i + 1}]/td[4]').text
            templist = [taxinvoiceno, suppliercode, supplierinvoiceno, customer]
            print(templist)
            mainlist.append(templist)
        
        driver.quit()

    maindf = pd.DataFrame(mainlist)
    maindf.columns = ['Tax Invoice No', 'Supplier Code', 'Supplier Invoice No', 'Customer']
    
    return maindf



def main():
    maindf = downloadDataEBridge()

