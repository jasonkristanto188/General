import os

def getUserInput(message):
    userinput = input(message)
    return userinput   

def clearCMD():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')