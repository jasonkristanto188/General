import os
import time
import shutil
import pandas as pd
from datetime import datetime
from RPA.Outlook.Application import Application

#0. Get Main Data; Can be used to get: No. DN, No. SJ
def get_hs_code():
    
    #path is fixed
    excelpath = r"D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\HS Code SP new 1.xlsx"

    df = pd.read_excel(excelpath)
    df.columns = df.iloc[0]
    df = df.iloc[1:]
    df.reset_index(drop=True, inplace=True)
    df = df[['Material', 'NEW HS CODE']]

    return df

def get_dn_sj_data():
    mainpath = rf'D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\{datetime.now().year}'
    deliverynotepath = None
    suratjalanpath = None

    directories = [d for d in os.listdir(mainpath) if os.path.isdir(os.path.join(mainpath, d))]
    for directory in directories:
        monthstr = directory.split('.')[0]

        if int(monthstr) == datetime.now().month:
            innerpath = os.path.join(mainpath, directory)
            innerdirectories = [d for d in os.listdir(innerpath) if os.path.isdir(os.path.join(innerpath, d))]
            innerdirectories.sort()
            latestdirectory = innerdirectories[-1]

            finalpath = os.path.join(innerpath, latestdirectory)
            files = os.listdir(finalpath)
            for file in files:
                if 'data ready delivery batam' in file.lower() and '.xlsx' in file and '~' not in file:
                    deliverynotepath = os.path.join(finalpath, file)
                elif 'ship' in file.lower() and 'batam' in file.lower() and '~' not in file and file.endswith('.xlsx'):
                    suratjalanpath = os.path.join(finalpath, file)
    
    return finalpath, deliverynotepath, suratjalanpath

def get_maindf():
    mainpath, deliverynotepath, suratjalanpath = get_dn_sj_data()
    print()
    print('main path:', mainpath)
    print('delivery note path:', deliverynotepath)
    print('surat jalan path:', suratjalanpath)
    print()

    maindf = pd.read_excel(deliverynotepath, sheet_name='DATA READY DELIVERY BATAM')
    maindf.columns = maindf.iloc[1]
    maindf = maindf.iloc[2:]
    maindf.reset_index(drop=True, inplace=True)
    print(maindf)

    sjdf = pd.read_excel(suratjalanpath)
    sjdf.columns = sjdf.iloc[0]
    sjdf = sjdf.iloc[2:, 1:]
    sjdf.reset_index(drop=True, inplace=True)

    hsdf = get_hs_code()

    for index, row, in maindf.iterrows():
        #update column no. SJ 
        maindf.loc[index, 'No. SJ'] = sjdf.loc[sjdf['Delivery'] == row['No. DN'], 'Shipment N'].values[0]

        #update hs code
        hscodelist = hsdf.loc[hsdf['Material'] == row['Part Number'], 'NEW HS CODE'].values
        if len(hscodelist) == 1:
            maindf.loc[index, 'HS CODE'] = hsdf.loc[hsdf['Material'] == row['Part Number'], 'NEW HS CODE'].values[0]
        else:
            print(f"ERROR inserting HS CODE at row: {index}, part number: {row['Part Number']}")
    print(maindf)

    temp_main_path = os.path.join(mainpath, f"DATA READY DELIVERY BATAM {datetime.now().strftime('%Y%m%d')}.xlsx")
    # maindf.to_excel(temp_main_path, index=False)
    return maindf, temp_main_path



#1. Get Delivery Numbers
def get_dn_list():
    maindf, mainpath = get_maindf()
    # print(maindf)
    dnlist = list(set(maindf['No. DN'].values.tolist()))
    
    return dnlist



#2. Get billing report data
def getOneDrivePath():  #used by report billing keyword in batam.robot
    mainpath = rf'D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\{datetime.now().year}'

    directories = [d for d in os.listdir(mainpath) if os.path.isdir(os.path.join(mainpath, d))]
    for directory in directories:
        monthstr = directory.split('.')[0]

        if int(monthstr) == datetime.now().month:
            innerpath = os.path.join(mainpath, directory)
            innerdirectories = [d for d in os.listdir(innerpath) if os.path.isdir(os.path.join(innerpath, d))]
            innerdirectories.sort()
            latestdirectory = innerdirectories[-1]

            return os.path.join(innerpath, latestdirectory)

    return ''

def wait_until_file_exists(path):
    while not os.path.isfile(path):
        time.sleep(1)

def check_file_exists(path):
    return True if os.path.isfile(path) else False

def get_report_billing_data(path):
    df = pd.read_excel(path)
    df.columns = df.iloc[4]
    df = df.iloc[5:, 3:-3]
    df.columns = df.columns.str.strip()
    # df = df[['Invoice No', 'Date', 'Customer', 'Material', 'Qty', 'Delivery No.']]

    df = df[df['Customer'] == 'PT AI - BATAM']
    df.reset_index(drop=True, inplace=True)

    return df

def update_main_again(reportbillingpath):
    reportbillingdf = get_report_billing_data(reportbillingpath)
    maindf, mainpath = get_maindf()

    print('\nReport billing:')
    print(reportbillingdf[['Delivery No.', 'Material', 'Invoice No', 'Net Sales']])

    print('\nMain data:')
    print(maindf[['No. DN', 'Part Number']])

    for index, row in maindf.iterrows():
        #update no invoice
        maindf.loc[index, 'No. Inv'] = reportbillingdf.loc[reportbillingdf['Delivery No.'] == row['No. DN'], 'Invoice No'].values[0]

        #update net value
        maindf.loc[index, 'Net value'] = reportbillingdf.loc[(reportbillingdf['Delivery No.'] == row['No. DN']) & (reportbillingdf['Material'] == row['Part Number']), 'Net Sales'].values[0]

    print(maindf)
    maindf.to_excel(mainpath, index=False)
    return mainpath



def get_sj_list(mainpath):
    maindf = pd.read_excel(mainpath)
    return list(set(maindf['No. SJ'].values.tolist()))



def get_invoice_per_sj(mainpath, sj):
    maindf = pd.read_excel(mainpath)
    return maindf['No. Inv'][maindf['No. SJ'] == sj].values.tolist()
   
def update_billing_doc_no(vf25path, mainpath, reportbillingpath):
    vf25df = pd.read_excel(vf25path, skiprows=9)
    vf25df = vf25df.drop(index=0)
    vf25df.reset_index(drop=True, inplace=True)
    vf25df = vf25df.rename(columns={'Bill. Doc..1': 'Invoice No.'})
    vf25df['Bill. Doc.'] = vf25df['Bill. Doc.'].apply(lambda x: int(x))
    vf25df['Invoice No.'] = vf25df['Invoice No.'].apply(lambda x: int(x))
    maindf = pd.read_excel(mainpath)

    for index, row in maindf.iterrows():
        maindf.loc[index, "Bill. Date"] = vf25df.loc[vf25df['Invoice No.'] == row['No. Inv'], 'Bill. Date'].values[0]
        maindf.loc[index, "NO. Inv List"] = vf25df.loc[vf25df['Invoice No.'] == row['No. Inv'], 'Bill. Doc.'].values[0]
    
    maindf['NO. Inv List'] = maindf['NO. Inv List'].apply (lambda x: int(x))
    print(maindf[['No. SJ', 'No. DN', 'Part Number', 'Qty', 'No. Inv', 'Net value', 'NO. Inv List', 'Bill. Date']])

    # maindf.to_excel(mainpath, index=False)

    
    
    #generate sum pivot
    sumdf = maindf.groupby(['No. SJ', 'NO. Inv List', 'Bill. Date'])['Net value'].sum().reset_index()
    print(sumdf)

    
    
    writer = pd.ExcelWriter(mainpath, engine='xlsxwriter')
    # writer = pd.ExcelWriter('final.xlsx', engine='xlsxwriter')
    maindf.to_excel(writer, sheet_name='Sheet1', index=False)
    sumdf.to_excel(writer, sheet_name='Sheet2', index=False)
    writer.close()

    return mainpath

def get_invoice_number(mainpath):
    maindf = pd.read_excel(mainpath)
    invoicelist = list(set(maindf['NO. Inv List'].values.tolist()))
    pdfpath = os.listdir(r'D:\13. PDF')

    for pdf in pdfpath:
        invoicenum = pdf.replace('.pdf', '')

        if invoicenum.isdigit():
            invoicenum = int(invoicenum)
            
        if invoicenum in invoicelist:
            invoicelist.remove(invoicenum)
    
    return invoicelist

def check_substring_exists(substr, str):
    return True if substr in str else False

def delete_pdfs():
    folderpath = r'D:\13. PDF'

    files = os.listdir(folderpath)
    for file in files:
        if '.pdf' in file:
            os.remove(os.path.join(folderpath, file))

def send_email(excel_attachment_path):
    #delete genpy folder first
    genpy_path = r"D:\Users\Mahmudin.M2\AppData\Local\Temp\gen_py"
    if os.path.isdir(genpy_path):
        shutil.rmtree(genpy_path)
    
    path = r"D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\List Email.xlsx"
    
    df = pd.read_excel(path)
    to_recipients = df['To'].values.tolist()
    cc_recipients = df['CC'].values.tolist()
    # to_recipients = 'mahmudin@Daihatsu.astra.co.id'
    # cc_recipients = 'adrianus.endo@Daihatsu.astra.co.id'

    currentdate = datetime.now().strftime('%d-%m-%Y')
    app = Application()
    app.open_application()

    bodymessage = '''
Dear Pak Kurniawan/pak Fajar & Team 
Berikut kami kirimkan softcopy invoice listnya (.zip), silahkan dapat digunakan untuk proses PPBJnya
Dan dapat dikirimkan no PPBJ nya ke team tax ADM

Dear Bpk Jonathan & Ibu Eka, 
Berikut ini saya kirimkan Data inv. List yang sudah kami buat (.xls), silahkan dilanjutkan prosesnya untuk pembuatan FP setelah no PPBJ dari team AI BATAM diterima
Terima kasih

Dear Pak Frenold/Pak Beni/Pak Arga
Berikut kami kirimkan softcopy invoice nya (.zip)
Mohon part nya dapat dikirimkan apabila FP dari team tax sudah diterima


Note : sesuai informasi sebelumnya, dimulai bulan feb 2024 untuk invoice sudah tidak dalam bentuk hardcopy lagi (approval + Stampel) dan akan digantikan dengan invoice softcopy generate by system

Demikian dari kami, terima kasih atas perhatian dan kerjasamanya
Terima kasih


Best Regard, 

Mahmudin 
PT. Astra Daihatsu Motor (HO)
Finance Div. | Billing & Insurance Dept. | 021-6510300 | Sunter - Jakarta Utara
'''

    zip_directory = r'D:\13. PDF'
    zipfiles = [os.path.join(zip_directory, f) for f in os.listdir(zip_directory) if '.zip' in f]
    zipfilepath = max(zipfiles)
    app.send_email(
        recipients=to_recipients,
        cc_recipients=cc_recipients,
        subject = f'Shipment Batam {currentdate}',
        body=bodymessage,
        attachments=[excel_attachment_path, zipfilepath]
    )

#for manual ============================================================================================================================
currentyear = datetime.now().year
currentmonthstr = datetime.now().strftime('%m')

def get_core_path(currentyear, currentmonthstr):
    core_path = rf"D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\{currentyear}"

    folders = os.listdir(core_path)
    for folder in folders:
        if folder.startswith(currentmonthstr):
            core_path = os.path.join(core_path, folder)
            folderlist = os.listdir(core_path)
            core_path = os.path.join(core_path, max(folderlist))
            break
    del folders

    return core_path

def get_reportbilling_path():
    core_path = get_core_path(currentyear, currentmonthstr)
    return rf"{core_path}\billing.xlsx"

def get_vf25_path():
    core_path = get_core_path(currentyear, currentmonthstr)
    return rf"{core_path}\vf25.xlsx"

def get_main_path():
    core_path = get_core_path(currentyear, currentmonthstr)
    maxday = core_path.split('\\')[-1]
    return rf"{core_path}\DATA READY DELIVERY BATAM {currentyear}{currentmonthstr}{maxday}.xlsx"

def check_final_path():
    try:
        df = pd.read_excel(get_main_path(), sheet_name='Sheet2')
        return True
    except:
        return False
    
def update_master_data(main_path):
    main_sheet_1_df = pd.read_excel(main_path, sheet_name='Sheet1')
    main_sheet_2_df = pd.read_excel(main_path, sheet_name='Sheet2')

    path = r"D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\POWERAPP\Part_Batam - Copy.xlsx"

    sheet_1_df = pd.read_excel(path, sheet_name='Sheet1')
    sheet_1_df = pd.concat([sheet_1_df, main_sheet_1_df], ignore_index=True)

    sheet_2_df = pd.read_excel(path, sheet_name='Sheet2')
    sheet_2_df = pd.concat([sheet_2_df, main_sheet_2_df], ignore_index=True)
    
    sheet_4_df = pd.read_excel(path, sheet_name='Sheet4')
    del main_sheet_1_df, main_sheet_2_df

    writer = pd.ExcelWriter(path, engine='xlsxwriter')
    sheet_1_df.to_excel(writer, sheet_name='Sheet1', index=False)
    sheet_2_df.to_excel(writer, sheet_name='Sheet2', index=False)
    sheet_4_df.to_excel(writer, sheet_name='Sheet4', index=False)

    workbook = writer.book
    ws1 = writer.sheets['Sheet1']
    ws2 = writer.sheets['Sheet2']
    ws4 = writer.sheets['Sheet4']

    ws1.add_table(0,0,sheet_1_df.shape[0], sheet_1_df.shape[1] - 1, {'columns': [{'header': c} for c in sheet_1_df.columns], 'name': 'Detail_Batam'})
    ws2.add_table(0,0,sheet_2_df.shape[0], sheet_2_df.shape[1] - 1, {'columns': [{'header': c} for c in sheet_2_df.columns], 'name': 'Part_Batam'})
    ws4.add_table(0,0,sheet_4_df.shape[0], sheet_4_df.shape[1] - 1, {'columns': [{'header': c} for c in sheet_4_df.columns], 'name': 'Email_Batam'})

    #close and save the worksheet
    writer.close()