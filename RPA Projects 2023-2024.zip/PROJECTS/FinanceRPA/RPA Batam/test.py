from Batam import *

path = r"D:\Users\Mahmudin.M2\OneDrive - daihatsu.astra.co.id\BATAM\2024\08. AGU\12\DATA READY DELIVERY BATAM 20240812 - Copy.xlsx"
# send_email(path)

update_master_data(path)