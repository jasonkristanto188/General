from datetime import datetime

def get_month_of_x_months_ago(x):
    pastXmonth = datetime.now().month - x
    while pastXmonth <= 0:
        pastXmonth += 12
    return pastXmonth

def get_year_of_x_months_ago(x):
    pastXmonth = datetime.now().month - x
    yearOfXMonthsAgo = datetime.now().year
    while pastXmonth <= 0:
        pastXmonth += 12
        yearOfXMonthsAgo -= 1
    return yearOfXMonthsAgo

def get_last_date_of_month_x(x):
    if x == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    return 30 if x in [4, 6, 9, 11] else 31

def getCurrentDateSAP():
    return datetime.now().strftime('%d.%m.%Y')