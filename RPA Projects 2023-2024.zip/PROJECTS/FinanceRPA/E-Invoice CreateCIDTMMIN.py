import os
import time
import pypdf
import pandas as pd
from datetime import datetime, timedelta

def mergeListEInvoice():
    path = r'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Summary Sales Unit\List Invoice lists FP'

    maindf = pd.DataFrame()
    files = os.listdir(path)
    for file in files:
        if not file.startswith('~'):
            excelpath = os.path.join(path, file)
            df = pd.read_excel(excelpath)
            maindf = pd.concat([maindf, df], ignore_index=True)

            del df
    
    maindf['Tax Vat Number'] = maindf['Tax Vat Number'].apply(lambda x: x.replace('.', ''))
    tmmindf = maindf[maindf['Customer'] == 100000034].reset_index(drop=True)
    return tmmindf

def getHardcopyEInvoice():
    directory = r'Y:\E-INVOICE&E-MATERAI\UNIT\TMMIN'
    files = os.listdir(directory)

    invoicelist = []
    for file in files:
        if '100000034' in file.lower() or '-signed' in file.lower(): 
            pdf_filepath = os.path.join(directory, file)
            with open(pdf_filepath, 'rb') as pdf_file:
                pdf_reader = pypdf.PdfReader(pdf_file)
                targetpage = pdf_reader.pages[0]    #read the first page
                pagetext = targetpage.extract_text()
                lines = pagetext.split('\n')
            
            if len(lines) > 0:
                invoiceNo = lines[2].split(':')[-1].strip()
                invoicelist.append(invoiceNo)
                # invoicelist.append(int(invoiceNo))
    print(invoicelist)
    return invoicelist
  
def getGRNoFromFinal():
    path = r"D:\DataVision\Invoice Creation\final.xlsx"
    df = pd.read_excel(path)
    df['Received/GR Date'] = df['Received/GR Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y %H:%M:%S').strftime('%d.%m.%Y'))
    df['Supplier Reference No'] = df['Supplier Reference No'].apply(lambda x: str(x))
    invoicenotyetcreateddf = df
    # invoicenotyetcreateddf = df[df['Invoice Status Vision'] == 'Invoice not yet created'].reset_index(drop=True)
    print(invoicenotyetcreateddf)
    return invoicenotyetcreateddf

def getListFP_PDF():
    path = r'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Faktur pajak Unit'

    files = os.listdir(path)

    listfp = []
    for file in files:
        nomorfakturpajak = file.split('-')[1].strip()
        listfp.append(nomorfakturpajak)
    
    return listfp

def getListFP_EBridge():
    path = r"D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Summary Sales Unit\List FP E-Bridge\List FP E-Bridge.xlsx"
    df = pd.read_excel(path)

    df['Tax Invoice No'] = df['Tax Invoice No'].apply(lambda x: x.replace('.', ''))
    df['Tax Invoice No'] = df['Tax Invoice No'].apply(lambda x: x.replace('-', ''))
    return df['Tax Invoice No'].values.tolist()

def createCIDTMMIN():
    maindf = mergeListEInvoice()    #customer, invoice date, commercial, tax vat number
    maindf[['Hardcopy E-Invoice Stamp', 'GR No Vision','Invoice Status Vision', 'Faktur Pajak in PDF', 'Faktur Pajak in E-Bridge', 'Status Rekon']] = None
    maindf['Commercial'] = maindf['Commercial'].apply(lambda x: str(x))

    #hardcopy e-invoice
    hardcopyeinvoicelist = getHardcopyEInvoice()

    #GR No Vision
    grvisiondf = getGRNoFromFinal()
   

    #faktur pajak in PDF
    listFakturPajakPDF = getListFP_PDF()   

    #faktur pajak in E-Bridge
    listFakturPajakEBridge = getListFP_EBridge()

    for index, row in maindf.iterrows():
        #update hardcopy e-invoice in maindf
        if row['Commercial'] in hardcopyeinvoicelist:
            maindf.loc[index, 'Hardcopy E-Invoice Stamp'] = 'OK'
        else :
            maindf.loc[index, 'Hardcopy E-Invoice Stamp'] = 'NOK'
            maindf.loc[index, 'Status Rekon'] = 'Not Yet Completed'

        #insert GR No Vision into maindf
        grlist = grvisiondf.loc[(grvisiondf['Supplier Reference No'] == row['Commercial']) \
            & (grvisiondf['Received/GR Date'] == row['Invoice Date']), 'GR No'].values.tolist()
        grstatus = grvisiondf.loc[(grvisiondf['Supplier Reference No'] == row['Commercial']) \
            & (grvisiondf['Received/GR Date'] == row['Invoice Date']), 'Invoice Status Vision'].values.tolist()        
                          
        if len(grlist) > 0:
            maindf.loc[index, 'GR No Vision'] = grlist[0]
        else:
            maindf.loc[index, 'Status Rekon'] = 'Not Yet Completed'
        
        if len(grstatus) > 0:
            maindf.loc[index, 'Invoice Status Vision'] = grstatus[0]


        #update faktur pajak PDF in maindf
        if row['Tax Vat Number'] in listFakturPajakPDF:
            maindf.loc[index, 'Faktur Pajak in PDF'] = 'OK'
        else:
            maindf.loc[index, 'Faktur Pajak in PDF'] = 'NOK'
            maindf.loc[index, 'Status Rekon'] = 'Not Yet Completed'

        #update faktur pajak EBridge in maindf
        if row['Tax Vat Number'] in listFakturPajakEBridge:
            maindf.loc[index, 'Faktur Pajak in E-Bridge'] = 'OK'
        else:
            maindf.loc[index, 'Faktur Pajak in E-Bridge'] = 'NOK'
            maindf.loc[index, 'Status Rekon'] = 'Not Yet Completed'
    
    #if everything went well, then status rekon = Ready to create
    maindf['Status Rekon'] = maindf['Status Rekon'].apply(lambda x: 'Ready To Create' if x is None else x)

    #sort the data based on invoice date
    maindf['Invoice Date'] = pd.to_datetime(maindf['Invoice Date'], format='%d.%m.%Y')
    maindf = maindf.sort_values(by='Invoice Date')
    maindf = maindf.reset_index(drop=True)
    maindf = maindf.query("`Invoice Status Vision` != 'Created'")
    maindf = maindf.query("`Invoice Status Vision` != 'Posted'")
    maindf = maindf.query("`Invoice Status Vision` != 'Paid'")
    #see the final result
    print('final result:')
    print(maindf)
    print(maindf[['Invoice Date', 'Commercial', 'Hardcopy E-Invoice Stamp', 'GR No Vision', 'Invoice Status Vision', 'Status Rekon']])
    #generate excel
    filename = 'Monitoring Create CID TMMIN.xlsx'
    excelpath = rf'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Summary Sales Unit\Monitoring Create CID TMMIN\{filename}'

    maindf.to_excel(excelpath, index=False)
    return excelpath 

def getDataForCID():
    path = r"D:\Users\jason.kristanto\OneDrive - daihatsu.astra.co.id\RPA Finance\Monitoring Create CID TMMIN.xlsx"
    df = pd.read_excel(path)
    df['Commercial'] = df['Commercial'].apply(lambda x: str(x))
    df['Invoice Date'] = df['Invoice Date'].apply(lambda x: x.strftime('%d-%b-%Y'))
    df['GR No Vision'] = df['GR No Vision'].apply(lambda x: str(x))

    return df[df['Status Rekon'] == 'Ready To Create'].values.tolist()

def getVisionDateRange():
    currentdatetime = datetime.now()

    today = currentdatetime.strftime('%d')

    currentmonth = currentdatetime.month
    xxxcurrentmonth = currentdatetime.strftime('%b')

    pastmonth = 12 if currentmonth - 1 == 0 else currentmonth - 1
    xxxpastmonth = datetime.strptime(str(pastmonth), '%m').strftime('%b')

    currentyear = currentdatetime.year
    yearOfPastMonth = currentyear - 1 if pastmonth == 12 else currentyear

    return f'01-{xxxpastmonth}-{yearOfPastMonth} to {today}-{xxxcurrentmonth}-{currentyear}'



def web():
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.edge.options import Options
    from selenium.webdriver.support.select import Select
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    edge_options = Options()
    edge_options.add_experimental_option("detach", True)
    driver = webdriver.Edge(options=edge_options)
    driver.maximize_window()

    #open website
    website = 'https://vision.toyota.co.id/Login#r'
    driver.get(website)

    #insert username
    usernametextbox = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div[2]/div/div/div/div[1]/div/form/fieldset/div[1]/input"))
    )
    username = '0005.epitanta'
    usernametextbox.send_keys(username)

    #insert password
    password = 'Ayla100'
    passwordtextbox = driver.find_element(By.XPATH, '/html/body/div[1]/div[2]/div/div/div/div[1]/div/form/fieldset/div[2]/input')
    passwordtextbox.send_keys(password)
    
    #maximize the browser before we login

    #click login
    loginbutton = driver.find_element(By.XPATH, '/html/body/div[1]/div[2]/div/div/div/div[1]/div/form/fieldset/div[3]/button')
    loginbutton.click()

    data = getDataForCID()

    #begin the main function
    for counter in range(0, len(data)):

        #click Transaction
        transaction = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/aside[1]/div/div[4]/div/div/nav/ul/li[2]/a"))
        )
        transaction.click()

        #click Invoicing
        invoicing = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/aside[1]/div/div[4]/div/div/nav/ul/li[2]/ul/li[2]/a'))
        )
        invoicing.click()
        
        #click Invoice Creation
        invoicecreation = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH , '/html/body/div[1]/aside[1]/div/div[4]/div/div/nav/ul/li[2]/ul/li[2]/ul/li[1]/a'))
        )
        invoicecreation.click()
        
        #insert supplier no
        suppliercode = '0045'
        suppliercode_textbox = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[1]/div[1]/div[1]/div/input'))
        )
        suppliercode_textbox.send_keys(suppliercode)
        
        #insert gr/sa no
        grnum = data[counter][5]
        grsano = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[1]/div[3]/div[2]/div/input'))
        )
        grsano.send_keys(grnum)
        
        #insert transaction type
        transactiontype_options = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[1]/div[3]/div[2]/div/input'))
        )
        transactiontype_options.click()

        transactiontype = 'CBU - Vehicle CBU'
        transactiontype_textbox = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[1]/div[1]/div[3]/div/div/div/div/input'))
        )
        transactiontype_textbox.send_keys(transactiontype)
        transactiontype_textbox.send_keys(Keys.ENTER)

        #insert GR/SA Date
        daterange = getVisionDateRange()
        daterange_textbox = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[1]/div[3]/div[1]/div/input'))
        )
        daterange_textbox.send_keys(Keys.CONTROL)
        daterange_textbox.send_keys('A')
        daterange_textbox.send_keys(Keys.BACKSPACE)
        daterange_textbox.send_keys(daterange)
        daterange_textbox.send_keys(Keys.ENTER)
        time.sleep(1)

        #click search
        searchbutton = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/form/div/div[2]/div[2]/div/button[1]'))
        )
        searchbutton.click()

        driver.execute_script("document.body.style.zoom = '80%'")
        time.sleep(1)

        #there should be only one row
        row = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/div[1]/div[2]/div/div[1]/table/tbody/tr[3]'))
        )
        time.sleep(1)

        #select the row
        row_checkbox = WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/section/div[2]/div[1]/div[1]/div[2]/div/div[1]/table/tbody/tr[3]/td[1]/input'))
        )

        #click preview invoice
        previewInvoice_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div[1]/section/div[2]/div[1]/div[1]/div[1]/div/div[2]/div[2]/div/button[1]"))
        )
        previewInvoice_button.click()

        #input invoice num
        invoicenum_textbox = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div[1]/section/div[2]/div[1]/div[3]/div/div/div[2]/div[2]/div[2]/div/div[1]/div[2]/div"))
        )
        driver.execute_script("arguments[0].scrollIntoView();", invoicenum_textbox) # Scroll to the element

        invoicenum = data[counter][2]
        invoicenum_textbox.send_keys(invoicenum)

    #     RPA.Browser.Selenium.Input Text    xpath:/html/body/div[1]/div[1]/section/div[2]/div[1]/div[3]/div/div/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/input    ${invoicenum}

        break

web()
# print(getVisionDateRange())