from datetime import datetime, timedelta
import pandas as pd
import subprocess
import time
import os

onedrive_main_path = r"C:\Users\Administrator\OneDrive - daihatsu.astra.co.id\Notif BMPV - Rio Abdurrahman's files"

def get_txt_data(txt_data):
    mainlist = []
    breaklines = txt_data.split('\n')
    for line in breaklines:
        mainlist.append(line.split('\t'))

    return mainlist

def merge_multiple_txt_files(path):
    files = [f for f in os.listdir(path) if f.lower().endswith('.txt')]
    maindf = pd.DataFrame()

    for file in files:
        txtfile = open(os.path.join(path, file))
        txt_data = txtfile.read()
        df = pd.DataFrame(get_txt_data(txt_data))

        if 'Upload' in path:
            df.columns = ['No', 'Status Upload', 'Supplier Code', 'Manifest', 'Part Number', 'Quantity PO', 'Quantity GR', 'Upload', 'Message Upload']
            date = file.split()[3]
            time = file.split()[-1].split('.')[0]
            if '_' not in time:
                time = f'{time[0:2]}_{time[2:4]}_{time[4:]}'
        else:   # elif 'Sales' in path:
            df.columns = df.iloc[0]
            df = df.iloc[1:]
            df.reset_index(drop=True, inplace=True)
            date = file.split('_')[2].split()[0]
            time = file.split()[1].split('.')[0]
        
        date = date.split('.')[2] + '-' + date.split('.')[1] + '-' + date.split('.')[0]
        time = time.replace('_', ':')
        df['Date created'] = date + ' ' + time

        maindf = pd.concat([maindf, df], ignore_index=True)
    
    return maindf

def get_latest_txt_file(path):

    max = None
    files = os.listdir(path)
    for file in files:
        if 'GI Sales' in path:
            current_date = file.split()[0].split('_')[-1]
            current_time = file.split()[-1]
        else:
            current_date = file.split()[3]
            current_time = file.split()[4]
            
        year = current_date.split('.')[2]
        month = current_date.split('.')[1]
        day = current_date.split('.')[0]
        current_date = f'{year}.{month}.{day}'
        current_datetime = current_date + ' ' + current_time

        if max is None or max < current_datetime:
            max = current_datetime
            target_file_path = os.path.join(path, file)

    txtfile = open(target_file_path)
    txt_data = txtfile.read()
    df = pd.DataFrame(get_txt_data(txt_data))
    df.columns = df.iloc[0]
    df = df.iloc[1:]
    df.reset_index(drop=True, inplace=True)
    return df

def proses_latest_txt_file(df, type):
    for index, row in df.iterrows():
        df.loc[index, 'Status'] = 'S' if row['Message'] == 'Success' else f'E{type}'
    if type == 'TP':    #jgn drop yg 'GR'
        df.drop_duplicates(inplace=True)

    df.reset_index(drop=True, inplace=True)
    df = df.rename(columns={'Status': type, 'Message': f'Message {type}'})

    return df

def save_dataframe_as_table(df, outputpath, tablename):
    #df can be a df or a dflist

    # Create a Pandas Excel writer using XlsxWriter as the engine
    writer = pd.ExcelWriter(outputpath, engine='xlsxwriter')

    # Write the DataFrame to the Excel file
    if isinstance(df, pd.DataFrame):
        df = [df]
        sheetnamelist = ['Sheet1']
    elif isinstance(df, list):
        sheetnamelist = ['Sheet1', 'Summary']

    for x in range(len(df)):
        # df[x].to_excel(writer, sheet_name=sheetnamelist[x], startrow=1, header=False, index=False)
        df[x].to_excel(writer, sheet_name=sheetnamelist[x], index=False)

        time.sleep(3)

        # Get the xlsxwriter workbook and worksheet objects
        workbook  = writer.book
        worksheet = writer.sheets[sheetnamelist[x]]

        # Get the dimensions of the DataFrame
        (max_row, max_col) = df[x].shape

        # Create a list of column headers, to use in add_table()
        column_settings = [{'header': column} for column in df[x].columns]

        # Add the Excel table structure with a table name
        worksheet.add_table(0, 0, max_row, max_col - 1, {
            'columns': column_settings,
            'name': tablename[x]
        })

    # Close the Pandas Excel writer and output the Excel file
    writer.close()

    while not os.path.isfile(outputpath):
        pass
    
def encrypt_file(outputpath, inputpath, password):
    # Path to your batch file
    batch_file = r"D:\Users\Jason.Kristanto\Jason's Projects\Monitoring Component BMPV\compress_file_with_password.bat"

    # Arguments to pass to the batch file
    args = [outputpath, inputpath, password]

    # Run the batch file with arguments
    subprocess.run([batch_file] + args, shell=True)    

def merge_with_parameter_message_error_data(df, type):
    error_parameter_path = rf"{onedrive_main_path}\Parameter Message Error\Message {type}.xlsx"
    error_parameter_df = pd.read_excel(error_parameter_path)

    for index, row in df.iterrows():
        for index2, row2 in error_parameter_df.iterrows():
            if row2['Message'] in row[f'Message {type}']:
                df.loc[index, 'Error'] = row2['Error']
    return pd.merge(df, error_parameter_df[['Error', 'Notif']], how='left', on='Error')
    
def generate_excel_for_logistic_and_stock(output_directory, df, logisticdf, type):
    output_directory_a = os.path.join(output_directory, f'Notification {type}')
    output_directory_b = os.path.join(output_directory, f'Notification {type} Stock')
    filename_a = f"Notifikasi {type} {datetime.now().strftime('%Y%m%d %H%M%S')}.xlsx"
    filename_b = f"Notifikasi {type} Stock {datetime.now().strftime('%Y%m%d %H%M%S')}.xlsx"

    type = type.replace(' ', '_')

    if len(df) > 0:
        save_dataframe_as_table(df, os.path.join(output_directory_a, filename_a), f'Notifikasi_{type}')
    if len(logisticdf) > 0:
        logistic_summary_df = logisticdf[['Part Number', 'Stock Kurang']].groupby('Part Number').sum().reset_index()
        tablenamelist = [f'Notifikasi_{type}_Stock', f'Summary_Stock_{type}']
        save_dataframe_as_table([logisticdf, logistic_summary_df], os.path.join(output_directory_b, filename_b), tablenamelist)
    