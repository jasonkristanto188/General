from proses_rekon_BMPV_functions import *

def proses_rekonsiliasi_BMPV(maindf, beginning_upload_df, GR_part_df, TP_part_df, GI_sales_df, master_supplier_data):
    #get Upload GR data
    upload_GR_df = maindf[maindf['Status Upload'] == 'GR']  
    upload_GR_df.drop_duplicates(subset=['Manifest'], inplace=True)
    upload_GR_df.reset_index(drop=True, inplace=True)
    upload_GR_df = pd.concat([upload_GR_df, beginning_upload_df], ignore_index=True)

    #get beginning sales data
    beginning_sales_path = os.path.join(onedrive_main_path, 'Data Begining Sales.xlsx')
    beginning_sales_df = pd.read_excel(beginning_sales_path)

    #get necessary data from GR sales
    GI_sales_df = GI_sales_df[['Date created', 'Manifest', 'Status', 'Message']]
    GI_sales_df = GI_sales_df.drop_duplicates(subset=['Manifest'], keep='first')
    GI_sales_df.reset_index(drop=True, inplace=True)
    GI_sales_df = GI_sales_df.rename(columns={'Status': 'Sales', 'Message': 'Message Sales'})
    GI_sales_df = pd.concat([GI_sales_df, beginning_sales_df], ignore_index=True)
    GR_part_df = GR_part_df[['Manifest', 'GR', 'Message GR']]

    #get necessary columns from TP Part
    TP_part_df = TP_part_df[['Manifest', 'TP', 'Message TP']]

    #merge all data above to generate rekonsiliasi data 
    rekonsiliasi_df = upload_GR_df[['Date created', 'Supplier Code', 'Manifest', 'Upload', 'Message Upload']]
    rekonsiliasi_df.loc[rekonsiliasi_df['Upload'] == 'S', 'Upload'] = 'UploadSuccses'
    rekonsiliasi_df.loc[rekonsiliasi_df['Upload'] == 'E', 'Upload'] = 'UploadGRError'
    rekonsiliasi_df = rekonsiliasi_df.merge(GR_part_df, on='Manifest', how='left')
    rekonsiliasi_df = rekonsiliasi_df.merge(TP_part_df, on='Manifest', how='left')
    rekonsiliasi_df = rekonsiliasi_df.merge(GI_sales_df[['Manifest', 'Sales', 'Message Sales']], on='Manifest', how='left')

    #replace all empty values with empty strings
    for col in rekonsiliasi_df.columns:
        rekonsiliasi_df[col] = rekonsiliasi_df[col].apply(lambda x: '' if pd.isna(x) else x)

    for index, row in rekonsiliasi_df.iterrows():
        # print(row['Manifest'], row['Supplier Code'])
        rekonsiliasi_df.loc[index, 'Supplier Name'] = master_supplier_data.loc[master_supplier_data['Supplier Code'] == str(row['Supplier Code']), 'Supplier Name'].values[0]

        #add column 'Final Check'
        if row['Supplier Code'] == 'ADM':
            finalcheck = row['Upload'] + row['TP'] + row['Sales']
            rekonsiliasi_df.loc[index, 'Production'] = 'Inhouse'
        else:
            finalcheck = row['Upload'] + row['GR'] + row['Sales']
            rekonsiliasi_df.loc[index, 'Production'] = 'Outhouse'
        rekonsiliasi_df.loc[index, 'Final Check'] = finalcheck

        #add column 'Error Status'
        if finalcheck == 'UploadSuccses' or finalcheck == 'UploadSuccsesS':
            rekonsiliasi_df.loc[index, 'Error Status'] = 'Already to Billing'
            rekonsiliasi_df.loc[index, 'Noted'] = 'OK'
        elif finalcheck == 'UploadSuccsesEGI':
            rekonsiliasi_df.loc[index, 'Error Status'] = row['Message Sales']
            rekonsiliasi_df.loc[index, 'Noted'] = 'Error'
        elif finalcheck == 'UploadSuccsesEGR':
            rekonsiliasi_df.loc[index, 'Error Status'] = row['Message GR']
            rekonsiliasi_df.loc[index, 'Noted'] = 'Error'
        elif finalcheck == 'UploadSuccsesETP':
            rekonsiliasi_df.loc[index, 'Error Status'] = row['Message TP']
            rekonsiliasi_df.loc[index, 'Noted'] = 'Error'
        elif finalcheck == 'UploadSuccesUploadSuccess':
            rekonsiliasi_df.loc[index, 'Error Status'] = 'Belum Ada Proses GR/TP, SO, DN, GI'
            rekonsiliasi_df.loc[index, 'Noted'] = 'OK'
        else:
            rekonsiliasi_df.loc[index, 'Error Status'] = None
            rekonsiliasi_df.loc[index, 'Noted'] = 'OK'
    
    #rearrange the columns' positions
    rekonsiliasi_df_columns = rekonsiliasi_df.columns.tolist()
    rekonsiliasi_df_columns.remove('Production')
    rekonsiliasi_df_columns.insert(1, 'Production')
    rekonsiliasi_df_columns.remove('Supplier Name')
    rekonsiliasi_df_columns.insert(3, 'Supplier Name')
    rekonsiliasi_df = rekonsiliasi_df[rekonsiliasi_df_columns]

    #merge with rekonsiliasi feedback data, if any
    feedbackpath = os.path.join(onedrive_main_path, 'Rekonsiliasi BMPV - Feedback.xlsx') 
    if os.path.isfile(feedbackpath):
        feedback_df = pd.read_excel(feedbackpath)
        rekonsiliasi_df = pd.merge(rekonsiliasi_df, feedback_df, how='left', on='Manifest')

    #filter data for SAP then generate the excel file (for Bu Santi)
    sapfilter = ['UploadSuccsesEGI', 'UploadSuccsesEGR', 'UploadSuccsesETP']
    df_for_SAP = rekonsiliasi_df[rekonsiliasi_df['Final Check'].isin(sapfilter)]
    filename = 'Manifest Filter Report SAP.xlsx'
    df_for_SAP.to_excel(os.path.join(onedrive_main_path, filename), index=False)

    #generate excel for rekon data
    filename = 'Rekonsiliasi BMPV.xlsx'
    outputpath = r'C:\Users\Administrator\OneDrive - daihatsu.astra.co.id\Notif BMPV\Rekon BMPV'
    save_dataframe_as_table(rekonsiliasi_df, os.path.join(outputpath, filename), ['RekonBMPV'])

def proses_notifikasi_GR_logistic(GR_part_df, report_bmpv_df):
    GR_part_df.columns = ['No', 'Code', 'Plant', 'Manifest', 'Part Number', 'Qty PO', 'Qty GR TMMIN', 'GR', 'Message GR']
    GR_part_df = GR_part_df[['Manifest', 'Part Number', 'Qty PO', 'Qty GR TMMIN', 'GR', 'Message GR']]
    GR_part_df['Qty PO'] = GR_part_df['Qty PO'].apply(lambda x: int(x) if (not pd.isna(x) and not x) else x)
    GR_part_df['Qty GR TMMIN'] = GR_part_df['Qty GR TMMIN'].apply(lambda x: int(x) if (not pd.isna(x) and not x) else x)

    #ambil column2 yg perlu saja dari report BMPV
    bmpv_df = report_bmpv_df[['Manifest number', 'Plant', 'Actual GR Date', 'Vendor Name']]
    bmpv_df = bmpv_df.drop_duplicates()
    bmpv_df.reset_index(drop=True, inplace=True)

    #merge GR Part dengan report BMPV, diname 'notifikasi GR'
    notifikasi_GR_df = pd.merge(GR_part_df[GR_part_df['GR'] == 'EGR'], bmpv_df, left_on=['Manifest'], right_on=['Manifest number'])    
    notifikasi_GR_df.reset_index(drop=True, inplace=True)

    #add dua columns baru ke data notifikasi GR: 'PO' dan 'Delay time (in Days)'
    notifikasi_GR_df['PO'] = notifikasi_GR_df['Manifest'].apply(lambda x: 'PO Project' if x.startswith('X') else 'Reguler BMPV')
    notifikasi_GR_df['Delay time (in Days)'] = (datetime.now() - notifikasi_GR_df['Actual GR Date']).dt.days

    #bersih2 dan ambil column2 yg perlu saja dari data yg di merge
    # notifikasi_GR_df = notifikasi_GR_df[['Vendor Name', 'Manifest', 'Part Number', 'Plant', 'Actual GR Date', 'PO', 'Message GR', 'Delay time (in Days)']]    
    notifikasi_GR_df = notifikasi_GR_df.rename(columns={'Vendor Name': 'Supplier Name'})
    notifikasi_GR_df.sort_values(by=['Actual GR Date', 'Supplier Name'], inplace=True)
    notifikasi_GR_df.reset_index(drop=True, inplace=True)

    #merge with rekonsiliasi feedback data, if any
    feedbackpath = rf"{onedrive_main_path}\Rekonsiliasi BMPV - Feedback.xlsx"
    if os.path.isfile(feedbackpath):
        feedback_df = pd.read_excel(feedbackpath)
        notifikasi_GR_df = pd.merge(notifikasi_GR_df, feedback_df, how='left', on='Manifest')

    #merge with parameter message error data
    notifikasi_GR_df = merge_with_parameter_message_error_data(notifikasi_GR_df, 'GR')

    #split jadi dua df based on parameter message error
    notif_A = notifikasi_GR_df[(notifikasi_GR_df['Notif'] == 'A') | (pd.isna(notifikasi_GR_df['Notif']))]
    notif_A.drop_duplicates(inplace=True)
    notif_A.reset_index(drop=True, inplace=True)
    notif_A = notif_A[['Supplier Name', 'Plant', 'Manifest', 'Actual GR Date', 'Delay time (in Days)', 'PO', 'Error', 'Feedback']]
    notif_A.drop_duplicates(subset=['Manifest'], inplace=True)
    notif_A.reset_index(drop=True, inplace=True)

    notif_B = notifikasi_GR_df[notifikasi_GR_df['Notif'] == 'B']
    notif_B.reset_index(drop=True, inplace=True)
    notif_B['Stock Kurang'] = notif_B['Message GR'].apply(lambda x: int(x.split()[6]))
    notif_B = notif_B[['Supplier Name', 'Plant', 'Manifest', 'Part Number', 'Qty PO', 'Qty GR TMMIN', 'Actual GR Date', 'Delay time (in Days)', 'Stock Kurang', 'Error', 'Feedback']]
    notif_B.drop_duplicates(subset=['Manifest', 'Part Number'], inplace=True)
    notif_B.reset_index(drop=True, inplace=True)

    #generate excelnya
    output_directory = rf"{onedrive_main_path}\Notification Tabel"
    generate_excel_for_logistic_and_stock(output_directory, notif_A, notif_B, 'GR Logistic')

def proses_notifikasi_TP(TP_part_df, detail_bmpv_df):
    #clone TP Part data and rename it notifikasi TP
    notifikasi_TP_df = TP_part_df   

    #delete empty rows
    notifikasi_TP_df.dropna(subset=['Manifest'], inplace=True)
    notifikasi_TP_df.reset_index(drop=True, inplace=True)

    #add more columns
    notifikasi_TP_df = pd.merge(notifikasi_TP_df, detail_bmpv_df, left_on=['Manifest'], right_on=['Manifest number'])
    notifikasi_TP_df[['Qty Defisit Stock', 'Sloc', 'Remarks']] = ''
    
    for index, row in notifikasi_TP_df.iterrows():
        notifikasi_TP_df.loc[index, 'Delay time (in Days)'] = (datetime.now() - row['Actual GR Date']).days
        if 'Stock in transfer exceeded' in row['Message TP']:
            break_message_TP = row['Message TP'].split()
            notifikasi_TP_df.loc[index, 'Qty Defisit Stock'] = break_message_TP[6]
            # notifikasi_TP_df.loc[index, 'Plant'] = break_message_TP[-2]
            notifikasi_TP_df.loc[index, 'Sloc'] = break_message_TP[-1]
            notifikasi_TP_df.loc[index, 'Remarks'] = 'Stok Kurang Butuh TP untuk GR' 
        elif 'Posting only' in row['Message TP']:
            notifikasi_TP_df.loc[index, 'Remarks'] = 'Ubah tanggal Posting GR'
        else:
            notifikasi_TP_df.loc[index, 'Remarks'] = 'New Problem'

    notifikasi_TP_df['Vendor Name'] = 'ADM'
    notifikasi_TP_df['Qty PO'] = notifikasi_TP_df['Qty PO'].apply(lambda x: int(x))
    notifikasi_TP_df['Qty GR TMMIN'] = notifikasi_TP_df['Qty GR TMMIN'].apply(lambda x: int(x))
    notifikasi_TP_df.drop_duplicates(inplace=True)
    notifikasi_TP_df.sort_values(by=['Remarks', 'Actual GR Date', 'Manifest'], ascending=[True, False, True])
    notifikasi_TP_df.reset_index(drop=True, inplace=True)
    notifikasi_TP_df = notifikasi_TP_df.rename(columns={'Vendor Name': 'Supplier Name'})

    #merge with rekonsiliasi feedback data, if any
    feedbackpath = rf"{onedrive_main_path}\Rekonsiliasi BMPV - Feedback.xlsx"
    if os.path.isfile(feedbackpath):
        feedback_df = pd.read_excel(feedbackpath)
        notifikasi_TP_df = pd.merge(notifikasi_TP_df, feedback_df, how='left', on='Manifest')

    #merge with parameter message error data
    notifikasi_TP_df = merge_with_parameter_message_error_data(notifikasi_TP_df, 'TP')

    #split jadi dua df based on parameter message error
    notif_A = notifikasi_TP_df[(notifikasi_TP_df['Notif'] == 'A') | (pd.isna(notifikasi_TP_df['Notif']))]
    notif_A.drop_duplicates(inplace=True)
    notif_A.reset_index(drop=True, inplace=True)
    notif_A = notif_A[['Supplier Name', 'Plant', 'Manifest', 'Actual GR Date', 'Delay time (in Days)', 'TP', 'Error', 'Feedback']]
    notif_A.drop_duplicates(subset=['Manifest'], inplace=True)
    notif_A.reset_index(drop=True, inplace=True)

    notif_B = notifikasi_TP_df[notifikasi_TP_df['Notif'] == 'B']
    notif_B.reset_index(drop=True, inplace=True)
    notif_B['Stock Kurang'] = notif_B['Message TP'].apply(lambda x: int(x.split()[6]))
    notif_B = notif_B[['Supplier Name', 'Plant', 'Manifest', 'Part Number', 'Qty PO', 'Qty GR TMMIN', 'Actual GR Date', 'Delay time (in Days)', 'Stock Kurang', 'Error', 'Feedback']]
    notif_B.drop_duplicates(subset=['Manifest', 'Part Number'], inplace=True)
    notif_B.reset_index(drop=True, inplace=True)
    
    #generate excelnya
    output_directory = rf"{onedrive_main_path}\Notification Tabel"
    generate_excel_for_logistic_and_stock(output_directory, notif_A, notif_B, 'TP Logistic')

def proses_notifikasi_error_order_upload(maindf, master_supplier_data):
    maindf['Status Upload'] = maindf['Status Upload'].apply(lambda x: x.strip() if not pd.isna(x) else x)
    maindf['Message Upload'] = maindf['Message Upload'].apply(lambda x: x.strip() if not pd.isna(x) else x)

    df = maindf[(maindf['Status Upload'] == 'ORDER') & (maindf['Message Upload'] == 'Manifest Already Exist')]  
    df.reset_index(drop=True, inplace=True)

    df['Date created'] = df['Date created'].apply(lambda x: str(x))
    df['Date'] = df['Date created'].apply(lambda x: x.split()[0])
    df['Time'] = df['Date created'].apply(lambda x: x.split()[1])
    df = df[df['Date'] == max(df['Date'].values.tolist())]
    df = df[df['Time'] == min(df['Time'].values.tolist())]
    df.drop_duplicates(inplace=True)
    df.reset_index(drop=True, inplace=True)

    #merge with master supplier data
    df = df.merge(master_supplier_data[['Supplier Code', 'Supplier Name']], on='Supplier Code', how='left')

    #keep necessary columns only
    column_names = df.columns.tolist()
    column_names.remove('Supplier Name')
    column_names.remove('Date')
    column_names.remove('Time')
    column_names.insert(3, 'Supplier Name')
    df = df[column_names]

    output_directory = rf"{onedrive_main_path}\Notification Tabel\Notification Upload FTH GR\TMMIN"

    #merge with parameter message error data
    df = merge_with_parameter_message_error_data(df, 'Upload')
    
    #merge with rekonsiliasi feedback data, if any
    feedbackpath = rf"{onedrive_main_path}\Rekonsiliasi BMPV - Feedback.xlsx"
    if os.path.isfile(feedbackpath):
        feedback_df = pd.read_excel(feedbackpath)
        df = pd.merge(df, feedback_df, how='left', on='Manifest')

    df_col_list = df.columns.tolist()
    df_col_list.remove('Message Upload')
    df_col_list.remove('Upload')
    df_col_list.remove('Notif')
    df = df[df_col_list]
    
    filename = f"Notification Error Order Upload {datetime.now().strftime('%Y%m%d %H%M%S')}.xlsx"
    save_dataframe_as_table(df, os.path.join(output_directory, filename), 'Notification_Error_Order_Upload')

    newfilename = 'Notification Error Order Upload.zi_'
    encrypt_file(os.path.join(output_directory, newfilename), os.path.join(output_directory, filename), 'adm')

def proses_notifikasi_GI_sales(GI_notif_sales_df, master_supplier_data):
    df = GI_notif_sales_df.rename(columns={'Message GI': 'Message Sales', 'Code': 'Supplier Code'})
    df = df[~pd.isna(df['Manifest'])]
    df.reset_index(drop=True, inplace=True)

    #merge with master supplier data
    df = df.merge(master_supplier_data[['Supplier Code', 'Supplier Name']], on='Supplier Code', how='left')

    #merge with parameter message error data
    df = merge_with_parameter_message_error_data(df, 'Sales')

    #merge with rekonsiliasi feedback data, if any
    feedbackpath = rf"{onedrive_main_path}\Rekonsiliasi BMPV - Feedback.xlsx"
    if os.path.isfile(feedbackpath):
        feedback_df = pd.read_excel(feedbackpath)
        df = pd.merge(df, feedback_df, how='left', on='Manifest')
    
    notif_A = df[df['Notif'] == 'A']
    notif_A.drop_duplicates(subset=['Manifest', 'Part Number'], inplace=True)
    notif_A.reset_index(drop=True, inplace=True)
    notif_A = notif_A[['Supplier Name', 'Manifest', 'Plant', 'Part Number', 'Qty', 'Error', 'Feedback']]

    notif_B = df[['Supplier Name', 'Manifest', 'Plant', 'Part Number', 'Qty', 'SO Num', 'DO Num', 'Error', 'Feedback']][df['Notif'] == 'B']
    notif_B.drop_duplicates(subset=['Manifest'])
    notif_B.reset_index(drop=True, inplace=True)

    #generate excelnya
    output_directory = rf"{onedrive_main_path}\Notification Tabel"
    type = 'GI Sales'
    output_directory_a = os.path.join(output_directory, f'Notification {type}')
    output_directory_b = os.path.join(output_directory, f'Notification {type} SODNGI')
    filename_a = f"Notifikasi {type} {datetime.now().strftime('%Y%m%d %H%M%S')}.xlsx"
    filename_b = f"Notifikasi {type} SODNGI {datetime.now().strftime('%Y%m%d %H%M%S')}.xlsx"

    type = type.replace(' ', '_')

    if len(notif_A) > 0:
        save_dataframe_as_table(notif_A, os.path.join(output_directory_a, filename_a), f'Notifikasi_{type}')
    if len(notif_B) > 0:
        save_dataframe_as_table(notif_B, os.path.join(output_directory_b, filename_b), f'Notifikasi_{type}_SODNGI')

def proses_notifikasi_upload_FTH_GR(maindf):
    maindf['Status Upload'] = maindf['Status Upload'].apply(lambda x: x.strip() if not pd.isna(x) else x)
    maindf['Message Upload'] = maindf['Message Upload'].apply(lambda x: x.strip() if not pd.isna(x) else x)

    df = maindf[(maindf['Status Upload'] == 'ORDER') & (maindf['Message Upload'] == 'Manifest Already Exist')]  
    df.reset_index(drop=True, inplace=True)

def main():
    #get GR Part data
    GR_part_path = os.path.join(onedrive_main_path, 'GR Part')
    GR_part_df = get_latest_txt_file(GR_part_path)
    GR_part_df = proses_latest_txt_file(GR_part_df, 'GR')

    #get TP Part data
    TP_part_path = os.path.join(onedrive_main_path, 'TP Part')
    TP_part_df = get_latest_txt_file(TP_part_path)
    TP_part_df = proses_latest_txt_file(TP_part_df, 'TP')
    TP_part_df.columns = ['No', 'Vendor Name', 'Plant', 'Manifest', 'Part Number', 'Qty GR TMMIN', 'Qty PO', 'TP', 'Message TP']

    #get GI Sales data
    GI_sales_path = os.path.join(onedrive_main_path, 'GI Sales')
    GI_sales_df = merge_multiple_txt_files(GI_sales_path)
    GI_sales_df = GI_sales_df.dropna(subset=['Manifest'])
    GI_sales_df = GI_sales_df.sort_values(by=['Manifest', 'Date created'], ascending=[True, False])
    GI_sales_df.reset_index(drop=True, inplace=True)

    #get GI Sales notification data
    GI_notif_sales_df = get_latest_txt_file(GI_sales_path)
    GI_notif_sales_df = proses_latest_txt_file(GI_notif_sales_df, 'GI')

    #get upload GR data
    upload_GR_path = os.path.join(onedrive_main_path, 'Upload GR')
    maindf = merge_multiple_txt_files(upload_GR_path)
    maindf = maindf[['Date created', 'Status Upload', 'Supplier Code', 'Manifest', 'Upload', 'Message Upload']]
    maindf.loc[maindf['Upload'] == 'S', 'Message Upload'] = 'Upload Sukses'
    maindf = maindf.sort_values(by=['Date created'], ascending=False)

    #get beginning upload data
    beginning_upload_path = os.path.join(onedrive_main_path, 'Data Begining Upload.xlsx')
    beginning_upload_df = pd.read_excel(beginning_upload_path)

    #table Notification Error Order Upload
    order_GR_df = maindf[maindf['Status Upload'] == 'Order']
    order_GR_df.reset_index(drop=True, inplace=True)

    #master supplier 
    master_supplier_path = os.path.join(onedrive_main_path, 'Master Suplier Name.xlsx')
    master_supplier_data = pd.read_excel(master_supplier_path)
    master_supplier_data['Supplier Code'] = master_supplier_data['Supplier Code'].apply(lambda x: str(x))

    #get report bmpv data and split it into two dfs: SAP and SAP (Detail)
    #used to generate detail bmpv and for notifikasi GR Logistic
    report_bmpv_path = rf"{onedrive_main_path}\Report BMPV"
    report_bmpv_filepath = max([os.path.join(report_bmpv_path, f) for f in os.listdir(report_bmpv_path)])
    report_bmpv_df = pd.read_excel(report_bmpv_filepath)

    #used for notifikasi TP
    detail_bmpv_df = report_bmpv_df[['Vendor Name', 'Manifest number', 'Actual GR Date', 'Part Number ADM', 'Part Name']]

    #=============================================================================================

    #generate the sheets using the data above

    #sheet Rekonsiliasi BMPV
    proses_rekonsiliasi_BMPV(maindf, beginning_upload_df, GR_part_df, TP_part_df, GI_sales_df, master_supplier_data)

    #sheet Notifikasi GR Logistic
    proses_notifikasi_GR_logistic(GR_part_df, report_bmpv_df)

    #sheet Notifikasi TP 
    proses_notifikasi_TP(TP_part_df, detail_bmpv_df)

    #sheet Notifikasi Error Upload GR
    proses_notifikasi_error_order_upload(maindf, master_supplier_data)

    #sheet Notifikasi GI Sales
    proses_notifikasi_GI_sales(GI_notif_sales_df, master_supplier_data)
    
if __name__ == '__main__':
    main()
