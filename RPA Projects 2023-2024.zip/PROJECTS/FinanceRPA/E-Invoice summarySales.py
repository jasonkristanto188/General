import os
import re
import math
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from openpyxl import load_workbook
import win32com.client
import shutil

directory = r'\\adm-fs\fin\Billing\Report Billing\Summary Sales Query'
prntmmindirectory = r'D:\PRNTMMIN.XLSX'  
viperpath = r'D:\DataVision\Invoice Creation\final.xlsx'
duedatepath = r'\\adm-fs\fin\Billing\Report Billing\Summary Sales Query\Due Date\Penyesuaian Due Date.xlsx'

def modifyMainDF(df):
    df.columns = df.iloc[0].str.strip()     #set the first row as the column names
    df = df.drop(df.index[0])   #drop the first row
    df = df.loc[:, df.columns != '']    #delete columns that don't have a column name
    df = df.sort_values('Commercial')
    df.rename(columns={'Commercial': 'Invoice List', 'Invoice Date': 'Delivery Date', 'PPN BM-RP': 'PPN BM', 'PPh Pasal 22': 'PPH22'}, inplace=True)
    df = df.drop(columns = ['Material Des', 'Type', 'Nett Price', 'PPN BM-(%)', 'PPNBM PBG-(%)', 'PPNBM PBG-RP'])
    for col in df.columns:
        df[col] = df[col].apply(lambda x: x.strip() if isinstance(x, str) else x)
    
    df['Due Date'] = None
    df = df.reset_index(drop=True)
    return df



def format_number(number):
    if math.isnan(number):
        return '-'
    else:
        # Convert the number to a string
        if isinstance(number, float):
            number = int(number)

        s = str(number)
    
        # Reverse the string
        s = s[::-1]
        
        # Insert a period after every third digit
        s = '.'.join(s[i:i+3] for i in range(0, len(s), 3))
        
        # Reverse the string again and return the result
        return s[::-1]

def getDueDate(df): 
    specificDueDate = pd.read_excel(duedatepath)

    duedatelist = []
    for index, row in df.iterrows():

        if row['Delivery Date'] is None:
            duedatelist.append(None)
        else:
            date_object = datetime.strptime(row['Delivery Date'], "%d.%m.%Y")

            # Get the weekday name
            weekday_name = date_object.strftime('%A')

            # Set the due date
            if row['Customer'] == '100000034':
                if weekday_name == 'Sunday':
                    due_date = date_object + timedelta(days=9)
                elif weekday_name == 'Friday' or weekday_name == 'Saturday':
                    due_date = date_object + timedelta(days=10)
                else:
                    due_date = date_object + timedelta(days=8)    
            elif row['Customer'] == '100000015' or row['Customer'] == '100000044':
                if weekday_name == 'Saturday':
                    due_date = date_object + timedelta(days=23)
                elif weekday_name == 'Sunday':
                    due_date = date_object + timedelta(days=22)
                else:
                    due_date = date_object + timedelta(days=21)
            elif row['Customer'] == '100000043':
                days_dict = {
                    'Thursday': 13,
                    'Friday': 12,
                    'Saturday': 11,
                    'Sunday': 10,
                    'Monday': 9,
                    'Tuesday': 8,
                    'Wednesday': 7
                }

                if weekday_name in days_dict:
                    due_date = date_object + timedelta(days=days_dict[weekday_name])
            
            # Set specific due dates for specific invoice dates
            for index2, row2 in specificDueDate.iterrows():
                if str(row['Customer']) == str(row2['Customer Code']) \
                    and row['Delivery Date'] == row2['Invoice date'].strftime('%d.%m.%Y'):
                    due_date = row2['due date']
                    break

            duedatelist.append(due_date.strftime('%Y-%m-%d'))
        
    df['Due Date'] = duedatelist

    currentdatetime = datetime.now()
    yesterday = currentdatetime - timedelta(days=1)
    # print('yesterday:', yesterday.strftime('%Y-%m-%d'), type(yesterday))
    df = df[df['Due Date'] >= yesterday.strftime('%Y-%m-%d')]

    return df

def getTotalAmountTMMIN(df):
    invoiceset = set(df['Invoice List'].values.tolist())
    print(df.columns)

    mainlist = []
    for invoice in invoiceset:
        templist = []
        templist.append(invoice)
        tempdf = df[['Qty', 'DPP', 'PPN', 'PPN BM', 'PPH22', 'Total Amount']][df['Invoice List'] == invoice]
        
        invoicedate = set(df['Delivery Date'][df['Invoice List'] == invoice].values.tolist())
        templist.append(invoicedate.pop())

        for col in tempdf.columns:
            tempdf[col] = tempdf[col].apply(lambda x: float(x.replace('.', '')) if x is not None else x)
            sumnum = sum(tempdf[col].values.tolist())
            if sumnum.is_integer():
                sumnum = int(sumnum)
            templist.append(sumnum)
        
        del tempdf

        duedate = df['Due Date'][df['Invoice List'] == invoice].values[0]
        duedate = pd.to_datetime(str(duedate)).strftime('%Y-%m-%d')
        templist.append(duedate)

        mainlist.append(templist)

        del templist
    
    if len(mainlist) <= 0:
        return None
    else:
        newdfcols = ['Invoice List', 'Delivery Date', 'Qty', 'DPP', 'PPN', 'PPN BM', 'PPH22', 'Total Amount', 'Due Date']
        newdf = pd.DataFrame(mainlist, columns=newdfcols)
        newdf = newdf.sort_values(by=['Due Date', 'Invoice List'])

        newdf['Delivery Date'] = newdf['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%d %B %Y'))
        newdf['Due Date'] = newdf['Due Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime('%d %B %Y'))
        newdf['Grand Total'] = None

        duedate_list = set(newdf['Due Date'].values.tolist())
        for duedate in duedate_list:
            totallist = newdf['Total Amount'][newdf['Due Date'] == duedate].values.tolist()
            grandsum = 0
            for total in totallist:
                grandsum += total
                
            index = newdf[newdf['Due Date'] == duedate].index[0]
            newdf.loc[index, 'Grand Total'] = grandsum

        return newdf

def getTotalAmountAI(df):
    df['Qty'] = df['Qty'].apply(lambda x: int(x))
    df['Total Amount'] = df['Total Amount'].apply(lambda x: int(x.replace('.', '')))
    # invoiceset = set(df['Invoice List'].values.tolist())

    grouped_df = df.groupby(['Invoice List', 'Delivery Date', 'Due Date'])[['Qty', 'Total Amount']].sum().reset_index()
    return grouped_df



def getPRN(customercode):
    prndf = pd.read_excel(prntmmindirectory)
    prndf = prndf[['Cust. Code', 'Due Date', 'PRN Number', 'Total']][prndf['Cust. Code'] == customercode]
    prndf['PRN'] = None
    prndf['Grand Total'] = None

    duedate_list = set(prndf['Due Date'].values.tolist())

    for duedate in duedate_list:
        duedate = pd.to_datetime(duedate / 1e9, unit='s')
        
        prnlist = prndf['PRN Number'][prndf['Due Date'] == duedate].values.tolist()
        longprn = ''
        for prn in prnlist:
            longprn += str(prn)
        shorterprn = longprn[:15]

        index = prndf.loc[prndf['Due Date'] == duedate].index[0]
        prndf.loc[index, 'PRN'] = shorterprn

        sumlist = prndf['Total'][prndf['Due Date'] == duedate].values.tolist()
        total = 0
        for sum in sumlist:
            total += sum
        index = prndf.loc[prndf['Due Date'] == duedate].index[0]
        prndf.loc[index, 'Grand Total'] = total

    newprndf = prndf[['Due Date', 'PRN', 'Grand Total']]  

    newprndf = newprndf.dropna(subset=['PRN', 'Grand Total'])

    return newprndf

def mergeWithViper(df):
    viperdf = pd.read_excel(viperpath)
    viperdf = viperdf[['GR No', 'Supplier Reference No', 'GR Status', 'GR Status Vision']]
    viperdf.rename(columns={'Supplier Reference No': 'Invoice List'}, inplace=True)
    viperdf['Invoice List'] = viperdf['Invoice List'].apply(lambda x: str(x) if x is not None else None)

    mergeddf = df.merge(viperdf, how='left', on='Invoice List')
    
    return mergeddf
    


def getDateDay(fulldate):
    return fulldate.day

def getMonth(fulldate):
    return fulldate.strftime('%B')

def getYear(fulldate):
    return fulldate.strftime('%Y')

def mergetxtfiles():
    mainlist = []
    count = 0

    # Get all files in the directory
    for filename in os.listdir(directory):

        # Construct full file path
        filepath = os.path.join(directory, filename)

        # Check if path is a file
        if os.path.isfile(filepath):
            finalpath = directory + '\\' + filename

            with open(finalpath, 'r') as file:
                lines = file.readlines()
                modified_time = os.path.getmtime(finalpath)
        
                # Convert the timestamp to a datetime object
                modified_datetime = datetime.fromtimestamp(modified_time)

                # Read the file line by line
                start_reading = False

                for line in lines:
                    if line.lstrip().startswith("Material Des"):
                        count += 1
                        start_reading = True
                    elif line.lstrip().startswith("*"):
                        start_reading = False

                    if start_reading and line != '\n':
                        line = line.replace('\n', '')
                        breakline = line.split('\t')

                        if line.lstrip().startswith("Material Des"):
                            if count == 1:
                                breakline.append('File Source')
                                breakline.append('File Modified Date')
                                mainlist.append(breakline)
                        else:
                            breakline.append(filename)
                            breakline.append(modified_datetime)
                            mainlist.append(breakline)

    df = pd.DataFrame(mainlist)
    df = modifyMainDF(df)

    #generate due date column
    df = getDueDate(df)
    df = df.sort_values(by=['Invoice List', 'File Source'])

    dfcols = df.columns.values.tolist()
    # dfcols.remove('File Source')
    
    # Find the maximum value in column 'D' for each group in column 'A'
    # max_values = df.groupby('Invoice List')['File Source'].transform(max)
    max_values = df.groupby('Invoice List')['File Source'].transform('max')
 
    # Filter df to only include rows where 'D' is equal to the maximum value for that group
    df = df[df['File Source'] == max_values]
    del mainlist
    return df

    

def summarySalesTMMIN():
    df = mergetxtfiles()
    df = df[df['Customer'] == '100000034']
    # print(df['Delivery Date'])

    #generate total amount column
    df = getTotalAmountTMMIN(df)

    #merge with PRN
    prndf = getPRN(100000034)
    prndf['Due Date'] = prndf['Due Date'].apply(lambda x: x.strftime('%d %B %Y'))
    df = df.merge(prndf, how='left', on=['Due Date', 'Grand Total'])

    df = mergeWithViper(df)

    #final modification to df
    colsToFormatNum = ['Qty', 'DPP', 'PPN', 'PPN BM', 'PPH22', 'Total Amount', 'Grand Total']
    for col in colsToFormatNum:
        df[col] = df[col].apply(lambda x: format_number(x) if x is not None else x)

    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    df['Due Date'] = df['Due Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    df.rename(columns={'GR No': 'GR No in VIPER', 'GR Status': 'Status GR VIPER', 'GR Status Vision': 'Status Invoice Vision'}, inplace=True)

    #generate the excel
    filename = 'Sales Confirmation TMMIN.xlsx'
    filepath = '\\\\Adm-fs\\fin\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\TMMIN\\' + filename
    df.to_excel(filepath, index=False)
    # df.to_excel(filename, index=False)
    
    del df, colsToFormatNum
    return filepath
    # return filename

def convert_to_html_table_TMMIN(data):
    df = pd.DataFrame(data)
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: x.strftime('%d %B %Y'))
    df['Due Date'] = df['Due Date'].apply(lambda x: x.strftime('%d %B %Y'))
 
    html_table = df.to_html(index=False)
    newtr = '<tr style="text-align: center; font-size: 30px;"><b><u>REKAP KONFIRMASI SALES TMMIN (REGULER)</u></b></tr>'
    html_table = re.sub('<tr style="text-align: right;">', '<tr style="text-align: right; background-color: #FFCC66">', html_table)
    html_table = re.sub(' class="dataframe"', '', html_table)
    html_table = re.sub('None', '.', html_table)
    html_table = re.sub('<td>', '<td style="text-align: right;">', html_table)

    soup = BeautifulSoup(html_table, 'html.parser')

    for row in soup.find_all('tr'):
        td_elements = row.find_all('td')

        if len(td_elements) >= 10:
            td = td_elements[9]
            if td.text is not None:
                td.string.wrap(soup.new_tag('b'))
                td['style'] = 'background-color: yellow'

    html_table = str(soup)
    return html_table



def summarySalesAI():
    df = mergetxtfiles()
    
    #AI DSO
    dsodf = df[df['Customer'] == '100000015']
    dsodf = dsodf[['Delivery Date', 'Invoice List', 'Qty', 'Total Amount', 'Due Date']]
    dsodf = getTotalAmountAI(dsodf)
    dsodf.rename(columns={'Invoice List': 'Invoice No', 'Total Amount': 'Amount'}, inplace=True)

    #AI DSO - Batam
    tamdf = df[df['Customer'] == '100000044']
    tamdf = tamdf[['Delivery Date', 'Invoice List', 'Qty', 'Total Amount', 'Due Date']]
    tamdf = getTotalAmountAI(tamdf)
    tamdf.rename(columns={'Invoice List': 'Invoice No Batam', 
        'Qty': 'Qty Batam', 'Total Amount': 'Amount Batam'}, inplace=True)

    #merge the two dataframes
    mergeddf = dsodf.merge(tamdf, how='left', on=['Delivery Date', 'Due Date'])
    del dsodf, tamdf, df
    

    #format the date columns
    mergeddf['Delivery Date'] = mergeddf['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%m.%d.%Y'))
    mergeddf['Delivery Date'] = mergeddf['Delivery Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    mergeddf['Due Date'] = mergeddf['Due Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    
    #get the total qty and total amount
    deliverydateset = set(mergeddf['Delivery Date'].tolist())
    for date in deliverydateset:
        tempdf = mergeddf[mergeddf['Delivery Date'] == date].groupby(['Invoice No', 'Delivery Date', 'Due Date'])[['Qty Batam', 'Amount Batam']].sum().reset_index()
        index = mergeddf.loc[(mergeddf['Delivery Date'] == date) & (mergeddf['Invoice No'] == tempdf['Invoice No'].values[0]) & (mergeddf['Due Date'] == tempdf['Due Date'].values[0])].index[0]
        mergeddf.loc[index, 'TOTAL QTY'] = mergeddf.loc[index, 'Qty'] + tempdf['Qty Batam'].values[0]
        mergeddf.loc[index, 'TOTAL Amount'] = mergeddf.loc[index, 'Amount'] + tempdf['Amount Batam'].values[0]
        del tempdf

    #finalize the table
    mergeddf = mergeddf[['Delivery Date', 'Invoice No', 'Qty', 'Amount', 'Invoice No Batam',
        'Qty Batam', 'Amount Batam', 'TOTAL QTY', 'TOTAL Amount', 'Due Date']]
    
    #format the numbers
    cols = ['Qty', 'Amount', 'Qty Batam', 'Amount Batam', 'TOTAL QTY', 'TOTAL Amount']
    for col in cols:
        mergeddf[col] = mergeddf[col].apply(lambda x: format_number(x))
   
    # 'remove' duplicate rows
    # indexlist = mergeddf[mergeddf['TOTAL QTY'] == '-'].index
    # for index in indexlist:
    #     mergeddf.loc[index, ['Invoice No', 'Qty', 'Amount']] = '-'
    # 'remove' duplicate rows
    indexlist = mergeddf[mergeddf['TOTAL QTY'] == '-'].index
    for index in indexlist:
        mergeddf.loc[index, ['Invoice No', 'Qty', 'Amount', 'TOTAL Amount']] = mergeddf.loc[index, ['Invoice No', 'Qty', 'Amount', 'TOTAL Amount']].replace('-', np.nan)
        mergeddf['TOTAL Amount'].fillna(mergeddf['Amount'], inplace=True)
        mergeddf.loc[index, 'TOTAL QTY'] = mergeddf.loc[index, 'Qty']
    # convert_to_html_table_AI(mergeddf)

    #generate the excel
    filename = 'Sales Confirmation AI.xlsx'
    filepath = '\\\\Adm-fs\\fin\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\AI\\' + filename
    mergeddf.to_excel(filepath, index=False)
    # mergeddf.to_excel(filename, index=False)

    del indexlist, mergeddf
   
    return filepath
    # return filename
    

# def convert_to_html_table_AI(df):
def convert_to_html_table_AI(data):
    df = pd.DataFrame(data)
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: x.strftime('%d %B %Y'))
    df['Due Date'] = df['Due Date'].apply(lambda x: x.strftime('%d %B %Y'))
    dfcols = df.columns.values.tolist()

    tbody = ''
    for index, row in df.iterrows():
        if index % 2 == 0:
            color = 'background-color: white;'
        else:   #light orange
            color = 'background-color: #FFE6CC'

        trow = f'<tr style="{color}">\n'
        for col in dfcols:
            if col in ['Qty', 'Amount', 'Qty Batam', 'Amount Batam', 'TOTAL QTY', 'TOTAL Amount']:
                trow += '<td style="text-align: right;">'
            else:
                trow += '<td style="text-align: center;">'
            
            if row[col] is not None:
                if col in ['Delivery Date', 'TOTAL QTY', 'TOTAL Amount', 'Due Date']:
                    trow += f'<b>{row[col]}</b></td>\n'
                else:
                    trow += f'{row[col]}</td>\n'
            else:
                trow += '.</td>\n'

        trow += '</tr>\n'
        tbody += trow

    #additional last row for grand sum
    # lastrow = '<tr>'
    # for col in dfcols:
    #     if col in ['Qty', 'Amount', 'Qty Batam', 'Amount Batam', 'TOTAL QTY', 'TOTAL Amount']:
    #         df[col] = df[col].apply(lambda x: int(x.replace('.', '')))
    #         df[col] = df[col].apply(lambda x: 0 if x == '.' else x)
    #         lastrow += f'<td style="text-align: right;">{sum(df[col].values.tolist())}</td>\n'
    #     else:
    #         lastrow += '<td style="text-align: center;">.</td>\n'
    # lastrow += '</tr>\n'
    # tbody += lastrow
    
    html_str = f"""
    <table border="1">
        <thead>
            <tr style="text-align: center; background-color: orange;">
                <th rowspan='2'>Delivery Date</th>
                <th rowspan='2'>Invoice No</th>
                <th colspan='2'>AI DSO</th>
                <th rowspan='2'>Invoice No</th>
                <th colspan='2'>AI DSO - Batam</th>
                <th colspan='2'>TOTAL</th>
                <th rowspan='2'>Due Date</th>
            </tr>
            <tr style="text-align: center; background-color: #FFE6CC;">
                <th>QTY</th>
                <th>AMOUNT (IDR)</th>
                <th>QTY</th>
                <th>AMOUNT (IDR)</th>
                <th>QTY</th>
                <th>AMOUNT (IDR)</th>
            </tr>
        </thead>
        <tbody>
            {tbody}
        </tbody>
    </table>
    """

    return html_str

def zipAttachmentAI(list2d):
    df = pd.DataFrame(list2d, columns=['Path', 'Size', 'Date'])
    df = df[df['Size'] > 22]    #take files that are bigger than 1kb
    df['Date'] = df['Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d'))
 
    dateset = list(set(df['Date'].values.tolist()))
    latestdate = max(dateset)
 
    latestdf = df[df['Date'] == latestdate]
    latestdatelist = latestdf['Path'].values.tolist()
    print(latestdatelist)
 
    return latestdatelist #return a list of zip paths

def convert_to_html_table_TAM(data):
    df = pd.DataFrame(data)
    df['Delivery Date'].iloc[:-1] = df['Delivery Date'].iloc[:-1].apply(lambda x: x.strftime('%d %B %Y'))
    df['Due Date'] = df['Due Date'].apply(lambda x: x.strftime('%d %B %Y'))
   
    formatNumCols = ['Qty', 'Amount', 'Materai', 'Total Amount']
    for col in formatNumCols:
        df[col] = df[col].apply(lambda x: format_number(x) if x != '-' else x)
    print(df)
 
    dfcols = df.columns.values.tolist()
 
    tbody = ''
    for index, row in df.iterrows():
        if index % 2 == 0:
            style = 'background-color: white;'
        else:   #light gray/blue
            style = 'background-color: #FFE6CC'
       
        trow = f'<tr style="{style}">\n'
        for col in dfcols:
            if col == 'Payment Reference Code':
                if index == 0:
                    trow += f'<td rowspan="{len(df)}" style="background-color: yellow; text-align: center;"><b>{row[col]}</b></td>\n'
            else:
                style = ''
                if col in ['Qty', 'Amount', 'Materai', 'Total Amount', 'Invoice No']:
                    style = 'text-align: right;'
                else:
                    style = 'text-align: center;'
               
                if index == len(df) - 1:
                    style += 'background-color: yellow; color: red'
                   
                trow += f'<td style="{style}">'
 
                if row[col] is not None:
                    if index == len(df) - 1:
                        trow += f'<b>{row[col]}</b></td>\n'
                    else:
                        trow += f'{row[col]}</td>\n'
                else:
                    trow += '.</td>\n'
           
        trow += '</tr>\n'
        tbody += trow
        del trow
 
    html_str = f"""
    <table border=1>
        <thead>
            <tr style="text-align: center; background-color: orange;">
                <td rowspan='2'><b>DELIVERY DATE</b></td>
                <td rowspan='2'><b>DUE DATE</b></td>
                <td colspan='5'><b>DESCRIPTION</b></td>
                <td rowspan='2'><b>PAYMENT REFERENCE CODE</b></td>
            </tr>
            <tr style="text-align: center; background-color: #FFE6CC;">
                <td><b>QTY</b></td>
                <td><b>AMOUNT (IDR)</b></td>
                <td><b>MATERAI (IDR)</b></td>
                <td><b>TOTAL AMOUNT (IDR)</b></td>
                <td><b>INVOICE NO</b></td>
            </tr>
        </thead>
        <tbody>{tbody}</tbody>
    </table>
    """
 
    return html_str


def summarySalesTAM():
    df = mergetxtfiles()
    df = df[df['Customer'] == '100000043']
    df = df[['Invoice List', 'Delivery Date', 'Due Date', 'Qty', 'Total Amount']]

    #get the closest due date that is still bigger than today
    today = datetime.now().strftime('%Y-%m-%d')
    df = df[df['Due Date'] >= today]
    df = df[df['Due Date'] == df['Due Date'].tolist()[0]]

    # df = df.query("`Due Date` == '2024-02-28'") #Filter manual
    #modify the df
    df = df.rename(columns={'Invoice List': 'Invoice No', 'Total Amount': 'Amount'})
    df['Amount'] = df['Amount'].apply(lambda x: int(x.replace('.', '')))
    df['Qty'] = df['Qty'].apply(lambda x: int(x.replace('.', '')))
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%m.%d.%Y'))
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    df['Due Date'] = df['Due Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime('%m.%d.%Y'))
    df['Due Date'] = df['Due Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
   
    # df['Delivery Date'] = df['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%d-%b-%y'))
    # df['Due Date'] = df['Due Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime('%d-%b-%y'))
 
    print(df)
 
    #summarize the df
    grouped_df = df.groupby(['Invoice No', 'Delivery Date', 'Due Date'])[['Qty', 'Amount']].sum().reset_index()
    del df
 
    #get the sum quantity and amount
    grouped_df[['Materai', 'Total Amount']] = '-'
    grouped_df.loc[grouped_df['Amount'] > 0, 'Materai'] = 10000
    grouped_df.loc[grouped_df['Amount'] > 0, 'Total Amount'] = grouped_df['Amount'] + grouped_df['Materai']
   
    grouped_df = grouped_df[['Delivery Date', 'Due Date', 'Qty', 'Amount', 'Materai', 'Total Amount', 'Invoice No']]
 
 
    #bikin row baru untuk grouped df
    totallist = ['TOTAL DUE DATE', grouped_df['Due Date'].tolist()[0]]  #rownya terbuat dari list yg mengandung 2 values, total due date dan valuenya
    #add more values to this last row
    for col in ['Qty', 'Amount', 'Materai', 'Total Amount']:
        grandsum = sum(grouped_df[col].values.tolist())
        totallist.append(grandsum)
    totallist.append(None)
   
    grouped_df.loc[len(grouped_df)] = totallist

    #merge with PRN
    prndf = getPRN(100000043)
    lastrowdf = grouped_df.loc[len(grouped_df)-1]
    prn = prndf['PRN'][prndf['Due Date'] == lastrowdf['Due Date'].strftime('%Y-%m-%d')] #cm ambil data dari column 'PRN', hasilnya itu list
    if len(prn) == 0:
        prn = '-'
    else:
        prn = prn.values.tolist()[0]    #ambil valuen prn nya
    grouped_df['Payment Reference Code'] = prn
 
    #generate the excel
    duedate = grouped_df['Due Date'].tolist()[0]
    duedate = duedate.strftime('%d-%m-%Y')
    # filename = f'Sales Confirmation TAM Due Date - {duedate}.xlsx'
    # filepath = '\\\\Adm-fs\\fin\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\TAM\\' + filename
    # grouped_df.to_excel(filepath, index=False)
    

    filename = f'Sales Confirmation TAM Due Date - {duedate}.xlsx'
    base_filepath = '\\\\Adm-fs\\fin\\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\TAM\\' + filename
    Sent_filepath='\\\\Adm-fs\\fin\\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\TAM\\Sent\\'
    

    # Cek apakah file dengan nama yang sama sudah ada di folder 'Sent'
    if os.path.exists(os.path.join(Sent_filepath, filename)):
        print(f"File '{filename}' sudah ada di folder 'Sent'. Proses penyimpanan dibatalkan.")
        return '-'
    else:
        # Lanjutkan dengan menyimpan file jika tidak ada file dengan nama yang sama
        grouped_df.to_excel(base_filepath, index=False)
        print(f"File '{filename}' berhasil disimpan di '{base_filepath}'.")
        # Set password protection for the existing workbook
        password = 'adm'  # Replace 'adm' with your desired password

        # Create Excel application object
        # excel_app = win32.gencache.EnsureDispatch('Excel.Application')
        excel_app = win32com.client.Dispatch('Excel.Application')

        # Open the workbook
        workbook = excel_app.Workbooks.Open(base_filepath)

        # Set the password for the workbook
        workbook.Password = password

        # Save and close the workbook
        workbook.Save()
        workbook.Close()
        
        return base_filepath

def summarySalesTM():
    df = mergetxtfiles()
    df = df[df['Customer'] == '100000043']
    df = df[['Invoice List', 'Delivery Date', 'Due Date', 'Qty', 'Total Amount']]

    #get the closest due date that is still bigger than today
    today = datetime.now().strftime('%Y-%m-%d')
    df = df[df['Due Date'] >= today]
    df = df[df['Due Date'] == df['Due Date'].tolist()[0]]

    # df = df.query("`Due Date` == '2024-02-28'") #Filter manual
    #modify the df
    df = df.rename(columns={'Invoice List': 'Invoice No', 'Total Amount': 'Amount'})
    df['Amount'] = df['Amount'].apply(lambda x: int(x.replace('.', '')))
    df['Qty'] = df['Qty'].apply(lambda x: int(x.replace('.', '')))
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%m.%d.%Y'))
    df['Delivery Date'] = df['Delivery Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
    df['Due Date'] = df['Due Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime('%m.%d.%Y'))
    df['Due Date'] = df['Due Date'].apply(lambda x: np.datetime64(pd.to_datetime(x)))
   
    # df['Delivery Date'] = df['Delivery Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%d-%b-%y'))
    # df['Due Date'] = df['Due Date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime('%d-%b-%y'))
 
    print(df)
 
    #summarize the df
    grouped_df = df.groupby(['Invoice No', 'Delivery Date', 'Due Date'])[['Qty', 'Amount']].sum().reset_index()
    del df
 
    #get the sum quantity and amount
    grouped_df[['Materai', 'Total Amount']] = '-'
    grouped_df.loc[grouped_df['Amount'] > 0, 'Materai'] = 10000
    grouped_df.loc[grouped_df['Amount'] > 0, 'Total Amount'] = grouped_df['Amount'] + grouped_df['Materai']
   
    grouped_df = grouped_df[['Delivery Date', 'Due Date', 'Qty', 'Amount', 'Materai', 'Total Amount', 'Invoice No']]
 
 
    #bikin row baru untuk grouped df
    totallist = ['TOTAL DUE DATE', grouped_df['Due Date'].tolist()[0]]  #rownya terbuat dari list yg mengandung 2 values, total due date dan valuenya
    #add more values to this last row
    for col in ['Qty', 'Amount', 'Materai', 'Total Amount']:
        grandsum = sum(grouped_df[col].values.tolist())
        totallist.append(grandsum)
    totallist.append(None)
   
    grouped_df.loc[len(grouped_df)] = totallist

    #merge with PRN
    prndf = getPRN(100000043)
    lastrowdf = grouped_df.loc[len(grouped_df)-1]
    prn = prndf['PRN'][prndf['Due Date'] == lastrowdf['Due Date'].strftime('%Y-%m-%d')] #cm ambil data dari column 'PRN', hasilnya itu list
    if len(prn) == 0:
        prn = '-'
    else:
        prn = prn.values.tolist()[0]    #ambil valuen prn nya
    grouped_df['Payment Reference Code'] = prn
 
    #generate the excel
    duedate = grouped_df['Due Date'].tolist()[0]
    duedate = duedate.strftime('%d-%m-%Y')
    filename = 'Sales Confirmation TAM.xlsx'
    filepath = '\\\\Adm-fs\\fin\Billing\\Report Billing\\Summary Sales Query\\Confirmation Sales\\TAM\\HTML\\' + filename
    grouped_df.to_excel(filepath, index=False)
    
    return filepath

def mergetxtfilesFP():
    df = mergetxtfiles()  
    df['File Modified Date'] = df['File Modified Date'].apply(lambda x: x.strftime('%Y-%m-%d'))
    today = datetime.now().strftime('%Y-%m-%d')
    # print(today)
    # print(df['File Modified Date'])
    df = df.loc[(df["File Modified Date"] == today)]
    print(df)

    return df

def get_filepaths(path):
    return [os.path.join(path, f) for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

def get_latestfilepath(path):
    return max(get_filepaths(path))

def get_Oldestfilepath(path):
    return min(get_filepaths(path))

def get_invoicelist(path):
    df = pd.read_excel(path)
    return df[df.columns.tolist()[0]].values.tolist()

def returnexceldata(path):
    return pd.read_excel(path)

def generateHTMLTableFromDF(df):
    print(type(df.to_html(index=False)))
    return df.to_html(index=False)


# path= r'W:\Summary Sales Query\ListE-invoice\ListEinvoiceFP020720241402.txt'
# filename='ListEinvoiceFP020720241402.txt'
def invoiceListFakturPajakOK(txtpath, filename):
    #read txt file
    with open(txtpath, 'r') as file:
        content = file.read()
    lines = content.split('\n')
    # for index, line in enumerate(lines):
    #     print(index, line)
 
    #get column for dataframe
    collist = lines[7].split('\t')
    newcol = [col.strip() for col in collist if col != '']
 
    #get data for dataframe
    mainlist = []
    for line in lines[9:-1]:
        breakline = line.split('\t')
        breakline = [val.strip() for val in breakline if val != '']
        newline = []
        for x in breakline:
            newline.append(x)
       
        if len(newline) > 0:
            mainlist.append(newline)
        del newline
 
    #create dataframe and delete duplicates from it
    df = pd.DataFrame(mainlist, columns=newcol)
    df = df.drop_duplicates()
    df = df.sort_values('Customer')

    #generate excel
    newfilename = filename.replace('.txt', '.xlsx')
    excelpath= rf'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Summary Sales Unit\List Invoice lists FP\{newfilename}'
    df.to_excel(excelpath, index=False)
 
    #remove old txt file
    os.remove(txtpath) #Remove file directory 
    return excelpath
def PRNClearing():
    prndf = pd.read_excel(prntmmindirectory)
    prndf = prndf[['Cust. Code', 'Due Date', 'PRN Number', 'Total']]
    prndf['PRN'] = None
    prndf['Grand Total'] = None

    duedate_list = set(prndf['Due Date'].values.tolist())

    for duedate in duedate_list:
        duedate = pd.to_datetime(duedate / 1e9, unit='s')
        
        prnlist = prndf['PRN Number'][prndf['Due Date'] == duedate].values.tolist()
        longprn = ''
        for prn in prnlist:
            longprn += str(prn)
        shorterprn = longprn[:15]

        index = prndf.loc[prndf['Due Date'] == duedate].index[0]
        prndf.loc[index, 'PRN'] = shorterprn

        sumlist = prndf['Total'][prndf['Due Date'] == duedate].values.tolist()
        total = 0
        for sum in sumlist:
            total += sum
        index = prndf.loc[prndf['Due Date'] == duedate].index[0]
        prndf.loc[index, 'Grand Total'] = total

    newprndf = prndf[['Cust. Code','Due Date', 'PRN', 'Grand Total']]  

    newprndf = newprndf.dropna(subset=['PRN', 'Grand Total'])
    # print(newprndf)
    return newprndf
    
def ClearingUnit():
    df=mergetxtfiles()
    df = df[['Customer','Due Date','Invoice List','Qty','Total Amount']]
    df[['Qty', 'Total Amount']] = df[['Qty', 'Total Amount']].replace('[\.,]', '', regex=True).apply(pd.to_numeric, errors='coerce')
    grouped_df = df.groupby(['Customer','Due Date','Invoice List'])[['Qty', 'Total Amount']].sum().reset_index()
    grouped_df = grouped_df.groupby(['Customer', 'Due Date']) \
                    .agg({'Invoice List': lambda x: ";".join(x), 'Qty': 'sum', 'Total Amount': 'sum'}) \
                    .reset_index()
    grouped_df['Key'] = grouped_df['Due Date'].str.replace('-', '') + grouped_df['Total Amount'].astype(str)
    grouped_df= grouped_df[['Key', 'Customer','Due Date','Invoice List','Total Amount']]
    # print(grouped_df)
    # dfprn=PRNClearing()
    # dfprn=dfprn[['Cust. Code','Due Date', 'PRN', 'Grand Total']]
    # dfprn = dfprn.rename(columns={'Cust. Code':'Customer','Grand Total':'Total Amount'})
    # merged_df = pd.merge(grouped_df, dfprn, on=['Customer', 'Due Date'], how='inner')
    # print(dfprn)
    #generate the excelcls
    filename = 'Data Sales Clearing.xlsx'
    filepath = 'W:\\Summary Sales Query\\Clearing\\' + filename
    grouped_df.to_excel(filepath, index=False)
    return grouped_df
    

def Pindahfile(Path1, Path2):
    try:
        # Check if the source file exists
        if not os.path.exists(Path1):
            raise FileNotFoundError(f"File not found: {Path1}")

        # Copy the file from Path1 to Path2
        shutil.copy(Path1, Path2)
        
        print(f"File copied from {Path1} to {Path2}")
    
    except Exception as e:
        print(f"Error: {e}")

def Dataincomingmonthly():
    dfAR=ClearingUnit()
    # print(Dfar)
    path=r'D:\Clearing Auto\Daily Incoming Report.xlsx'
    dfclearing = pd.read_excel(path)
    dfclearing = pd.read_excel(path, header=5)
    dfclearing['DATE'] = dfclearing['DATE'].astype(str)
    dfclearing['IDR'] = pd.to_numeric(dfclearing['IDR'].fillna(0), downcast='integer')
    dfclearing['Key'] =  dfclearing['DATE'].str.replace('-', '') + dfclearing['IDR'].astype(str)
    dfclearing=dfclearing[['Key','CUSTOMER','DATE','SAP','IDR']]
    print(dfclearing)
    merged_df = dfclearing.merge(dfAR, left_on='Key', right_on='Key')
    # print(merged_df)
    filename = 'Data Incoming.xlsx'
    filepath = 'W:\\Summary Sales Query\\Clearing\\' + filename
    dfclearing.to_excel(filepath, index=False)
    