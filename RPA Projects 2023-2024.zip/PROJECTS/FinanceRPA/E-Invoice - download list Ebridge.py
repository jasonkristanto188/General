import time
import pandas as pd
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC

edge_options = Options()
edge_options.add_experimental_option('detach', True)
driver = webdriver.Edge(options=edge_options)
 
def Ebridgedownloaddata():
    #simulation web
    website = 'https://tweb.toyota.co.id/E-FAKTUR/Login'
    
    driver.get(website)
    
    #enter username
    wait = WebDriverWait(driver, 5)
    usernametextbox = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/div/div[2]/form/div[1]/div[2]/input')))
    usernametextbox.send_keys('0045.epitanta')
    
    #enter password
    passwordtextbox = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/div/div[2]/form/div[2]/div[2]/input')))
    passwordtextbox.send_keys('aDm45$00')
    
    driver.maximize_window()
    
    #click login
    loginbutton = driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div[2]/div/div[2]/form/div[3]/div[2]/input')
    loginbutton.click()
    
    #click VAT IN -> click Tax Invoice List
    vatin = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/div[2]/ul/li[1]')))
    print('logged in')
    vatin.click()
    taxinvoicelist = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/div[2]/ul/li[1]/ul/li[3]/a')))
    print('VAT IN option clicked')
    taxinvoicelist.click()
    
    #wait until loading is done
    loadingdone = False
    while loadingdone is False:
        loadingimage = driver.find_element(By.XPATH, '/html/body/div[2]/div[3]')
        aria_hidden_value = loadingimage.get_attribute('aria-hidden')
    
        if aria_hidden_value == 'true':
            loadingdone = True
            print('tax invoice list option clicked')
            time.sleep(5)
    
    #select status: ALL
    statusselect = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[3]/div[1]/div/div[2]/select')))
    statusselect.click()
    allstatus = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[3]/div[1]/div/div[2]/select/option[2]')))
    print('status clicked')
    allstatus.click()
    
    #select register method: ALL
    registermethodselect = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[4]/div/div/div[2]/select')))
    print('all status clicked')
    registermethodselect.click()
    registerall = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[4]/div/div/div[2]/select/option[1]')))
    print('register method clicked')
    registerall.click()
    
    #select records / page: 500
    recordsselect = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[3]/div[2]/div[1]/div[2]/select')))
    print('register all method chosen')
    recordsselect.click()
    select500 = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[3]/div[2]/div[1]/div[2]/select/option[5]')))
    print('selecting records / page...')
    select500.click()
    
    #insert tax invoice date from
    invoicedatefrom_textinput = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[1]/div[1]/div/div[3]/div/input')))
    print('500 records / page selected')
    currentmonth = datetime.now().month
    currentyear = datetime.now().year
    if currentmonth == 1:
        pastmonth = '12'
        pastyear = str(currentyear - 1)
    
    else:
        pastmonth = currentmonth - 1
        if pastmonth < 10:
            pastmonth = '0' + str(pastmonth)
        else:
            pastmonth = str(pastmonth)
        pastyear = str(currentyear)
    
    invoicedatefrom = f'01/{pastmonth}/{pastyear}'
    invoicedatefrom_textinput.send_keys(invoicedatefrom)
    print('inserted invoice date before')
    
    #insert tax invoice date after
    invoicedateafter_textinput = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[1]/div[1]/div/div[5]/div/input')))
    invoicedateafter = datetime.now().strftime('%d/%m/%Y')
    invoicedateafter_textinput.send_keys(invoicedateafter)
    invoicedateafter_textinput.send_keys(Keys.ENTER)
    print('inserted invoice date after')
    
    #click search
    searchbutton = driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div[2]/form/div[5]/div[2]/input')
    searchbutton.click()
    time.sleep(5)
    
    #wait until loading is done
    loadingdone = False
    while loadingdone is False:
        loadingimage = driver.find_element(By.XPATH, '/html/body/div[2]/div[3]')
        aria_hidden_value = loadingimage.get_attribute('aria-hidden')
    
        if aria_hidden_value == 'true':
            loadingdone = True
            print('finished searching')
            time.sleep(5)
    
    #extract the data column
    column = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[2]/div[2]/div[1]/div/div/table/thead/tr/th[1]')))
    columns = driver.find_elements(By.XPATH, '/html/body/div[2]/div[2]/div[1]/div/div/table/thead/tr/th')
    
    columnlist = []
    for i in range(len(columns)):
        currentcol = driver.find_element(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/thead/tr/th[{i + 1}]').text
        columnlist.append(currentcol)
    
    #extract the data
    maindata = []
    rows = driver.find_elements(By.XPATH, '/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr')
    print(f'There are {len(rows)} rows of data to be extracted\n')
    for i in range(len(rows)):
        row = []
        currentrow = driver.find_elements(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[{i + 1}]/td')
        for j in range(len(currentrow)):
            data = driver.find_element(By.XPATH, f'/html/body/div[2]/div[2]/div[1]/div/div/table/tbody/tr[{i + 1}]/td[{j + 1}]').text
            row.append(data)
        maindata.append(row)
    
    df = pd.DataFrame(maindata, columns=columnlist)
    print(df)
    #generate the excel
    filename = 'List FP E-Bridge.xlsx'
    filepath = rf'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\Summary Sales Unit\List FP E-Bridge\{filename}'
    df.to_excel(filepath, index=False)

