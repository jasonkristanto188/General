from datetime import datetime
import pandas as pd
import os

def get_manifest_error():
    output_directory = r"D:\Users\jason.kristanto\Desktop\PROJECTS\FinanceRPA\Download Data Manifest Error"
    filename = 'Rekonsiliasi BMPV temp.xlsx'
    rekonsiliasi_df = pd.read_excel(os.path.join(output_directory, filename))

    sapfilter = ['UploadSucces', 'UploadSuccsesEGI', 'UploadSuccsesEGR', 'UploadSuccsesETP', 'UploadGRError']
    df_for_SAP = rekonsiliasi_df[rekonsiliasi_df['Final Check'].isin(sapfilter)]

    return df_for_SAP['Manifest'].unique()

def wait_until_file_exists(filepath):
    while not os.path.isfile(filepath):
        pass

def get_today_sap():
    return datetime.now().strftime('%d.%m.%Y')
    
def get_today():
    return datetime.now().strftime('%Y%m%d')