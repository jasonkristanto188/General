from datetime import datetime, timedelta
import pandas as pd

def gettoday_dayonly():
    today = datetime.today()
    return today.day

def getYesterday():
    current_date = datetime.now()
    yesterday = current_date - timedelta(days=1)
    yesterdayDay = yesterday.day
    yesterdayMonth = yesterday.month
    yesterdayYear = yesterday.year

    yesterdaystr = ''
    if yesterdayDay < 10:
        yesterdaystr += '0' 
    yesterdaystr += str(yesterdayDay) + '.'

    if yesterdayMonth < 10:
        yesterdaystr += '0'
    yesterdaystr += str(yesterdayMonth) + '.' + str(yesterdayYear)

    return yesterdaystr

def getCurrentMonth():
    return datetime.now().month

def getPrevMonth():
    return getCurrentMonth() - 1 if getCurrentMonth() > 1 else 12

def getmonth_3letters(month):
    month = int(month)
    if month == 1:
        return 'Jan'
    elif month == 2:
        return 'Feb'
    elif month == 3:
        return 'Mar'
    elif month == 4:
        return 'Apr'
    elif month == 5:
        return 'May'
    elif month == 6:
        return 'Jun'
    elif month == 7:
        return 'Jul'
    elif month == 8:
        return 'Aug'
    elif month == 9:
        return 'Sep'
    elif month == 10:
        return 'Oct'
    elif month == 11:
        return 'Nov'
    elif month == 12:
        return 'Dec'

def getCurrentYear():
    return datetime.now().year

def getYearOfPreviousMonth():
    return getCurrentYear() if getPrevMonth() < 12 else getCurrentYear() - 1

def getFirstDayOfMonth_SAP():
    currentmonth = getCurrentMonth()
    currentmonthstr = ''
    if currentmonth < 10:
        currentmonthstr += '0'
    currentmonthstr += str(currentmonth)

    currentyearstr = str(getCurrentYear())

    return '01.' + currentmonthstr + '.' + currentyearstr

def readlist(list):
    for x in list:
        print(x)

def minFromList(list):
    return min(list)

def maxFromList(list):
    return max(list)

def DDMMYYYY_to_YYYYMMDD(list):
    newlist = []
    for date in list:
        breakdate = date.split('.')
        year = breakdate[2]
        month = breakdate[1]
        day = breakdate[0]
        print(year, month, day)
        newdate = year + month + day
        print(newdate)
        newlist.append(newdate)
    return newlist

def minDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    mindate = min(templist)
    year = mindate[0:4]
    month = mindate[4:6]
    day = mindate[6:]

    return day + '.'+ month + '.' + year

def maxDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    maxdate = max(templist)
    year = maxdate[0:4]
    month = maxdate[4:6]
    day = maxdate[6:]

    return day + '.'+ month + '.' + year

def recreateviperxls(path):
    df = pd.read_excel(path)
 
    print(df)
    
    viperfilename = ''
    targetpath = f'D:\\Users\\rio.abdurrahman\\Downloads\\{viperfilename}.xlsx'
    df.to_excel(targetpath, index=False)

def checkGRTDLinkEmailSubject(subject):
    return True if 'PDI Report for Calya TMMIN Prod' in subject else False

def tdlinkcomparison(path1, path2):
    #from outlook
    df = pd.read_excel(path1, sheet_name='by Frame', usecols='B:L')
    newcols = df.iloc[0].values.tolist()
    df.columns = newcols
    df = df.drop(df.index[0])
    df = df.reset_index(drop=True)
    df = df.dropna(how='all')
    print(df)
 
    #from IH08
    df2 = pd.read_excel(path2, usecols='A:P')
    print(df2)
 
 
 
    #let the comparison begin
 
    #get the length of the master data (excel from outlook)
    masterlength = len(df)
 
    VLTwithVINnotyetreceived_df = df[['FrameNumber', 'PDIActualDate']][~df['FrameNumber'].isin(df2['Serial Number'])]
    VLTwithVINnotyetreceived_count = 0
    if VLTwithVINnotyetreceived_df.shape[0] > 0:
        VLTwithVINnotyetreceived_count = VLTwithVINnotyetreceived_df.shape[0]
   
    # Assuming 'df' and 'df2' are your dataframes
    merged_df = df.merge(df2[['Serial Number', 'System status']], left_on='FrameNumber', right_on='Serial Number', how='inner')
    viperdf = merged_df[['FrameNumber', 'PDIActualDate', 'System status']]
    VPHnotyetreceived_df = viperdf[viperdf['System status'] == 'AVLB']
    VPHnotyetreceived_count = 0
    if VPHnotyetreceived_df.shape[0] > 0:
        VPHnotyetreceived_count = VPHnotyetreceived_df.shape[0]
 
    #generate the message
    message = 'Total PDI: ' + str(masterlength) + ' units\n'
    message += 'Status PDI OK: ' + str(masterlength - VPHnotyetreceived_count - VLTwithVINnotyetreceived_count) + ' NIK\n'
    message += 'VPH not yet received: ' + str(VPHnotyetreceived_count) + ' NIK\n'
    if VPHnotyetreceived_count > 0:
        for index, row, in VPHnotyetreceived_df.iterrows():
            message += row['FrameNumber'] + ' || ' + row['PDIActualDate'] + '\n'
    message += 'VLT With VIN Not yet received: ' + str(VLTwithVINnotyetreceived_count) + ' NIK\n'
    if VLTwithVINnotyetreceived_count > 0:
        for index, row, in VLTwithVINnotyetreceived_df.iterrows():
            message += row['FrameNumber'] + ' || ' + row['PDIActualDate'] + '\n'
    print(message)
    return message

def split_FGW_TMMIN(file_path):

    # file_path = 'D:\\FGW\\202312050945_adm_fu_inv.txt'

    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Dictionary untuk menyimpan data berdasarkan nomor invoice
    invoice_data = {}

    for line in lines:
        # Mencari nomor invoice dalam baris
        invoice_index = line.find("UNT")
        if invoice_index != -1:
            invoice_number = line[invoice_index + 3 : invoice_index + 13].strip()

            # Menyimpan baris ke dalam dictionary berdasarkan nomor invoice
            if invoice_number not in invoice_data:
                invoice_data[invoice_number] = []

            invoice_data[invoice_number].append(line)

    # Menyimpan data ke file terpisah berdasarkan nomor invoice
    for invoice_number, data_lines in invoice_data.items():
        with open(f'D:\FGW\{invoice_number}_adm_fu_inv.txt', 'w') as output_file:
            output_file.writelines(data_lines)

def generateExcelInvoiceCreation(list2d, path):
    df = pd.DataFrame(list2d)
    df.reset_index(drop=True, inplace=True)
    df.columns = ['GR / SA Number', 'GR / SA Date', 'Status']

    currentdate = datetime.today().date()
    filename = f'grsa_invoicecreation_{currentdate}.xlsx'
    filepath = f'{path}\\{filename}'
    df.to_excel(filepath, index=False)
    return filepath

def generateExcelInvoiceInquiry(list2d, path):
    df = pd.DataFrame(list2d)
    df.reset_index(drop=True, inplace=True)
    df.columns = ['Invoice Number', 'Invoice Date', 'Total Invoice Amount', 'Invoice Status']

    currentdate = datetime.today().date()
    filename = f'grsa_invoiceinquiry_{currentdate}.xlsx'
    filepath = f'{path}\\{filename}'
    df.to_excel(filepath, index=False)
    return filepath

def cleanExcelColumnNames(dfcols):
    newdfcols = []
    for col in dfcols:
        newcol = col.strip()
        newcol = newcol.replace('\n', '')
        newdfcols.append(newcol)
    return newdfcols

def compareVISION(creationpath, inquirypath, viperpath):
    viperdf = pd.read_excel(viperpath)
    viperdf.columns = cleanExcelColumnNames(viperdf.columns.tolist())
    viperdf = viperdf[['GR No', 'Received/GR Date', 'Supplier Reference No', 'GR Qty', 'GR Status']]
    viperdf.drop(index=viperdf.index[0], axis=0, inplace=True)
 
    if creationpath is not None:
        creationdf = pd.read_excel(creationpath)

        if creationdf.shape[0] > 0:
            creationdf.columns = cleanExcelColumnNames(creationdf.columns.tolist())
            creationdf.rename(columns={'Status':'GR Status Vision'}, inplace=True)
            viperdf = viperdf.merge(creationdf, left_on='GR No', right_on='GR / SA Number', how='left')
            viperdf = viperdf.drop(columns = ['GR / SA Number', 'GR / SA Date'])
            viperdf['GR Status Vision'] = viperdf['GR Status Vision'].apply(lambda x: x.strip() if not pd.isna(x) else x)


   
    if inquirypath is not None:
        inquirydf = pd.read_excel(inquirypath)
        
        if inquirydf.shape[0] > 0:
            inquirydf.columns = cleanExcelColumnNames(inquirydf.columns.tolist())
            inquirydf.rename(columns={'Invoice Status':'Invoice Status Vision'}, inplace=True)
            viperdf = viperdf.merge(inquirydf, left_on='Supplier Reference No', right_on='Invoice Number', how='left')
            viperdf = viperdf.drop(columns = ['Invoice Number', 'Invoice Date', 'Total Invoice Amount'])
            viperdf['Invoice Status Vision'] = viperdf['Invoice Status Vision'].apply(lambda x: x.strip() if not pd.isna(x) else x)
    
    if 'GR Status Vision' not in viperdf.columns:
        viperdf['GR Status Vision'] = None
    
    if 'Invoice Status Vision' not in viperdf.columns:
        viperdf['Invoice Status Vision'] = None
    
    viperdf = viperdf.reindex(columns=['GR No', 'Received/GR Date', \
    'Supplier Reference No', 'GR Qty', 'GR Status', 'GR Status Vision', 'Invoice Status Vision'])

    for index, row, in viperdf.iterrows():
        if pd.isna(row['GR Status Vision']) and pd.isna(row['Invoice Status Vision']):
            viperdf.at[index, 'GR Status Vision'] = 'Not Yet Posted in VISION From VIPER'
            viperdf.at[index, 'Invoice Status Vision'] = 'Not Yet Posted in VISION From VIPER'
        elif row['GR Status Vision'] == 'Invoice not yet created' and pd.isna(row['Invoice Status Vision']):
            viperdf.at[index, 'Invoice Status Vision'] = 'Invoice not yet created'
        elif pd.isna(row['GR Status Vision']) and not pd.isna(row['Invoice Status Vision']):
            viperdf.at[index, 'GR Status Vision'] = 'Posted'

    currentmonth = getCurrentMonth()
    if currentmonth < 10:
        strcurrentmonth = '0' + str(currentmonth)
    else:
        strcurrentmonth = str(currentmonth)
    
    print('current month:', strcurrentmonth)
 
    currmonthdf = viperdf[viperdf['Received/GR Date'].str.split('.').str[1] == strcurrentmonth]
    print(currmonthdf)
    currmonthdf = currmonthdf[currmonthdf['Invoice Status Vision'].str.contains('Not Yet Posted in VISION From VIPER', case=False)]

    viperdf.to_excel('D:\\DataVision\\Invoice Creation\\final.xlsx', index=False)
    currmonthdf.to_excel('D:\\DataVision\\Invoice Creation\\currmonthfinal.xlsx', index=False)
    
# creationpath = "D:\\DataVision\\grsa_invoicecreation_2023-12-12.xlsx"
# creationpath = None
# inquirypath = "D:\\DataVision\\grsa_invoiceinquiry_2023-12-12.xlsx"
# inquirypath = None
# viperpath = "D:\\DataVision\\VIPER-InvoiceInquiry20231207145911826.xlsx"
# compareVISION(creationpath, inquirypath, viperpath)

def generateInvoiceListExcel(list):
    df = pd.DataFrame(list, columns=['Invoice No'])
    
    x = datetime.now()
    currentdatetime = x.strftime("%Y-%m-%d-%H%M%S")
    excelpath = f'invoicelist_{currentdatetime}.xlsx'

    df.to_excel(excelpath, index=False)
