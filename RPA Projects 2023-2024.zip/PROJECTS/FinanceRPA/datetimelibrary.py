from datetime import datetime

#day =============================

def gettoday_dayonly():
    today = datetime.today()
    return today.day

def getYesterday():
    current_date = datetime.now()
    yesterday = current_date - timedelta(days=1)
    yesterdayDay = yesterday.day
    yesterdayMonth = yesterday.month
    yesterdayYear = yesterday.year

    yesterdaystr = ''
    if yesterdayDay < 10:
        yesterdaystr += '0' 
    yesterdaystr += str(yesterdayDay) + '.'

    if yesterdayMonth < 10:
        yesterdaystr += '0'
    yesterdaystr += str(yesterdayMonth) + '.' + str(yesterdayYear)

    return yesterdaystr



#month =============================

def getCurrentMonth():
    return datetime.now().month

def getPrevMonth():
    return getCurrentMonth() - 1 if getCurrentMonth() > 1 else 12

def getNextMonth():
    return getCurrentMonth() + 1 if getCurrentMonth() < 12 else 1

def getmonth_3letters(month):
    return datetime.strptime(str(month), '%m').strftime('%b')

def intToStringMonth(month):
    monthstr = ''
    if month < 10:
        monthstr += '0'
    return monthstr + int(month) 

#year =============================

def getCurrentYear():
    return datetime.now().year

def getYearOfPreviousMonth():
    return getCurrentYear() if getPrevMonth() < 12 else getCurrentYear() - 1

def getYearOfNextMonth():
    return getCurrentYear() if getPrevMonth() < 12 else getCurrentYear() + 1 



#SAP =============================

def getFirstDayOfMonth_SAP():
    return f'01.{intToStringMonth(getCurrentMonth())}.{str(getCurrentYear())}'

def DDMMYYYY_to_YYYYMMDD(list):
    newlist = []
    for date in list:
        breakdate = date.split('.')
        year = breakdate[2]
        month = breakdate[1]
        day = breakdate[0]
        print(year, month, day)
        newdate = year + month + day
        print(newdate)
        newlist.append(newdate)
    return newlist

def minDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    mindate = min(templist)
    year = mindate[0:4]
    month = mindate[4:6]
    day = mindate[6:]

    return day + '.'+ month + '.' + year

def maxDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    maxdate = max(templist)
    year = maxdate[0:4]
    month = maxdate[4:6]
    day = maxdate[6:]

    return day + '.'+ month + '.' + year
