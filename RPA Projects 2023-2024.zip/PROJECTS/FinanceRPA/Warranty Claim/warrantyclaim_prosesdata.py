from custom_datetime import *
import pandas as pd
import numpy as np
import os

def getCombinedExcelData(mainpath):
    folders = ['QA', 'KAP', 'QSS', 'SPD']

    maindf = pd.DataFrame()
    for folder in folders:
        innerpath = rf'{mainpath}\{folder}'

        files = os.listdir(innerpath)
        excelpath = []
        for f in files:
            if '.xlsx' in f and '~' not in f:
                excelpath.append(os.path.join(innerpath, f))
        
        if len(excelpath) > 0:
            excelpath = excelpath[0]
            df = pd.read_excel(excelpath, sheet_name='Summary Claim')
            df.columns = df.iloc[5]
            df = df.iloc[6:-1, 1:]
            df.reset_index(drop=True, inplace=True)
            df['Code'] = folder

            currentMonthName = datetime.now().strftime('%b')

            maindf = pd.concat([maindf, df], ignore_index=True)
            del df

    return maindf

def getExcelData(mainpath, folder):
    innerpath = rf'{mainpath}\{folder}'

    files = os.listdir(innerpath)
    excelpath = []
    for f in files:
        if '.xlsx' in f and '~' not in f:
            excelpath.append(os.path.join(innerpath, f))
    
    if len(excelpath) > 0:
        excelpath = excelpath[0]
        df = pd.read_excel(excelpath, sheet_name='Summary Claim')
        df.columns = df.iloc[5]
        df = df.iloc[6:-1, 1:]
        df.reset_index(drop=True, inplace=True)
        df['Code'] = folder

        currentMonthName = datetime.now().strftime('%b')
        return df
    return None

def getUserInput(message):
    userinput = input(message)
    return userinput   

def clearCMD():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.sysem('clear')

def main():
    mainpath = rf'\\adm-fs\FIN\Billing\Warranty Claim\SUMMARY\{getYearOfPastMonth()}'
    maindirs = os.listdir(mainpath)

    # pastmonthstr = getMonthStr(getPastMonth())
    pastmonthstr = '02.'
    for dir in maindirs:
        if pastmonthstr in dir and 'Copy' in dir:
            excelpath = os.path.join(mainpath, dir)

    print('\nExcel path:', excelpath)

    #get data dari 4 folders berikut: QA, KAP, QSS, SPD
    qadf = getExcelData(excelpath, 'QA')
    kapdf = getExcelData(excelpath, 'KAP')
    qssdf = getExcelData(excelpath, 'QSS')
    spddf = getExcelData(excelpath, 'SPD')

    #gabung data2 yg ada menjadi 1
    maindf = qadf
    dflist = [kapdf, qssdf, spddf]
    for df in dflist:
        if len(df) > 0:
            maindf = pd.concat([maindf, df])
    maindf['Vendor Name'] = maindf['Vendor Name'].apply(lambda x: x.replace(', PT', '').replace('PT.', '').strip())

    #get master data
    masterdatacustomerpath = r"\\adm-fs\FIN\Billing\99. Master Data\Master Customer Billing\Master Data Customer_FIN.xlsx"
    masterdatacustomer = pd.read_excel(masterdatacustomerpath, sheet_name='New Data Customer Updated')
    masterdatacustomer = masterdatacustomer.iloc[:, 1:]
    masterdatacustomer['Name'] = masterdatacustomer['Name'].apply(lambda x: x.replace(', PT', '').replace('PT.', '').upper().strip())
    masterdatacustomer.reset_index(drop=True, inplace=True)
    print('\nMaster data customer:')
    print(masterdatacustomer[['Customer No.', 'Name']])

    #add column 'Customer Code' to maindf
    maindf['Customer Code'] = None 

    errorVendorName = set()
    for index, row in maindf.iterrows():
        try:
            maindf.loc[index, 'Customer Code'] = masterdatacustomer.loc[masterdatacustomer['Name'] == row['Vendor Name'].upper().strip(), 'Customer No.'].values[0]
        except:
            # print(f"\nAn error occurred at vendor: {row['Vendor Name']}")
            errorVendorName.add(row['Vendor Name'].upper())
    
    if len(errorVendorName) > 0:
        print(f'\nThere are {len(errorVendorName)} vendor name errors found. Here is the list:')
        while len(errorVendorName) > 0:
            temp = errorVendorName.pop()
            print(temp)
    

    #add column 'Date' to maindf
    maindf['Date'] = datetime.now().strftime('%d/%m/%Y')

    #add column 'GL Account' to maindf
    maindf['GL Account'] = '9990005000'

    #change column name 'Document No' to 'Description
    #change column name 'Detail Amount' to 'Subtotal'
    maindf = maindf.rename(columns={
        'Document No': 'Description',
        'Detail Amount': 'Subtotal'})

    

    maindf = maindf[['Vendor Name', 'Customer Code', 'Date', 'Description', 'GL Account', 'Subtotal', 'Code']]
    print('\nFINAL:')
    print(maindf)

    filename = f'Summary Claim {getYearOfPastMonth()}{getMonthStr(getPastMonth())}.xlsx'
    filepath = rf'{excelpath}\{filename}'

    with pd.ExcelWriter(filepath) as writer:
        maindf.to_excel(writer, sheet_name='Gab Detail', index=False)
        # qadf.to_excel(writer, sheet_name=f"QA", index=False)

        index = 1
        dflist = [qadf, kapdf, qssdf, spddf]

        for df in dflist:
            if len(df) > 0:
                amountsum = sum(df['Detail Amount'].values.tolist())
                vatsum = sum(df['Add Vat 11%'].values.tolist())
                totalsum = sum(df['Total'].values.tolist())
                finalrow = ['Grand Total', '', '', '', '', amountsum, vatsum, totalsum, '', '', '', '']
                df.loc[len(df)] = finalrow

                if index == 1:
                    df.to_excel(writer, sheet_name=f"QA", index=False)
                    print('wrote for QA')
                elif index == 2:
                    df.to_excel(writer, sheet_name=f"KAP", index=False)
                    print('wrote for KAP')
                elif index == 3:
                    df.to_excel(writer, sheet_name=f"QSS", index=False)
                    print('wrote for QSS')
                elif index == 4:
                    df.to_excel(writer, sheet_name=f"SPD", index=False)
                    print('wrote for SPD')
                
            index += 1

        #     kapdf.to_excel(writer, sheet_name=f"KAP", index=False)
        # if len(qssdf) > 0:
        #     qssdf.to_excel(writer, sheet_name=f"QSS", index=False)
        # if len(spddf) > 0:    
        #     spddf.to_excel(writer, sheet_name=f"SPD", index=False)



if __name__ == '__main__':
    main()

