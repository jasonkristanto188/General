from custom_datetime import *
import os
import time
import fnmatch
import zipfile
import PyPDF2
import win32com.client

def getOutlookSavePath():
    mainpath = r'D:\WARRANTY CLAIM\FAKTUR PAJAK'

    directorylist = [d for d in os.listdir(mainpath) if os.path.isdir(os.path.join(mainpath, d))]
    path = rf'{mainpath}\{getCurrentYear()}'

    #create year folder if does not exist
    try:
        os.mkdir(path)
        print(f"Directory '{path}' created.")
    except FileExistsError:
        print(f"Directory '{path}' already exists.")

    monthdirlist = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    print(monthdirlist)

    targetpath = rf'{path}\{getCurrentMonthString()}. {getCurrentMonthName().upper()} {getCurrentYear()}'
    # targetpath = rf'{path}\04. APRIL 2024'
    print(targetpath)

    #create month folder if does not exist inside year folder
    try:
        os.mkdir(targetpath)
        print(f"Directory '{targetpath}' created.")
    except FileExistsError:
        print(f"Directory '{targetpath}' already exists.")

    return targetpath
        
def getOutlookEmail(targetOutlookSavePath):
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    # Get the root folder (usually the mailbox)
    root_folder = outlook.Folders["Taris.Nabillah@Daihatsu.astra.co.id"]
    folders = root_folder.Folders

    for folder in folders:
        if folder.Name == 'Inbox':
            for email in folder.Items:
                if 'Summary Warranty Claim, Part Claim, dan SSP' in email.Subject:
                    for attachment in email.Attachments:
                        attachment.SaveAsFile(os.path.join(targetOutlookSavePath, attachment.FileName))
                    break
            break
    print('\nattachments downloaded')

def extractZipFile(path):
    zipfiles = [file for file in os.listdir(path) if fnmatch.fnmatch(file, '*.zip')]

    for zip_file in zipfiles:
        fullZipPath = os.path.join(path, zip_file)
        with zipfile.ZipFile(fullZipPath, 'r') as zip_ref:
            zip_ref.extractall(path)

    return fullZipPath.replace('.zip', '')

def renameFiles(path):
    files = os.listdir(path)

    for file in files:
        filepath = os.path.join(path, file)
        with open(filepath, 'rb'):
            # Create a PDF file reader object
            pdf_reader = PyPDF2.PdfReader(filepath)
            targetpage = pdf_reader.pages[0]    #read the first page
            pagetext = targetpage.extract_text()
            lines = pagetext.split('\n')
            kodefakturpajak = file.split('-')[1]
            suppliername = lines[3].split(':')[1].strip()

            newfilename = f'FP {getCurrentMonthNameSimplified()} {getCurrentYearSimplified()} {suppliername} {kodefakturpajak}'
            # newfilename = f'FP APR 24 {suppliername} {kodefakturpajak}'

        #create year folder if does not exist
        folderpath = rf'D:\WARRANTY CLAIM\{getCurrentYear()}'
        try:
            os.mkdir(folderpath)
            print(f"Directory '{folderpath}' created.")
        except FileExistsError:
            print(f"Directory '{folderpath}' already exists.")
        
        #create month folder if does not exist
        monthname = f'{getCurrentMonthString()}. {getCurrentMonthName().upper()} {getCurrentYear()}'
        folderpath = rf'{folderpath}\{monthname}'
        try:
            os.mkdir(folderpath)
            print(f"Directory '{folderpath}' created.")
        except FileExistsError:
            print(f"Directory '{folderpath}' already exists.")
        
        #create 'Folder' folder if does not exist
        folderpath = rf'{folderpath}\Folder'
        try:
            os.mkdir(folderpath)
            print(f"Directory '{folderpath}' created.")
        except FileExistsError:
            print(f"Directory '{folderpath}' already exists.")

        #create supplier folder if does not exist
        folderpath = rf'{folderpath}\{suppliername}'
        try:
            os.mkdir(folderpath)
            print(f"Directory '{folderpath}' created.")
        except FileExistsError:
            print(f"Directory '{folderpath}' already exists.")
            
        # newfilepath = rf'{path}\{newfilename}.pdf'
        newfilepath = rf'{folderpath}\{newfilename}.pdf'
        os.rename(filepath, newfilepath)

def main():
    targetOutlookSavePath = getOutlookSavePath()
    getOutlookEmail(targetOutlookSavePath)
    time.sleep(5)
    extractedpath = extractZipFile(targetOutlookSavePath)
    renameFiles(extractedpath)



if __name__ == '__main__':
    main()
