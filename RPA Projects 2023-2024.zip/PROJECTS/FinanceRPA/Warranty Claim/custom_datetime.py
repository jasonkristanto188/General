from datetime import datetime, timedelta

def getCurrentYear():
    return datetime.now().year

def getCurrentYearSimplified():
    return datetime.now().strftime('%y')

def getCurrentMonth():
    return datetime.now().month

def getCurrentMonthString():
    if getCurrentMonth() < 10:
        return f'0{getCurrentMonth()}'
    else:
        return str(getCurrentMonth())

def getCurrentMonthName():
    return datetime.now().strftime('%B')

def getCurrentMonthNameSimplified():
    return datetime.now().strftime('%b')

def getPastMonth():
    currentmonth = datetime.now().month
    if currentmonth - 1 == 0:
        return 12
    else:
        return currentmonth - 1

def getYearOfPastMonth():
    if getPastMonth() == 12:
        return datetime.now().year - 1
    else:
        return datetime.now().year

def getMonthNameSimplified(month):
    return datetime.strptime(str(month), '%m').strftime('%b')

def getMonthStr(month):
    if month < 10:
        return f'0{month}'
    else:
        return str(month)