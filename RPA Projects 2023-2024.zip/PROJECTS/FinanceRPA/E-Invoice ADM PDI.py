import os
import shutil
import PyPDF2
import zipfile
from datetime import datetime
from RPA.Outlook.Application import Application

def encryptPDF(foldername, filename):
    pdf_file = open(os.path.join(foldername, filename), 'rb')
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    pdf_writer = PyPDF2.PdfWriter()

    # Add each page to the pdf_writer object
    for page_num in range(len(pdf_reader.pages)):
        page_obj = pdf_reader.pages[page_num]
        pdf_writer.add_page(page_obj)

    # Set the password for the new PDF
    password = 'adm'
    pdf_writer.encrypt(password)

    # newfilename = filename.replace('.pdf', '_encrypted.pdf')
    # encrypted_path = os.path.join(foldername, newfilename)
    encrypted_path = os.path.join(foldername, filename)

    # Write the new PDF to a file
    with open(encrypted_path, "wb") as f:
        pdf_writer.write(f)
    
    return encrypted_path

def send_email(attachmentpath, invoicenum):
    currentdate = datetime.now().strftime('%d %B %Y')
    shortcurrentdate = datetime.now().strftime('%d %b %Y')
    # recipientlist = ['jason.kristanto@daihatsu.astra.co.id', 'rio.abdurrahman@daihatsu.astra.co.id']
    recipientlist = ['jason.kristanto@daihatsu.astra.co.id']

    app = Application()
    app.open_application()
    app.send_email(
        recipients= recipientlist,
        subject=f'[E-Invoice ADM] PDI Date : {currentdate} - {invoicenum}',
        body=f'''
        Dear Bu Ista,\n
        Selamat siang\n
        Berikut kami lampirkan E-Invoice ADM dengan PDI Date {shortcurrentdate} 
        dengan No Invoice ${invoicenum} (attach file)\n
        Atas perhatian dan kerjasamanya kami ucapkan terima kasih\n
        Note : password attach file = adm\n\n
        Regards,\n\n
        -Ida Ramdaningsih-\n
        PT. Astra Daihatsu Motor\n
        Jl. Gaya Motor 3 No. 5 Sunter 2 - Jakarta Utara - 14330 Finance Division | Billing & Insurance Dept.\n
         : +6221-6510300, Ext : 5524
        ''',
        attachments=attachmentpath
    )

def main(directory_path):
    for foldername, subfolders, filenames in os.walk(directory_path):
        for filename in filenames:
            if filename.endswith('.pdf'):
                invoicenum = str(filename.split('_')[1])

                try:
                    #encrypt the pdf 
                    encryptedpath = encryptPDF(foldername, filename)
                except:
                    #file is already encrypted
                    print(f'{filename} already encrypted')
                    encryptedpath = os.path.join(foldername, filename)

                #send the encrypted pdf via outlook
                send_email(encryptedpath, invoicenum)
                print(f'{filename} sent via outlook')

                # #move the file to 'sent' folder
                # newfoldername = foldername + '\\Sent'
                # destinationpath = os.path.join(newfoldername, filename)
                # shutil.move(encryptedpath, newfoldername)
                # print(f'{filename} moved to "Sent" folder')
                print()

# if __name__ == '__main__':
#     directory_path = r'D:\Users\jason.kristanto\OneDrive - daihatsu.astra.co.id\RPA Finance\TMMIN'

#     main(directory_path)

