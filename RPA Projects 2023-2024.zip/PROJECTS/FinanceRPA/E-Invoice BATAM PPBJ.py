import os
import re
import math
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from openpyxl import load_workbook
import win32com.client
import shutil

TAXRPT = r'\\Adm-fs\fin\Billing\Report Billing\Unit\Download Invoices\AI DSO\PPBJ\AI BATAM\AI BATAM.xlsx'
Dataluxury = r'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\AI - BATAM\Data Luxury TAX\ALL.xlsx'

def Rekonppbj():
    dftaxrpt = pd.read_excel(TAXRPT)
    # print(dftaxrpt)

    dfLuxury = pd.read_excel(Dataluxury)
    dftaxrpt = dftaxrpt[['Customer No','Billing Date', 'Billing No.','Material No.','NIK','Description','Engine', 'Harga Jual', 'Faktur  No']]
    # dftaxrpt['Material No.'].fillna(0, inplace=True)
    # dftaxrpt['Material No.'] = dftaxrpt['Material No.'].astype('object')
    # print(dftaxrpt.dtypes)
    dfLuxury = dfLuxury[['HS Code', 'Remarks', 'tarif PPN', 'Tarif PPNBM', 'Finish Unit No.']]
    # dfLuxury['Finish Unit No.'] = dfLuxury['Finish Unit No.'].astype('object')
    # print(dfLuxury.dtypes)
    mergeddf = pd.merge(dftaxrpt, dfLuxury, left_on='Material No.', right_on='Finish Unit No.')
    mergeddf['Customer No'] = mergeddf['Customer No'].apply(lambda x: int(x))
    mergeddf['Billing Date'] = mergeddf['Billing Date'].apply(lambda x: datetime.strptime(x, '%d.%m.%Y').strftime('%Y-%m-%d'))
    mergeddf[['Color','Tahun','Isi Silinder','Bahan Bakar','Nett Weight','Gross Weight','Measurement']] = None
    mergeddf['Jumlah Kemasan'] = 1
    mergeddf['Jenis Kemasan'] = 'NE - Unpackages'
    mergeddf = mergeddf[['Customer No','Billing Date','Material No.','HS Code','NIK','Description','Engine','Harga Jual','Faktur  No','Remarks','Color','Tahun','Isi Silinder','Bahan Bakar','tarif PPN','Tarif PPNBM','Nett Weight','Gross Weight','Measurement','Jumlah Kemasan','Jenis Kemasan']]
    mergeddf = mergeddf.rename(columns={'Remarks': 'Model Name','HS Code':'HS CODE','Faktur  No':'Faktur  No'})
    # print(mergeddf)
    # print(mergeddf.info())

    tamdf = mergeddf[mergeddf['Customer No'] == 100000043]
    aibatamdf = mergeddf[mergeddf['Customer No'] == 100000044]
    del dftaxrpt, dfLuxury, mergeddf

    columnsToDrop = ['Customer No']
    tamdf.drop(columns=columnsToDrop, axis=1, inplace=True)
    aibatamdf.drop(columns=columnsToDrop, axis=1, inplace=True)

    # print(tamdf.info())
    # print(aibatamdf.info())

    maxdatetam = datetime.strptime(max(tamdf['Billing Date'].tolist()), '%Y-%m-%d').strftime('%d %b %y')
    mindatetam = datetime.strptime(min(tamdf['Billing Date'].tolist()), '%Y-%m-%d').strftime('%d %b %y')
    datenaming_tam = f'Data_kebutuhan_PPBJ_ADM_CBU {mindatetam} - {maxdatetam}'
    print(datenaming_tam)

    maxdateaibatam = datetime.strptime(max(aibatamdf['Billing Date'].tolist()), '%Y-%m-%d').strftime('%d %b %y')
    mindateaibatam = datetime.strptime(min(aibatamdf['Billing Date'].tolist()), '%Y-%m-%d').strftime('%d %b %y')
    datenaming_aibatam = f'Data_kebutuhan_PPBJ_ADM_CBU {mindateaibatam} - {maxdateaibatam}'
    print(datenaming_aibatam)

    filepath = rf'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\TAM\List PTBJ TAM\{datenaming_tam}.xlsx'
    filepath2 = rf'D:\Users\Rio.Abdurrahman\OneDrive - daihatsu.astra.co.id\AI - BATAM\List PTBJ AI DSO\{datenaming_aibatam}.xlsx'
    tamdf.to_excel(filepath, index=False)
    aibatamdf.to_excel(filepath2, index=False)

def maxBillingDate(list):
    return max(list)

def minBillingDate(list):
    return min(list)