from transferbudget import *

bplist = get_bp_num_list()
print(bplist)
