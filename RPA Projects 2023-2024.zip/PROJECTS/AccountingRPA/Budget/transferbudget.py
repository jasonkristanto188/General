from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
# from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd

edge_options = Options()
# chrome_options = Options()
# edge_options.add_experimental_option("detach", True)

def checkSubstring(substr, str):
    return True if substr in str else False

def get_bp_num_list():
    driver = webdriver.Edge(options=edge_options)
    driver.maximize_window()
    
    website = 'https://appworks.daihatsu.astra.co.id/home/ADM/app/start/web'
    driver.get(website) #run website

    wait = WebDriverWait(driver, 60)    #set fixed time buat nunggu websitenya load

    rows = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div[1]')))
    rows = driver.find_elements(By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div')
    
    bpnumlist = []
    for i in range(0, len(rows)):
        currentindex = i + 1
        currentrow = wait.until(EC.visibility_of_element_located((By.XPATH, f'/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div[{currentindex}]')))
        currentrow.click()

        bpnum = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-column[1]/layout-zone/layout-tabs/div/div[1]/section/layout-panel/panel-parent-container/panel-container/div/form-template/div/div/div/div[9]/adjustable-container/div/div[2]/form-template/div/div/div/div[1]/nested-grid-container/div/results-grid/div/div/div/div/div[4]/div[2]/div/div[3]/div/div/div'))).text
        bpnumlist.append(bpnum)

        driver.back()

    driver.quit()
    
    return bpnumlist

def claim_bp(list2d):
    df = pd.DataFrame(list2d)
    df.columns = ['BP No', 'Status']

    driver = webdriver.Edge(options=edge_options)
    driver.maximize_window()
    
    website = 'https://appworks.daihatsu.astra.co.id/home/ADM/app/start/web'
    driver.get(website) #run website

    wait = WebDriverWait(driver, 60)    #set fixed time buat nunggu websitenya load

    #click hamburger button
    hamburgerbutton = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/div/div/div[1]/bs-image-button/button')))
    hamburgerbutton.click()

    #click BPE Approval
    bpeapproval = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout-drawer-menu/div[2]/div/div/div[2]/div[1]')))
    bpeapproval.click()

    #check total row
    rows = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div[1]')))
    rows = driver.find_elements(By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div')
                                           
    bpnumlist = []
    for i in range(0, len(rows)):
        currentindex = i + 1
        currentrow = wait.until(EC.visibility_of_element_located((By.XPATH, f'/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-zone/layout-panel/panel-parent-container/panel-container/results-grid/div/div/div/div[1]/div[3]/div[2]/div[{currentindex}]')))
        currentrow.click()

        bpnum = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-column[1]/layout-zone/layout-tabs/div/div[1]/section/layout-panel/panel-parent-container/panel-container/div/form-template/div/div/div/div[9]/adjustable-container/div/div[2]/form-template/div/div/div/div[1]/nested-grid-container/div/results-grid/div/div/div/div/div[4]/div[2]/div/div[3]/div/div/div'))).text
        claimable = df.loc[df['BP No'] == bpnum, 'Status']

        if claimable:
            checkbox = wait.until(EC.visibility_of_element_located((By.XPATH, f'/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-column[2]/layout-zone/layout-tabs/div/div[1]/section/layout-panel/panel-parent-container/panel-container/div/results-grid/div/div/div/div/div[3]/div[2]/div[9]/div[1]/div/div')))
            checkbox.click()

            #click claim
            claimbutton = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/router-view/div/layout/div/layout-row[2]/layout-column[2]/layout-zone/layout-tabs/div/div[1]/section/layout-panel/panel-parent-container/panel-container/div/results-grid/div/div/div/div/div[2]/div[2]/action-bar-tmp/horizontal-overflow-menu/div/div/div/bs-button[2]/button')))
            claimbutton.click()

            print('\nClaimed for', row['BP No'])

        driver.back()

    driver.quit()

