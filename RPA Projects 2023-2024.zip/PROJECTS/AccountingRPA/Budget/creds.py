import os

def getUserInput(message):
    return input(message)

def clearCMD():
    os.system('cls') if os.name == 'nt' else os.system('clear')