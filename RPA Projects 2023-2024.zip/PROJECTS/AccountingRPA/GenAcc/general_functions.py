import os
import time

def check_file_exists(filepath):
    while not os.path.isfile(filepath):
        time.sleep(1)
    
def check_substring_found(substr, str, case_sensitive=False):
    if case_sensitive:
        return True if substr in str else False
    else:
        return True if substr.lower() in str.lower() else False
