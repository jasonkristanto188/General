import os
import pandas as pd
from datetime import datetime, timedelta

currentyear = datetime.now().year
currentmonthstr = datetime.now().strftime('%m')
currentmonthname = datetime.now().strftime('%B')

folderpath = rf"\\adm-fs\ACC\ACC_BARU\Accounting\Kurs\Kurs {currentyear}\{currentmonthstr}. {currentmonthname} {currentyear}"
files = [f for f in os.listdir(folderpath) if not f.startswith('~')]
path = os.path.join(folderpath, files[-1])

def get_valid_from():
    df = pd.read_excel(path, sheet_name='RPA')
    return df['Valid From'].values[0]

def get_valid_from_shell():
    df = pd.read_excel(path, sheet_name='RPA')
    return df['SAP'].values[0]

def get_data_kurs():
    df = pd.read_excel(path, sheet_name='Sheet2')

    df.columns = df.iloc[4]
    df = df.iloc[5:, 6:]

    list = ['EUR', 'GBP', 'JPY', 'THB', 'SGD', 'USD']
    df = df[df['Mata Uang'].isin(list)]

    df.reset_index(drop=True, inplace=True)

    return df

def get_kurs_tengah_value(matauang, ratio):
    ratio = float(ratio.replace('.', ''))
    df =  get_data_kurs()
    kurstengah = df['Kurs Tengah'][df['Mata Uang'] == matauang].values[0]
    return "{:.5f}".format(float(round(kurstengah / ratio, 5))).replace('.', ',')


