from updateKurs import *

folderpath = rf"\\adm-fs\ACC\ACC_BARU\Accounting\Kurs\Kurs {currentyear}\{currentmonthstr}. {currentmonthname} {currentyear}"
files = [f for f in os.listdir(folderpath) if not f.startswith('~')]
# print(files[-1])
