from datetime import datetime
 
def getMonthString(month):
    if month < 10:
        return f'0{month}'
    return str(month)
 
def get_month_of_x_months_ago(x):
    pastXmonth = datetime.now().month - x
    while pastXmonth <= 0:
        pastXmonth += 12
    return pastXmonth
 
def get_year_of_x_months_ago(x):
    pastXmonth = datetime.now().month - x
    yearOfXMonthsAgo = datetime.now().year
    while pastXmonth <= 0:
        pastXmonth += 12
        yearOfXMonthsAgo -= 1
    return yearOfXMonthsAgo
 
def get_last_date_of_month_x(x):
    if x == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    return 30 if x in [4, 6, 9, 11] else 31
   
def get_first_date_of_prev_month():
    return f'01.{getMonthString(get_month_of_x_months_ago(1))}.{get_year_of_x_months_ago(1)}'
 
def get_last_date_of_prev_month():
    return f'{get_last_date_of_month_x(get_month_of_x_months_ago(1))}.{getMonthString(get_month_of_x_months_ago(1))}.{get_year_of_x_months_ago(1)}'

    