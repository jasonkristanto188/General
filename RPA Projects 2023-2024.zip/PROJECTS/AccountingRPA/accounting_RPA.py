import pandas as pd
import math
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

def getYesterday():
    current_date = datetime.now()
    yesterday = current_date - timedelta(days=1)
    yesterdayDay = yesterday.day
    yesterdayMonth = yesterday.month
    yesterdayYear = yesterday.year

    yesterdaystr = ''
    if yesterdayDay < 10:
        yesterdaystr += '0' 
    yesterdaystr += str(yesterdayDay) + '.'

    if yesterdayMonth < 10:
        yesterdaystr += '0'
    yesterdaystr += str(yesterdayMonth) + '.' + str(yesterdayYear)

    return yesterdaystr

def getCurrentMonth():
    return datetime.now().month

def getCurrentYear():
    return datetime.now().year

def getFirstDayOfMonth_SAP():
    currentmonth = getCurrentMonth()
    currentmonthstr = ''
    if currentmonth < 10:
        currentmonthstr += '0'
    currentmonthstr += str(currentmonth)
    
    currentyearstr = str(getCurrentYear())

    return '01.' + currentmonthstr + '.' + currentyearstr

def getLastMonthKey():
    today = datetime.today()
    first_day_of_month = datetime(today.year, today.month, 1)
    last_day_of_previous_month = first_day_of_month - timedelta(days=1)
    
    lastmonth = last_day_of_previous_month.month
    lastyear = last_day_of_previous_month.year
    return str(lastyear) + '-' + str(lastmonth)

def getLastDayOfLastMonthSAP():
    today = datetime.today()
    first_day_of_month = datetime(today.year, today.month, 1)
    last_day_of_previous_month = first_day_of_month - timedelta(days=1)
    return last_day_of_previous_month.strftime('%d.%m.%Y')

def getFirstDayOfLastMonthSAP():
    today = datetime.today()
    first_day_of_month = datetime(today.year, today.month, 1)
    last_day_of_previous_month = first_day_of_month - timedelta(days=1)
    first_day_of_previous_month = datetime(last_day_of_previous_month.year, last_day_of_previous_month.month, 1)
    return first_day_of_previous_month.strftime('%d.%m.%Y')

def getLastDayOfCurrentMonthSAP():
    today = datetime.today()
    first_day_of_month = datetime(today.year, today.month + 1, 1)
    last_day_of_previous_month = first_day_of_month - timedelta(days=1)
    first_day_of_previous_month = datetime(last_day_of_previous_month.year, last_day_of_previous_month.month, 1)
    return first_day_of_previous_month.strftime('%d.%m.%Y')

def readlist(list):
    for x in list:
        print(x)

def minFromList(list):
    return min(list)

def maxFromList(list):
    return max(list)

def DDMMYYYY_to_YYYYMMDD(date):
    breakdate = date.split('.')
    year = breakdate[2]
    month = breakdate[1]
    day = breakdate[0]
    print(year, month, day)
    newdate = year + month + day
    print(newdate)
    return newdate

def minDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    mindate = min(templist)
    year = mindate[0:4]
    month = mindate[4:6]
    day = mindate[6:]

    return day + '.'+ month + '.' + year

def maxDDMMYYYY(list):
    templist = DDMMYYYY_to_YYYYMMDD(list)
    maxdate = max(templist)
    year = maxdate[0:4]
    month = maxdate[4:6]
    day = maxdate[6:]

    return day + '.'+ month + '.' + year

def uploadFTHPython():
    url = 'https://ft.toyota.astra.co.id/RECEIVE/PROCESS'

    driver = webdriver.Edge(keep_alive=True)
    driver.get(url)

    
    username_textbox = driver.find_element(By.XPATH, '/html/body/div[1]/form/div[1]/label[1]/input')
    username_textbox.send_keys(username)
    password_textbox = driver.find_element(By.XPATH, '/html/body/div[1]/form/div[1]/label[2]/input')
    password_textbox.send_keys(password)

def manualBillingDateList(dates, qty):
    billingdates = []
    for i in range(len(dates)):
        for j in range(int(qty[i])):
            billingdates.append(dates[i])
    
    return billingdates
        
def getPurchasingDoc(path):
    df = pd.read_excel(path)
    df.drop(df.tail(1).index,inplace=True)  #drop the last row

    purchdocs = list(dict.fromkeys(df['Purchasing Document'].values.tolist()))

    grand_document_number_list = []

    for purchdoc in purchdocs:
        tempdf = df[df['Purchasing Document'] == purchdoc]
        amountlist = tempdf['Amount in Doc. Curr.'].values.tolist()

        if sum(amountlist) == 0:
            print(purchdoc)
            docnumlist = list(dict.fromkeys(tempdf['Document Number'].values.tolist()))
            # docnumlist = tempdf['Document Number'].values.tolist()

            for x in docnumlist:
                grand_document_number_list.append(int(x))

    return grand_document_number_list

def getDocHeaderText(path):
    df = pd.read_excel(path)
    df.drop(df.tail(1).index,inplace=True)  #drop the last row
    df['Amount in Doc. Curr.'] = df['Amount in Doc. Curr.'].apply(lambda x: 0 if math.isnan(x) else x)
    df['Amount in Local Currency'] = df['Amount in Local Currency'].apply(lambda x: 0 if math.isnan(x) else x)
    print(df[['Document Number', 'Amount in Doc. Curr.', 'Amount in Local Currency']])

    docheaders = list(dict.fromkeys(df['Document Header Text'].values.tolist()))

    grand_document_number_list = []

    for docheader in docheaders:
        tempdf = df[df['Document Header Text'] == docheader]
        amountlist = tempdf['Amount in Doc. Curr.'].values.tolist()
        amountinlocalcurrlist = tempdf['Amount in Local Currency'].values.tolist()

        if sum(amountlist) == 0 and (sum(amountinlocalcurrlist) <= 100 and sum(amountinlocalcurrlist) >= -100):
            # print(docheader)
            docnumlist = list(dict.fromkeys(tempdf['Document Number'].values.tolist()))
            # docnumlist = tempdf['Document Number'].values.tolist()

            for x in docnumlist:
                if not math.isnan(x):
                    print(int(x))
                    current_date = datetime.now().strftime('%d.%m.%Y')
                    currentmonth = datetime.now().month
                    templist = ['920002000', current_date, currentmonth, 'IDR']
                    templist.append(int(x))
                    grand_document_number_list.append(templist)

    newdf = pd.DataFrame(grand_document_number_list, columns=['GL', 'TGL', 'Bln', 'Curr', 'Doc'])
    print(newdf)
    
    path = r'D:\Users\Jason.Kristanto\Downloads\clearingIntransit.xlsx'
    newdf.to_excel(path, header=False, index=False)
    
    return path

def getDocumentDate(path):
    df = pd.read_excel(path)
    df.drop(df.tail(1).index,inplace=True)  #drop the last row

    purchdocs = list(set(df['Purchasing Document'].values.tolist()))

    grand_dates = []

    for purchdoc in purchdocs:
        tempdf = df[df['Purchasing Document'] == purchdoc]
        amountlist = tempdf['Amount in Doc. Curr.'].values.tolist()

        if sum(amountlist) == 0:
            for x in tempdf['Posting Date'].tolist():
                grand_dates.append(x)

    return grand_dates

def getMinDocDate(path):
    grand_dates = getDocumentDate(path)
    min_date = min(grand_dates).strftime("%Y-%m-%d")

    breakmin = min_date.split('-')
    minyear = breakmin[0]
    minmonth = breakmin[1]
    minday = breakmin[2]
    return minday + '.' + minmonth + '.' + minyear

def getMaxDocDate(path):
    grand_dates = getDocumentDate(path)
    max_date = max(grand_dates).strftime("%Y-%m-%d")

    breakmax = max_date.split('-')
    maxyear = breakmax[0]
    maxmonth = breakmax[1]
    maxday = breakmax[2]
    return maxday + '.' + maxmonth + '.' + maxyear



path = 'D:\\Users\\jason.kristanto\\Downloads\\23.01.2024.xlsx'
getDocHeaderText(path)