from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
import zipfile
import time
import os
 
def main():
    edge_options = Options()
    edge_options.add_experimental_option('detach', True)
    website = 'https://bunifikasi.pajakku.com'
    driver = webdriver.Edge(options=edge_options)
    action = ActionChains(driver)
    wait = WebDriverWait(driver, 60)
    driver.get(website)
 
    #enter username
    username = 'Sarinurhasanah'
    usernametextbox = wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="login-username"]')))
    for x in username:
        usernametextbox.send_keys(x)
        time.sleep(0.2)
    # usernametextbox.send_keys(username)

    driver.maximize_window()
 
    #enter password
    password = 'Lkjh090090'
    passwordtextbox = driver.find_element(By.XPATH, '//*[@id="login-password"]')
    for x in password:
        passwordtextbox.send_keys(x)
        time.sleep(0.2)
    # passwordtextbox.send_keys(password)
 
    #checkbox
    checkbox = driver.find_element(By.XPATH, '//*[@id="login-form"]/div[2]/div[1]/div[1]/div/label/div/i')
    checkbox.click()

    #sign in 
    signinbutton = driver.find_element(By.XPATH, '//*[@id="login-form"]/div[2]/div[2]/button')
    signinbutton.click()

    time.sleep(10)

    newwebsite = 'https://bunifikasi.pajakku.com/product/company/6557/import'
    driver.get(newwebsite)

    #click import button
    importbutton = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="auto-positioning-above Import"]')))
    driver.execute_script("arguments[0].click();", importbutton)

    #daftar SPT 
    driver.get('https://bunifikasi.pajakku.com/product/company/6557/daftar-spt')

    #check month on first row
    monthcheck = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/div/div/div/div/div/table/tbody/tr[1]/td[6]'))).text
    currentmonth = datetime.now().month

    if str(currentmonth) == monthcheck:
        #check the first row
        checkbox = driver.find_element(By.XPATH, '/html/body/div/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/div/div/div/div/div/table/tbody/tr[1]/td[1]/div/span/input')
        driver.execute_script("arguments[0].click();", checkbox)

        #then click export
        exportbutton = driver.find_element(By.XPATH, '//*[@id="auto-positioning-above Export"]')
        driver.execute_script("arguments[0].click();", exportbutton)

        #click Summary I (BP DN/LN)
        summary1label = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/span[2]/div/div/div/p[2]/div/label')))
        summary1button = driver.find_element(By.XPATH, '/html/body/span[2]/div/div/div/p[2]/div/span/input')
        driver.execute_script("arguments[0].click();", summary1button)

        #click ya
        yesbutton = driver.find_element(By.XPATH, '//*[@id="react-mpk-modal-confirm-yes"]')
        driver.execute_script("arguments[0].click();", yesbutton)

        #go to log export
        logexportlink = 'https://bunifikasi.pajakku.com/product/company/6557/log-export'
        driver.get(logexportlink)

        #click the hamburger button
        button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/div/div/div/div/div/table/tbody/tr[1]/td[3]/div/button')))
        driver.execute_script("arguments[0].click();", button)

        #click download
        downloadbutton = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/div/div/div/div/div/table/tbody/tr[1]/td[3]/div/div/ul/li[2]')))
        driver.execute_script("arguments[0].click();", downloadbutton)
        time.sleep(10)

        downloadpath = r'D:\Users\jason.kristanto\Downloads'
        files = os.listdir(downloadpath)

        for file in files:
            if 'SUMMARY' in file and '.zip' in file:
                print(file)
                zippath = os.path.join(downloadpath, file)
                with zipfile.ZipFile(zippath, 'r') as zip_ref:
                    zip_ref.extractall(downloadpath)
                break

    driver.quit()
 
if __name__ == '__main__':
    main()