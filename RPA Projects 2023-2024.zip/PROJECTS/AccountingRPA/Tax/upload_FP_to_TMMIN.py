from upload_FP_to_TMMIN_functions import *

def main():
    edge_options = Options()
    edge_options.add_experimental_option("detach", True)
    driver = webdriver.Edge(options=edge_options)
    driver.maximize_window()

    wait = WebDriverWait(driver, 60
    )

    website = 'https://tweb.toyota.co.id/E-FAKTUR/Login'
    driver.get(website)

    #insert username
    username = '0045.epitanta'
    username_textbox = wait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="UserName"]')))
    username_textbox.send_keys(username)

    #insert password
    password = 'aDm45$00'
    password_textbox = driver.find_element(By.XPATH, '//*[@id="Password"]')
    password_textbox.send_keys(password)

    #click login
    loginbutton = driver.find_element(By.XPATH, '//*[@id="LoginBtn"]')
    loginbutton.click()

    menupath = '/html/body/div[1]/div[1]/div[2]/ul/li'
    menu = wait.until(EC.visibility_of_all_elements_located((By.XPATH, menupath)))

    #click vat in -> upload vat in
    for i in range(1, len(menu) + 1):
        currentmenu_path = f'{menupath}[{i}]'
        currentmenu_text = driver.find_element(By.XPATH, f'{currentmenu_path}/a/i').text
        if 'vat in' in currentmenu_text.lower():
            vat_in_button = driver.find_element(By.XPATH, f'{currentmenu_path}/a')
            vat_in_button.click()
    
            #click upload vat in
            vat_in_menu_path = f'{currentmenu_path}/ul/li'
            vat_in_menu = wait.until(EC.visibility_of_all_elements_located((By.XPATH, vat_in_menu_path)))
            for j in range(1, len(vat_in_menu) + 1):
                current_vat_in_menu_path = f'{vat_in_menu_path}[{j}]'
                current_vat_in_menu_text = driver.find_element(By.XPATH, f'{current_vat_in_menu_path}/a/i').text
                if 'upload vat in' in current_vat_in_menu_text.lower():
                    upload_vat_in_button = driver.find_element(By.XPATH, f'{current_vat_in_menu_path}/a')
                    upload_vat_in_button.click()
                    break
            
            break
    
    




if __name__ == '__main__':
    main()