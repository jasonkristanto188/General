import os
import time
import glob
import zipfile
import pandas as pd
from datetime import datetime, timedelta

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC


import pyautogui
from openpyxl import Workbook
from openpyxl.drawing.image import Image



def getDataFromBeaCukai():
    currentdatetime = datetime.now().strftime('%d-%m-%Y')
    print('current date:', currentdatetime)



    website = 'https://www.beacukai.go.id/kurs.html'

    # edge_options = Options()
    # edge_options.add_experimental_option("detach", True)
    # driver = webdriver.Edge(options=edge_options)

    driver = webdriver.Edge()
    driver.get(website)
    driver.maximize_window()



    # The program is given 1 minute to find the tanggalkurs input box
    element = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div/main/div/div[2]/div/div[2]/fieldset/div/section/label/input"))
    )
    print(element)
    print('done waiting')

    tanggalkurs = driver.find_element(By.XPATH, '/html/body/div[1]/div/main/div/div[2]/div/div[2]/fieldset/div/section/label/input')
    print('tanggalkurs input box found')

    tanggalkurs.send_keys(currentdatetime)
    print(currentdatetime, 'inserted into the input box')

    submitbutton = driver.find_element(By.XPATH, '/html/body/div[1]/div/main/div/div[2]/div/div[2]/fieldset/div/button[1]')
    submitbutton.click()
    print('submitted\n\n')



    element = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[3]/div/div"))
    )

    daterange = driver.find_element(By.XPATH, '/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[2]/p/strong').text
    startingdate = daterange.split('s.d')[0]
    enddate = daterange.split('s.d')[1]

    # print('date range:', startingdate, enddate)

    currencycolumns = driver.find_elements(By.XPATH, "/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[3]/div/div")
    total_columns = len(currencycolumns)

    targetcurrencies = ['USD', 'JPY', 'THB', 'EUR']
    mainlist = []
    mainlist.append([startingdate, enddate])

    for i in range(total_columns):
        index = i + 1
        currencies = driver.find_elements(By.XPATH, f'/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[3]/div/div[{index}]/table/tbody/tr')
        currencies_found = len(currencies)          

        for j in range(currencies_found):
            index2 = j + 1
            currency = driver.find_element(By.XPATH, f'/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[3]/div/div[{index}]/table/tbody/tr[{index2}]/td[1]').text
            currency = currency.split()[1]

            if currency in targetcurrencies:
                currency_value = driver.find_element(By.XPATH, f'/html/body/div[1]/div/main/div/div[2]/div/div[3]/div/div[3]/div/div[{index}]/table/tbody/tr[{index2}]/td[4]').text

                if currency == 'USD' or currency == 'EUR':
                    currency_value = currency_value.replace(',', '').replace('.', ',')
                
                integer_part, decimal_part = currency_value.split(',')
                if len(decimal_part) > 5:
                    decimal_part = decimal_part[:5]
                # If there are less than 5 numbers after the comma, add zeros at the end
                elif len(decimal_part) < 5:
                    decimal_part = decimal_part.ljust(5, '0')

                # Combine the integer and decimal parts and return
                currency_value = integer_part + ',' + decimal_part
                mainlist.append([currency, currency_value])

    for list in mainlist:
        print(list)

    # Zoom out to 70%
    driver.execute_script("document.body.style.zoom='50%'")
    time.sleep(3)
    screenshot('webscreenshot.png')
    time.sleep(3)

    driver.quit()
    return mainlist

def screenshot(screenshotname):
    # Take a screenshot
    screenshot = pyautogui.screenshot()

    # Save the screenshot
    screenshot.save(screenshotname)

def addImagesToExcel(webimg, sapimg, startdate):
    # Create a new workbook and select the active sheet
    wb = Workbook()
    ws = wb.active

    # Load the screenshot image
    webimgimg = Image(webimg)
    sapimg = Image(sapimg)

    # Add the image to the worksheet
    ws.add_image(webimg, 'A1')

    ws.add_image(sapimg, 'B10')

    excelfilename = 'Kurs MK ' + str(startdate) + '.xlsx'

    # Save the workbook
    wb.save(excelfilename)

def getTanggalLapor():
    currentmonth = datetime.now().month
    yearval = datetime.now().year

    nextmonth = currentmonth + 1 
    if nextmonth < 10:
        monthstr = '0' + str(nextmonth)
    else:
        monthstr = str(nextmonth)
    
    if nextmonth == 1:
        yearval += 1

    tanggallapor = monthstr + '.' + str(yearval)

    return tanggallapor

def invoiceDateRange():
    main_daterange = []
    daterange = []

    newrow = True

    for i in range(7):
        currentdate = datetime.now() - timedelta(days=7)
        invoicedate = currentdate + timedelta(days=i)
        print(invoicedate)

        if currentdate.month == invoicedate.month:
            daterange.append(invoicedate.strftime("%d.%m.%Y"))
        else:
            if newrow:
                main_daterange.append(daterange)
                daterange = []
                newrow = False
            daterange.append(invoicedate.strftime("%d.%m.%Y"))
    
    main_daterange.append(daterange)

    for daterange in main_daterange:
        print(daterange)
    
    return main_daterange

def modifyExcel(path):
    df = pd.read_excel(path)
    df = df[df['Customer Name'] == 'TOYOTA MOTOR MFG. INDONESIA']
    df.to_excel(path, index=False)  #replace the old file with the new one

def updateDataFromOfficialLetter(num, name, path):
    data = {
        "num": num,
        "name": name,
        "path": path
    }

    with open('officialletterdata.json', 'w') as file:
        json.dump(data, file)

def getOfficialLetterData():
    # open the file
    with open('officialletterdata.json', 'r') as file:
        data = json.load(file)

        return data

def getOfficialLetterName():
    data = getOfficialLetterData()

    return data['name']

def checkstring(mainstr, targetstr):
    return True if targetstr in mainstr else False
    
def readHSCodeExcel(path):
    df = pd.read_excel(path)

    maincol = ''
    codecol = ''
    if 'unit' in path.lower():
        df.columns = df.iloc[5]
        df = df.iloc[6:]
        maincol = 'Finish Unit No.'
        codecol = 'HS Code'
        print(df)
    else:   #spare part
        df.columns = df.iloc[2] #set the second row as column names
        df = df.iloc[3:]  # Remove the first two rows
        maincol = 'Material'
        codecol = 'NEW HS CODE'
    
    df = df[[maincol, codecol]]
    
    df = df.dropna(how='all')
    df = df.reset_index(drop=True)  # Reset the index

    notepadlist = []
    for index, row in df.iterrows():
        line = str(row[maincol]) + '\t' + str(row[codecol])
        notepadlist.append(line)
    
    return notepadlist

def updateDataMasterSP(path):
    masterpath = r"F:\acc_tax\8. PPN\HS Code\HS CODE - RPA\HS CODE - SPARE PART\HS Code SP Master.xlsx"

    masterdf = pd.read_excel(masterpath)
    masterdf = masterdf[['Material', 'Part Name', 'NEW HS CODE']]
    print(masterdf)

    df = pd.read_excel(path)
    df.columns = df.iloc[2] #set the second row as column names
    df = df.iloc[3:]  # Remove the first two rows
    df = df[['Material', 'Part Name', 'NEW HS CODE']]

    newdf = masterdf.append(df, ignore_index=True)
    newdf.to_excel(masterpath)

def createFakturPajak():
    edge_options = Options()
    edge_options.add_experimental_option('detach', True)
    driver = webdriver.Edge(options=edge_options)
    wait = WebDriverWait(driver, 60)

    #simulation web
    website = 'https://daihatsuastracoid-my.sharepoint.com/personal/rio_abdurrahman_daihatsu_astra_co_id/_layouts/15/onedrive.aspx?FolderCTID=0x012000590F462F8E61614282851CE91AC5ACD3&OR=Teams%2DHL&CT=1708572633065&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yNDAxMDQxNzUwMyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&id=%2Fpersonal%2Frio%5Fabdurrahman%5Fdaihatsu%5Fastra%5Fco%5Fid%2FDocuments%2FSummary%20Sales%20Unit%2FInvoice%20Lists'

    driver.get(website)

    #click download
    zipdownloadbutton = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/div[1]/div/div/div/div/div/div[1]/div[5]/button/span/span/span')))
    zipdownloadbutton.click()

    driver.quit()

    #get the zip file from downloads
    downloadspath = r'D:\Users\Jason.Kristanto\Downloads'
    # Use glob to match the pattern '*.zip'
    zip_files = glob.glob(os.path.join(downloadspath, '*.zip'))

    # Now zip_files is a list of all zip files in the specified directory
    for file in zip_files:
        print(file)

    #now extract the zip file at downloads page

def test():
    #get the zip file from downloads
    downloadspath = r'D:\Users\Jason.Kristanto\Downloads'
    # Use glob to match the pattern '*.zip'
    zip_files = glob.glob(os.path.join(downloadspath, '*.zip'))

    # Now zip_files is a list of all zip files in the specified directory
    for file in zip_files:
        print(file)
