import os
import math
import glob
import string
import shutil
import pandas as pd
from datetime import datetime
import xml.etree.ElementTree as ET


def getCurrentDateTime():
    currentdatetime = datetime.now()
    return currentdatetime.strftime('%Y-%m-%d %H%M%S')

def getCurrentMonthKey():
    currentdatetime = datetime.now()
    return currentdatetime.strftime('%Y%m')

def getCurrentMonth():
    return datetime.now().month

def getMonthName(month):
    return datetime.strptime(str(month), '%m').strftime('%B')

def getCurrentMonthName():
    return getMonthName(getCurrentMonth())

def getPastMonth():
    currentmonth = datetime.now().month
    if currentmonth - 1 == 0:
        return 12
    else:
        return currentmonth - 1

def getPastMonthName():
    pastmonth = getPastMonth()
    return datetime.strptime(str(pastmonth), '%m').strftime('%B')

def getCurrentYear():
    return datetime.now().year

def getYearOfPastMonth():
    currentmonth = datetime.now().month
    if currentmonth - 1 == 0:
        return datetime.now().year - 1
    else:
        return datetime.now().year



def getFileFromOneDrive():
    directory = r'D:\Users\Sari.Nurhasanah\OneDrive - daihatsu.astra.co.id\Summary Sales Unit'

    # Get list of all files, and sort them by modified time ascending.
    files = sorted(
        (f for f in glob.glob(os.path.join(directory, '*')) if os.path.isfile(f) and 'Summary sales' in f), 
        key=os.path.getmtime
    )
    
    lastfilepath = files[-1]
    filename = lastfilepath.split('\\')[-1]
    fileyear = filename.split('-')[-1].split(' ')[0]
    filemonth = int(filename.split('-')[1])
    filemonthname = getMonthName(filemonth)
    print(fileyear, filemonth, filemonthname)

    newdestination = rf'Z:\acc_tax\7. PPH\Bukti Potong\PPH 22 OTOMOTIF\{fileyear}\{filemonth}. {filemonthname} {fileyear}\SUMMARY\{filename}'
    shutil.copy(lastfilepath, newdestination)
    print('new file copied from one drive')

def getLastInvoiceRekapSummary(path):
    rekapPPh22Otomotifpath = r"\\adm-fs\ACC\acc_tax\7. PPH\Bukti Potong\PPH 22 OTOMOTIF\Rekap PPh 22 Otomotif New.xlsx"
    # rekapPPh22Otomotifpath = r"D:\Users\jason.kristanto\Downloads\Rekap PPh 22 Otomotif Jason.xlsx"
    df = pd.read_excel(rekapPPh22Otomotifpath, sheet_name='Rekap Summary eBunifikasi 2024')
    df.columns = df.iloc[0]
    df = df.iloc[1:]
    df.reset_index(drop=True, inplace=True)
    df = df[['NO', 'NPWP', 'NAMA', 'TANGGAL', 'INVOICE', 'DPP', 'PPH 22']].dropna(subset=['NPWP'])

    return int(df['INVOICE'].values.tolist()[-1])

def getDisplaySAPData(lastinvoice):
    sapdir = r'Z:\acc_tax\7. PPH\Bukti Potong\PPH 22 OTOMOTIF\2024\4. April 2024\SAP'
    files = sorted(
        (f for f in glob.glob(os.path.join(sapdir, '*')) if os.path.isfile(f) and 'SAP' in f and '.xlsx' in f), 
        key=os.path.getmtime
    )
    sappath = files[-1] #get latest data from SAP

    # sapdir = r"D:\Users\jason.kristanto\Downloads\File download tcode display SAP.xlsx"
    # sappath = sapdir

    sapdf = pd.read_excel(sappath)
    sapdf = sapdf[['NPWP No', 'Customer Name', 'Posting Date', 'Nomor Dokumen', 'Amount Labor in IDR', 'PPh Amount in IDR']]
    sapdf = sapdf[sapdf['Nomor Dokumen'] > lastinvoice]
    sapdf['NPWP No'] = sapdf['NPWP No'].apply(lambda x: f'0{x}')
    sapdf.reset_index(drop=True, inplace=True)
    return sapdf

def getWebBunifikasiData(lastinvoice):
    webpath = r"D:\Users\jason.kristanto\Downloads\File download dari web Bubifikasi.xls"
    webdf = pd.read_excel(webpath, sheet_name='DN')
    webdf.columns = webdf.iloc[0]
    webdf = webdf.iloc[1:]
    webdf = webdf[['No Bukti Potong',
                                          'Status',
                                      'Masa Pajak',
                                     'Tahun Pajak',
                                      'Pembetulan',
                     'Tgl Pemotongan (dd/MM/yyyy)',
                                'Ber-NPWP ? (Y/N)',
                  'NPWP (tanpa format/tanda baca)',
                   'NIK (tanpa format/tanda baca)',
                                            'Nama',
                                          'Alamat',
                                      'Nomor Telp',
                                           'Email',
                                            'Tipe',
                                'Kode Objek Pajak',
                              'Nama Penandatangan',
                              'Npwp Penandatangan',
                                           'Bruto',
                                           'Tarif',
                                             'Pph',
       'Mendapatkan Fasilitas ? (N/SKB/DTP/SKT/O)',
                        'Nomor SKB/SKT/SK Lainnya',
                                'Nomor Aturan DTP',
                                        'NTPN DTP',
                                       'Referensi',
                                     'Persetujuan',
                                 'Jenis Dokumen 1',
                                 'Nomor Dokumen 1',
                               'Tanggal Dokumen 1']]

    webdf = webdf.rename(columns={'Jenis Dokumen 1': 'Jenis Dokumen',
        'Nomor Dokumen 1': 'Nomor Dokumen', 'Tanggal Dokumen 1': 'Tanggal Dokumen'})

    webdf.sort_values('Nomor Dokumen', inplace=True)
    webdf['Nomor Dokumen'] = webdf['Nomor Dokumen'].apply(lambda x: int(x) if not pd.isna(x) else x)
    webdf = webdf[webdf['Nomor Dokumen'] > lastinvoice]
    webdf.reset_index(drop=True, inplace=True)

    return webdf



def generate_alphabets(n):
    alphabets = list(string.ascii_uppercase)
    extended_alphabets = []

    for i in range(n):
        for letter in alphabets:
            for alphabet in alphabets:
                extended_alphabets.append(letter + alphabet)

    return alphabets + extended_alphabets

def getDfColumnNames(df):
    return df.columns.values.tolist()



def getColumnsForUpdateRekapSummary():
    return generate_alphabets(9)[3:9]

def getColumnsForUpdateRekap():
    return generate_alphabets(29)[0:29]
