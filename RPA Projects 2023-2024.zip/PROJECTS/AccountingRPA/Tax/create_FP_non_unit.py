from datetime import datetime

def get_month_of_x_months_ago(x):
    past_x_month = datetime.now().month - int(x)
    while past_x_month <= 0:
        past_x_month += 12
    return past_x_month
 
def get_year_of_x_months_ago(x):
    past_x_month = datetime.now().month - int(x)
    year_of_x_months_ago = datetime.now().year
    while past_x_month <= 0:
        past_x_month += 12
        year_of_x_months_ago -= 1
    return year_of_x_months_ago
 
def get_last_date_of_month_x(x):
    if int(x) == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    return 30 if int(x) in [4, 6, 9, 11] else 31


link = 'https://daihatsuastracoid-my.sharepoint.com/:f:/r/personal/mahmudin_m2_daihatsu_astra_co_id/Documents/SUMMARY%20SALES%20NON%20UNIT?csf=1&web=1&e=GiwOEt'
