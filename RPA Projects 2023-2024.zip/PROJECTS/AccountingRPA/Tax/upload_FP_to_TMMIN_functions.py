import os 
import shutil
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def get_credentials():  #this is for TAMA
    path = r'\\adm-fs\ACC\acc_tax\8. PPN\RPA\User Login sistem E-bridge TMMIN.xlsx'

    df = pd.read_excel(path)
    df['Customer'] = df['Username'].apply(lambda x: x.split('.')[0])
    return df

def checkstring(shorterstring, longerstring):
    if shorterstring in longerstring:
        return True
    else:
        return False

def listfiles(directory):
    return os.listdir(directory)

def moveFile(oldpath, newpath):
    shutil.move(oldpath, newpath)
