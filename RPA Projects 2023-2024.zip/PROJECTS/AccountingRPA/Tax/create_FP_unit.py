from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import os
import pandas as pd
from datetime import datetime

def get_invoice_no():
    edge_options = Options()
    edge_options.add_experimental_option('detach', True)
    driver = webdriver.Edge(options=edge_options)
    wait = WebDriverWait(driver, 60)

    link = 'https://daihatsuastracoid-my.sharepoint.com/:f:/r/personal/rio_abdurrahman_daihatsu_astra_co_id/Documents/Summary%20Sales%20Unit/Invoice%20Lists?csf=1&web=1&e=z1fDFi'

    driver.get(link)
    driver.maximize_window()

    rows_path = '/html/body/div[3]/div/div/div[2]/div/div/div[2]/div/div/div[1]/div[4]/cf-data-provider/cf-action-wrapper/div/div[1]/div[8]/div[2]/div'
    rows = wait.until(EC.visibility_of_all_elements_located((By.XPATH, rows_path)))

    if len(rows) == 0:
        return []
    else:
        #we only care about the topmost row
        first_row_path = f'{rows_path}[1]'

        #get the filename
        filename_path = f'{first_row_path}/div[3]/span'
        filename = driver.find_element(By.XPATH, filename_path).text
        print('filename:', filename)

        #download the file
        check_button_path = f'{first_row_path}/div[1]'
        check_button = driver.find_element(By.XPATH, check_button_path)
        check_button.click()

        #click more icon ...
        more_icon_path = '//*[@id="appRoot"]/div/div/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/div/span[1]/button[5]/span/i'
        more_icon = driver.find_element(By.XPATH, more_icon_path)
        more_icon.click()

        #click download
        download_path = '/html/body/div[5]/div/div/div/div/div/div/ul/li[2]/button/div/span'
        download_button = wait.until(EC.visibility_of_element_located((By.XPATH, download_path)))
        download_button.click()

        #wait for the download to finish
        download_directory = r'D:\Users\jason.kristanto\Downloads'
        download_path = os.path.join(download_directory, filename)
        while not os.path.isfile(download_path):
            pass

        driver.quit()

        #open the downloaded file and get the invoice list
        df = pd.read_excel(download_path)
        invoicelist = df['Invoice No'].values.tolist()

        for x in invoicelist:
            print(x)

        return invoicelist

def get_current_fiscal_year():
    fiscal_month = datetime.now().month - 3
    fiscal_year = datetime.now().year
    if fiscal_month <= 0:
        fiscal_month += 12
        fiscal_year -= 1
    
    return fiscal_year

def get_starting_billing_date():
    return f"01.{datetime.now().strftime('%m.%Y')}"

def get_last_date_of_month(month):
    if month in [4, 6, 9, 11]:
        return 30
    elif month == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    else:
        return 31

def get_ending_billing_date():
    last_date = get_last_date_of_month(datetime.now().month)
    return f"{last_date}.{datetime.now().strftime('%m.%Y')}"