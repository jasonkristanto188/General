from datetime import datetime
import pandas as pd
import math

path = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Loan\Full Data\July\LOAN 5-7 ADM 072024.xlsx"

df = pd.read_excel(path)
df_columns = df.iloc[2].tolist()
extracolumnrow = df.iloc[3]

for i in range(len(df_columns)):
    if not pd.isna(extracolumnrow[i]):
        df_columns[i] += ' ' + extracolumnrow[i]

df.columns = df_columns
df = df.iloc[4:]
df.reset_index(drop=True, inplace=True)
# print(df)

no = 0
dept = ''
for index, row in df.iterrows():
    if pd.isna(row['NO']):
        df.loc[index, 'NO'] = no
        df.loc[index, 'DEPT'] = dept
    else:
        no = row['NO']
        dept = row['DEPT'].strip()
        df.loc[index, 'DEPT'] = dept

    if 'Plant Head' in dept:
        plant = dept.split()[-1]
        df.loc[index, 'PLANT'] = f'P{plant}'
    else:
        df.loc[index, 'PLANT'] = 'HO'

df['MONTHKEY'] = datetime.now().strftime('%Y-%m')
print(df)