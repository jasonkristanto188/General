from datetime_custom import *
import pandas as pd
import os

path = r'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Loan'
mainpath = rf'{path}\Full Data'
outputpath = rf'{path}\Results'
glaccountpath = rf"{mainpath}\glaccountmaster.xlsx"

# month_ago = 1   #actual
month_ago = 5   #testing

def get_past_month():
    return get_month_of_x_months_ago(month_ago)

def get_past_year():
    return get_year_of_x_months_ago(month_ago)

def get_two_months_ago():
    return get_month_of_x_months_ago(month_ago + 1)

pastmonth = get_past_month()
doublepastmonth = get_two_months_ago()

def get_df_from_excel(path):
    return pd.read_excel(path)

def get_gl_numbers():
    gldf = get_df_from_excel(glaccountpath)
    glnumbers = list(set(gldf['GL Account'].values.tolist()))
    glnumbers.sort()
    return glnumbers

#step 1a, generates {pastmonthname}.xlsx
def merge_data_for_past_month():
    glaccountdf = pd.read_excel(glaccountpath)

    pastmonthname = datetime.strptime(str(pastmonth), '%m').strftime('%B')
    maindir = rf'{mainpath}\{pastmonthname}'
    files = os.listdir(maindir)
    maindf = pd.DataFrame()

    leading_names = ['HO', 'P1', 'P2', 'P3', 'P4', 'P5', 'LOAN']
    for file in files:
        for x in leading_names:
            if x in file and '~' not in file:
                print(file)
                filepath = os.path.join(maindir, file)

                df = pd.read_excel(filepath)
                maindf = pd.concat([maindf, df])
                break

    maindf.reset_index(drop=True, inplace=True)

    for index, row in maindf.iterrows():
        if row['KodePinjaman'] in glaccountdf['KodePjmn'].values.tolist():
            maindf.loc[index, 'GL Account'] = glaccountdf.loc[glaccountdf['KodePjmn'] == row['KodePinjaman'], 'GL Account'].values[0]
        maindf.loc[index, 'Cek Angsuran'] = row['AngsuranPer Bulan'] - (row['AngsuranExtra Payroll'] + row['AngsuranExtra Ext'] + row['AngsuranBulan Ini'])
    
    excelpath = rf'{maindir}\{pastmonthname}.xlsx'
    maindf.to_excel(excelpath, index=False)

    del maindf

    return excelpath

#step 1b
def get_path_for_double_past_month():
    doublepastmonthpastmonthname = datetime.strptime(str(doublepastmonth), '%m').strftime('%B')
    return rf'{mainpath}\{doublepastmonthpastmonthname}\{doublepastmonthpastmonthname}.xlsx'

#step 2, generates summary.xlsx
def compare_excel_files(pastmonthpath, doublepastmonthpath):
    # Read the Excel files
    pastmonthdf = pd.read_excel(pastmonthpath)
    pastmonthdf.rename(columns={'KodePjmn': 'KODEPINJAMAN'}, inplace=True)
    pastmonthdf.columns = pastmonthdf.columns.map(lambda x: x.upper())
    doublepastmonthdf = pd.read_excel(doublepastmonthpath)
    doublepastmonthdf.columns = doublepastmonthdf.columns.map(lambda x: x.upper())

    if 'MONTHKEY' not in pastmonthdf.columns:
        pastmonthstr = get_month_str(pastmonth)
        pastmonthdf['MONTHKEY'] = f'{get_year_of_x_months_ago(1)}-{pastmonthstr}'

    if 'MONTHKEY' not in doublepastmonthdf.columns:
        doublepastmonthstr = get_month_str(doublepastmonth)
        doublepastmonthdf['MONTHKEY'] = f'{get_year_of_x_months_ago(2)}-{doublepastmonthstr}'
    

    
    #filter the data
    desiredcols = ['MONTHKEY', 'KODEPINJAMAN', 'JENISPINJAMAN', 'NPK', 'NAMA KARYAWAN', 'PLANT', 'SALDOPINJAMAN']
    doublepastmonthdf = doublepastmonthdf[desiredcols]
    pastmonthdf = pastmonthdf[desiredcols]

    targetkeylist = [1010, 1015, 1016, 1030, 1090, 2190, 2170, 1025]
    doublepastmonthdf = doublepastmonthdf[doublepastmonthdf['KODEPINJAMAN'].isin(targetkeylist)]
    pastmonthdf = pastmonthdf[pastmonthdf['KODEPINJAMAN'].isin(targetkeylist)]

    print(doublepastmonthdf)
    print(pastmonthdf)
    
    #merge the data
    merged = pd.merge(doublepastmonthdf, pastmonthdf, how='outer', indicator=True)  
    merged = merged.drop(columns=['_merge'])  
    grouped = merged.groupby(['KODEPINJAMAN', 'NPK', 'NAMA KARYAWAN'])
    unique_months = grouped['MONTHKEY'].apply(lambda x: x.unique())
    unique_plants = grouped['PLANT'].apply(lambda x: x.unique())
    filteredmonths = unique_months[unique_months.apply(len) > 1]
    filteredplants = unique_plants[unique_plants.apply(len) > 1]
    merged_result = pd.merge(filteredmonths, filteredplants, left_index=True, right_index=True).reset_index()
    
    del pastmonthdf, doublepastmonthdf, grouped, unique_months, unique_plants, filteredmonths, filteredplants

    #explode the monthkey and plant values
    df_exploded = merged_result.explode('MONTHKEY').explode('PLANT')
    
    #clean and get the desired data
    finaldf = df_exploded.merge(merged, how='inner')
    finaldf['KODEPINJAMAN'] = finaldf['KODEPINJAMAN'].apply(lambda x: str(int(x)))



    #get the business area and gl account

    businessarealist = ['0450', '0451', '0452', '0453', '0454', '0455']
    finaldf['BUSINESS AREA'] = None

    glaccountdf = pd.read_excel(glaccountpath)
    glaccountdf['KodePjmn'] = glaccountdf['KodePjmn'].apply(lambda x: str(x))

    for index, row in finaldf.iterrows():

        #get the plant
        if row['PLANT'] == 'Head Office' or row['PLANT'] == 'HO':
            finaldf.loc[index, 'BUSINESS AREA'] = businessarealist[0]
        elif not pd.isna(row['PLANT']):
            fullplant = row['PLANT'].strip()
            plant = fullplant[-1]
            finaldf.loc[index, 'BUSINESS AREA'] = businessarealist[int(plant)]
        
        #get the gl account
        finaldf.loc[index, 'GL ACCOUNT'] = glaccountdf.loc[glaccountdf['KodePjmn'] == row['KODEPINJAMAN'], 'GL Account'].values[0]

    npkset = finaldf['NPK'].unique().tolist()
    for npk in npkset:
        tempdf = finaldf[finaldf['NPK'] == npk]
        tempdf.reset_index(drop=True, inplace=True)

        kodepinjamanset = tempdf['KODEPINJAMAN'].unique().tolist()
        for kode in kodepinjamanset:
            tempdf2 = tempdf[tempdf['KODEPINJAMAN'] == kode]
            if len(tempdf2) == 2:
                finaldf.loc[(finaldf['NPK'] == npk) & (finaldf['KODEPINJAMAN'] == kode), 'Validity'] = 'OK'
            else:
                finaldf.loc[(finaldf['NPK'] == npk) & (finaldf['KODEPINJAMAN'] == kode), 'Validity'] = 'NOK'

    finaldf = finaldf[['MONTHKEY', 'KODEPINJAMAN', 'JENISPINJAMAN', 'NPK', 'NAMA KARYAWAN', 'PLANT', 'BUSINESS AREA', 'SALDOPINJAMAN', 'GL ACCOUNT', 'Validity']]
    finaldf['NPK'] = finaldf['NPK'].apply(lambda x: str(int(x)) if isinstance(x, float) else x)
    finalexcelpath = rf'{outputpath}\Comparison\Comparison_{get_year_of_x_months_ago(1)}{get_month_str(pastmonth)}.xlsx'
    print(set(finaldf['BUSINESS AREA'].values.tolist()))
    finaldf.to_excel(finalexcelpath, index=False)

    return finalexcelpath

#step 3a, generates pivot____.xlsx
def getPivotHRData(excelpath):
    df = pd.read_excel(excelpath)
    df.dropna(subset=['GL Account'], inplace=True)
    df.reset_index(drop=True, inplace=True)
    df['GL Account'] = df['GL Account'].apply(lambda x: int(x))

    glset = list(set(df['GL Account'].values.tolist()))
    glset.sort()

    plantset = list(set(df['Plant'].values.tolist()))
    plantset.sort()

    mainlist = []
    for plant in plantset:
        plantdf = df[df['Plant'] == plant]

        templist = [plant]
        for gl in glset:
            gldf = plantdf[plantdf['GL Account'] == gl]
            if len(gldf) > 0:
                templist.append(gldf['SaldoPinjaman'].sum())
            else:
                templist.append(0)
        mainlist.append(templist)

    hrpivotdf = pd.DataFrame(mainlist)
    glset.insert(0, 'Plant')
    hrpivotdf.columns = glset
    hrpivotdf['Plant'] = hrpivotdf['Plant'].apply(lambda x: x.replace('Plant ', 'P'))

    filename = excelpath.split('\\')[-1]
    pivotexcelpath = excelpath.replace(filename, f'pivot_{filename}')
    hrpivotdf.to_excel(pivotexcelpath, index = False)
        
    return hrpivotdf

#step 3b
def getLastBusAreaDigit(businessArea):
    return int(businessArea[-1])

#step 3b
def generateExcelFrom2DList(list2d):
    return pd.DataFrame(list2d)

#step 3b, generates sapLoan.xlsx
def generate_TB_data(list2d):
    df = generateExcelFrom2DList(list2d)
    df = df.transpose()
    df.columns = df.iloc[0]
    df = df.iloc[1:]
    df.reset_index(drop=True, inplace=True)
    for col in df.columns:
        if col != 'Plant':
            df[col] = df[col].apply(lambda x: int(x.replace(',', '')))
    print(df)
    
    past_month_str = get_month_str(pastmonth)
    year_of_pastmonth = get_year_of_x_months_ago(pastmonth)

    df.to_excel(rf'{outputpath}\SAP Loan\sapLoan_{year_of_pastmonth}{past_month_str}.xlsx', index=False)
    
    return df

#step 3c, generates TBvsHR.xlsx
def compare_HR_TB(hrdf, tbdf):
    hrdf.columns = hrdf.columns.astype(str)
    tbdf.columns = tbdf.columns.astype(str)

    hrdf_columns = hrdf.columns.tolist()
    tbdf_columns = tbdf.columns.tolist()

    print(hrdf)
    print(tbdf)

    if len(hrdf_columns) < len(tbdf_columns):
        gl_not_found = [x for x in tbdf_columns if x not in hrdf_columns]
        for x in gl_not_found:
            hrdf[x] = 0
    elif len(hrdf_columns) > len(tbdf_columns):
        gl_not_found = [x for x in hrdf_columns if x not in tbdf_columns]
        for x in gl_not_found:
            tbdf[x] = 0

    df_diff = pd.DataFrame()
    for index, row in tbdf.iterrows():
        for col in tbdf.columns:
            if col != 'Plant':
                print(hrdf.loc[index, col])
                df_diff.loc[index, col] = row[col] - hrdf.loc[index, col]
            else:
                df_diff.loc[index, col] = row[col]

    hrdf['Source'] = 'HR'
    tbdf['Source'] = 'TB'
    df_diff['Source'] = 'TB - HR'

    emptylist = []
    for i in range(len(hrdf.columns.tolist())):
        emptylist.append('')
        
    hrdf.loc[len(hrdf)] = emptylist
    tbdf.loc[len(tbdf)] = emptylist

    tbvshrdf = pd.concat([tbdf, pd.concat([hrdf, df_diff])])
    tbvshrpath = rf'{outputpath}\TB vs HR\TBvsHR_{get_year_of_x_months_ago(1)}{get_month_str(pastmonth)}.xlsx'
    tbvshrdf.to_excel(tbvshrpath, index=False)
    del tbvshrdf

    return tbvshrpath

#step 4, summary
def summary(path, sappath):
    df = pd.read_excel(path)
    df['GL Account'] = df['GL Account'].apply(lambda x: int(x) if not pd.isna(x) else x)
    # df = df.rename(columns = {'Nama Karyawan': 'Nama', 'SaldoPinjaman': 'Balance'})
    df = df.rename(columns = {'Nama Karyawan': 'Nama'})

    sapdf = pd.read_excel(sappath)
    sapdf['Text'] = sapdf['Text'].apply(lambda x: x.strip() if not pd.isna(x) else x)
    sapdf['NPK'] = None
    sapdf['Nama'] = None
    sapdf = sapdf.rename(columns={'G/L Account': 'GL Account', 'Amount in Local Currency': 'Balance'})

    glaccountlist = [2930001000, 2930001005, 2930001007, 2930002000, 2930003000, 2930004000, 2930005000]

    # Create a Pandas Excel writer using XlsxWriter as the engine
    pastmonthstr = get_month_str(pastmonth)
    year_of_pastmonth = get_past_year()
    filepath = rf"{outputpath}\Summary Loan\Summary_Loan_{year_of_pastmonth}{pastmonthstr}.xlsx"
    writer = pd.ExcelWriter(filepath, engine='xlsxwriter')
    for gl in glaccountlist:
        #get npk from HR data
        gldf = df[df['GL Account'] == gl]
        tempdf = gldf[gldf['AngsuranExtra Ext'] != 0]
        
        gldf = gldf.rename(columns={'SaldoPinjaman': 'Balance'})
        gldf = gldf[['GL Account', 'NPK', 'Nama', 'Balance', 'Plant']]
        tempdf = tempdf.rename(columns={'AngsuranExtra Ext': 'Balance'})
        tempdf = tempdf[['GL Account', 'NPK', 'Nama', 'Balance', 'Plant']]

        npkset = set(tempdf['NPK'].values.tolist())

        #get npk from SAP data
        sapnpkset = set()
        tempsapdf = sapdf[sapdf['GL Account'] == gl]
        for index, row, in tempsapdf.iterrows():
            breaktext = row['Text'].split(' ')
            for text in breaktext:
                if text.isdigit() and (len(text) == 4 or len(text) == 5):
                    sapnpkset.add(int(text))
                    tempsapdf.loc[index, 'NPK'] = int(text)
                    break
        


        #get npks found in HR but not in SAP
        npk_not_in_sap = npkset.difference(sapnpkset)

        #list those items, if any
        not_in_sap_df = tempdf[['GL Account', 'NPK', 'Nama', 'Balance']][tempdf['NPK'].isin(npk_not_in_sap)]
        not_in_sap_df['Source'] = 'HR'



        #get npks found in HR but not in SAP
        npk_not_in_hr = sapnpkset.difference(npkset)
        
        not_in_hr_df = pd.DataFrame()
        while len(npk_not_in_hr) > 0:
            current_npk = npk_not_in_hr.pop()

            #list those items, if any
            not_in_hr_df = tempsapdf[['GL Account', 'NPK', 'Nama', 'Balance']][tempsapdf['NPK'] == current_npk]
            not_in_hr_df['Source'] = 'SAP'
        del tempsapdf

        #generate excel
        adjustmentdf = pd.concat([not_in_sap_df, not_in_hr_df], ignore_index=True)
        adjustmentdf['GL Account'] = adjustmentdf['GL Account'].apply(lambda x: str(int(x)))
        del not_in_sap_df, not_in_hr_df
        adjustmentdf.reset_index(drop=True, inplace=True)

        # Position of the dataframes in the worksheet
        df1_start_row = 0
        df1_start_col = 0
        df2_start_row = 0
        df2_start_col = 6

        # Write each dataframe to a different location in the same worksheet
        print('\nCurrent gl:', gl)
        if len(gldf) > 0:
            gldf.to_excel(writer, sheet_name=str(gl), startrow=df1_start_row, startcol=df1_start_col, index=False)
        if len(adjustmentdf) > 0:
            adjustmentdf.to_excel(writer, sheet_name=str(gl), startrow=df2_start_row, startcol=df2_start_col, index=False)
        del gldf, tempdf, adjustmentdf

    # Close the Pandas Excel writer and output the Excel file
    # writer.save()
    writer.close()
    
#step 5, journal
def get_post_key(counter):
    return 40 if counter % 2 == 0 else 50

def get_summary_data(summarypath):
    df = pd.read_excel(summarypath)
    df_sorted = df.sort_values(by=['NPK', 'GL ACCOUNT', 'MONTHKEY'])
    df_sorted.reset_index(drop=True, inplace=True)
    return df_sorted

def journal_data(summarypath):
    df = pd.read_excel(summarypath)

    df = df[df['Validity'] == 'OK']
    df.reset_index(drop=True, inplace=True)

    npkset = set(df['NPK'].values.tolist())

    mainlist = []
    for npk in npkset:
        tempdf = df[df['NPK'] == npk]

        kodepinjamanset = set(tempdf['KODEPINJAMAN'].values.tolist())
        for kode in kodepinjamanset:
            kodedf = tempdf[tempdf['KODEPINJAMAN'] == kode]

            mindf = kodedf[kodedf['MONTHKEY'] == kodedf['MONTHKEY'].min()]
            saldopinjaman = mindf['SALDOPINJAMAN'].values[0]
            start_businessarea = mindf['BUSINESS AREA'].values[0]

            maxdf = kodedf[kodedf['MONTHKEY'] == kodedf['MONTHKEY'].max()]
            end_businessarea = maxdf['BUSINESS AREA'].values[0]

            newrow = [mindf['KODEPINJAMAN'].values[0], mindf['NPK'].values[0], mindf['NAMA KARYAWAN'].values[0], start_businessarea, end_businessarea, saldopinjaman, mindf['GL ACCOUNT'].values[0]]

            mainlist.append(newrow)

    maindf = pd.DataFrame(mainlist)
    maindf.columns = ['KODEPINJAMAN', 'NPK', 'NAMA KARYAWAN', 'START B.A.', 'END B.A.', 'SALDOPINJAMAN', 'GL ACCOUNT']
    print(maindf)


    maindf.to_excel('temp_journal.xlsx', index=False)

    return maindf
