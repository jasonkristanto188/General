import os
import pandas as pd

excelpath = r''

def get_username():
    df = pd.read_excel(excelpath)
    return df['Username'].values[0]

def get_password():
    df = pd.read_excel(excelpath)
    return df['Password'].values[0]

def getUserInput(message):
    return input(message)

def clearCMD():
    os.system('cls') if os.name == 'nt' else os.system('clear')