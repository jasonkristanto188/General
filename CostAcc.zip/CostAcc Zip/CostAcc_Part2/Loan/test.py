from summaryLoan import *

# path = merge_data_for_past_month()
# df = pd.read_excel(path)
# print(set(df['Plant'].values.tolist()))
# two_months_ago_path = rf"{mainpath}\August\August.xlsx"
# past_month_path = rf"{mainpath}\September\September.xlsx"
# compare_excel_files(past_month_path, two_months_ago_path)

# pivot_hr_path = rf"{mainpath}\July\pivot_July.xlsx"
# saploan_path = rf'{mainpath}\sapLoan_202407.xlsx'
# pivot_df = get_df_from_excel(pivot_hr_path)
# saploan_df = get_df_from_excel(saploan_path)
# # compare_HR_TB(pivot_df, saploan_df)

path = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Loan\Results\Comparison\Comparison_202405.xlsx"
journal_data(path)