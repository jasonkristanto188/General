from slow_moving import * 

main_directory = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Slow Moving"
mb51path = rf"{main_directory}\SAP Download\MB51 202409.xlsx"
mb52path = rf"{main_directory}\SAP Download\MB52 202409.xlsx"
processed_mb52path = rf"{main_directory}\MB52 202409 coil pivot.xlsx"
process_data_MB51(main_directory, mb51path, processed_mb52path)
