import sys
sys.path.insert(1, r'D:\Users\jason.kristanto\Desktop\RPA Quick Files')
from datetime_custom import *
from creds import *

import time
import os
import pandas as pd

def check_substring_exists(substr, str):
    return True if substr in str else False

def check_file_exists(filepath):
    return True if os.path.isfile(filepath) else False

def wait_until_file_exists(filepath):
    while not os.path.isfile(filepath):
        time.sleep(1)

def get_batch(filepath):
    #2. Di excelnya, ambil list batch != None dimana value UoM nya KG'
    df = pd.read_excel(filepath)
    df = df[(df['Base Unit of Measure'] == 'KG') & (~pd.isna(df['Batch']))]
    df.reset_index(drop=True, inplace=True)
    # df.to_excel('check.xlsx', index=False)

    batchstr = ''
    for batch in df['Batch'].unique().tolist():
        if not pd.isna(batch):
            batchstr += f'{batch}\n'
    return batchstr

def process_data_MB52(main_directory, mb52path):
    df = pd.read_excel(mb52path)

    #4. Di excelnya, filter dan \ambil hanya yang UoM nya KG dan yang ada batchnya -> copy ke sheet baru 'coil'
    coil_df = df[(df['Base Unit of Measure'] == 'KG') & (~pd.isna(df['Batch']))]
    coil_df.reset_index(drop=True, inplace=True)
    
    #5. Tambahkan kolom quantity dan value
    coil_df.loc[:, 'Unrestricted':'Value Rets Blocked'] = coil_df.loc[:, 'Unrestricted':'Value Rets Blocked'].fillna(0)
    for index, row in coil_df.iterrows():
        batch = row['Batch'] if not pd.isna(row['Batch']) else ''
        coil_df.loc[index, 'Key'] = str(row['Material']) + '-' + batch + '-' + row['Plant']
        coil_df.loc[index, 'Quantity'] = row['Unrestricted'] + row['Transit and Transfer'] + row['Quality Inspection'] + row['Restricted-Use Stock'] + row['Blocked'] + row['Returns']
        coil_df.loc[index, 'Value'] = row['Value Unrestricted'] + row['Val. in Trans./Tfr'] + row['Value in QualInsp.'] + row['Value Restricted'] + row['Value BlockedStock'] + row['Value Rets Blocked']

    #6. Pivot key (material+batch+plant), material, batch, plant, quantitiy, value, price (value/qty)
    pivot_df = coil_df.groupby(['Key'])[['Quantity', 'Value']].sum().reset_index()
    pivot_df['Price'] = pivot_df.apply(lambda row: row['Value'] / row['Quantity'], axis=1)
    for index, row in pivot_df.iterrows():
        pivot_df.loc[index, 'Material'] = coil_df.loc[coil_df['Key'] == row['Key'], 'Material'].values[0]
        pivot_df.loc[index, 'Batch'] = coil_df.loc[coil_df['Key'] == row['Key'], 'Batch'].values[0]
        pivot_df.loc[index, 'Plant'] = coil_df.loc[coil_df['Key'] == row['Key'], 'Plant'].values[0]

    pivot_df = pivot_df[['Key', 'Material', 'Batch', 'Plant', 'Quantity', 'Value', 'Price']]

    #7 generate new excel
    filename = mb52path.split('\\')[-1].replace('.xlsx', ' coil pivot.xlsx')
    new_mb52_path = os.path.join(main_directory, filename)
    with pd.ExcelWriter(new_mb52_path, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
        coil_df.to_excel(writer, sheet_name='Coil', index=False)
        pivot_df.to_excel(writer, sheet_name='Pivot', index=False)

    while not os.path.isfile(new_mb52_path):
        pass

    return new_mb52_path

def process_data_MB51(main_directory, mb51path, mb52path):

    #7.1 get movement type data
    path = rf'{main_directory}\Movement Type Remarks.xlsx'
    mtype_remarks = pd.read_excel(path)
    mtype_remarks['Movement type'] = mtype_remarks['Movement type'].apply(lambda x: str(x))

    #7.2 add monthkey dan remarks
    mb51_df = pd.read_excel(mb51path)
    mb51_df['MonthKey'] = mb51_df['Posting Date'].apply(lambda x: x.strftime('%Y%m'))
    mb51_df['Remarks'] = mb51_df['Movement type'].apply(lambda x: mtype_remarks.loc[mtype_remarks['Movement type'] == x, 'Remarks'].values[0])

    #7.3. Pivot hanya yang movement type 101 dan 102 saja (pivot by material, batch, monthkey, quantity) , dan add kolom key (material+batch)
    #     will be used later in step 14
    pivot_101_102 = mb51_df[mb51_df['Movement type'].isin(['101', '102'])].groupby(['Material', 'Batch', 'MonthKey'])['Quantity'].sum().reset_index()
    pivot_101_102['Batch'] = pivot_101_102['Batch'].apply(lambda x: '' if pd.isna(x) else x)
    pivot_101_102['Key'] = pivot_101_102.apply(lambda row: row['Material'] + '-' + row['Batch'], axis=1)
    pivot_101_102 = pivot_101_102[['Key', 'Material', 'Batch', 'MonthKey', 'Quantity']]



    #8. Pivot lagi sheet ori by material, plant, batch, remarks (GR GI), dan monthkey --> panjang kesamping, dan add Grand Totalnya
    df = mb51_df.groupby(['Material', 'Batch', 'Plant', 'Remarks', 'MonthKey'])['Quantity'].sum().reset_index()
    full_pivot_df = df.pivot_table(index=['Material', 'Batch', 'Plant'], columns=['Remarks', 'MonthKey'], values='Quantity').reset_index()
    full_pivot_df.columns = ['_'.join(col).strip() if col[1] else col[0] for col in full_pivot_df.columns.values]
    full_pivot_df['Grand_Total'] = full_pivot_df.iloc[:, 3:].sum(axis=1)



    #9. Add key1 (material+batch+plant), key2 (material+batch)
    full_columns = full_pivot_df.columns.tolist()
    full_columns.insert(0, 'Key2')
    full_columns.insert(0, 'Key1')
    full_pivot_df['Batch'] = full_pivot_df['Batch'].apply(lambda x: '' if pd.isna(x) else x)
    full_pivot_df['Key1'] = full_pivot_df.apply(lambda row: row['Material'] + '-' + row['Batch'] + '-' + row['Plant'], axis=1)
    full_pivot_df['Key2'] = full_pivot_df.apply(lambda row: row['Material'] + '-' + row['Batch'], axis=1)
    full_pivot_df = full_pivot_df[full_columns]



    #10. Add kolom TOTAL GR, TOTAL GI, MB52 (Lookup qty nya bdsrkan key1 ke file MB52 sebelumnya)
    #10.1. Filter columns for 'GR' and 'GI'
    gr_columns = [col for col in full_pivot_df.columns if 'GR' in col]
    gi_columns = [col for col in full_pivot_df.columns if 'GI' in col]

    gr_gi_columns = [col for col in full_pivot_df.columns if 'GR' in col or 'GI' in col]
    for col in gr_gi_columns:
        full_pivot_df[col] = full_pivot_df[col].fillna(0)

    #10.2. Find the smallest 'GR' and 'GI' column names
    smallest_gr = min(gr_columns)
    smallest_gi = min(gi_columns)

    #10.3. Find the largest 'GR' and 'GI' column names
    largest_gr = max(gr_columns)
    largest_gi = max(gi_columns)
    print('largest GR:', largest_gr)
    print('largest GI:', largest_gi)

    #10.4. Add columns Total GR and Total GI  on data MB51
    full_pivot_df['Total GR'] = full_pivot_df.loc[:, smallest_gr:largest_gr].sum(axis=1)
    full_pivot_df['Total GI'] = full_pivot_df.loc[:, smallest_gi:largest_gi].sum(axis=1)
    
    #10.5 Get MB52
    mb52_df = pd.read_excel(mb52path, sheet_name='Pivot')
    
    #10.6 Add column MB52 on data MB51
    for index, row in full_pivot_df.iterrows():
        mb52_value_list = mb52_df.loc[mb52_df['Key'] == row['Key1'], 'Quantity'].values
        full_pivot_df.loc[index, 'MB52'] = mb52_value_list[0] if len(mb52_value_list) > 0 else 0

    print('Sum of Grand Total:', full_pivot_df['Grand_Total'].sum())
    print('Sum of Total GR:', full_pivot_df['Total GR'].sum())
    print('Sum of Total GI:', full_pivot_df['Total GI'].sum())
    print('Sum of MB52:', full_pivot_df['MB52'].sum())



    #11. Add kolom DIFF (Grand total-MB52), STOCK JULI (Grand Total-GR-GI), Abs= (Abs(sum(GI 6 Bulan)
    full_pivot_df['DIFF'] = full_pivot_df['Grand_Total'] - full_pivot_df['MB52']

    latest_monthkey = largest_gi.split('_')[-1]
    latest_month = int(latest_monthkey[4:])
    latest_year = int(latest_monthkey[:4])
    
    full_pivot_df[f'STOCK {latest_monthkey}'] = full_pivot_df['Grand_Total'] - full_pivot_df[largest_gr] - full_pivot_df[largest_gi]
    six_months_ago_str = ''
    six_months_ago = latest_month - 6
    six_months_ago_year = latest_year
    if six_months_ago < 0:
        six_months_ago += 12
        six_months_ago_year -= 1
    
    if six_months_ago < 10:
        six_months_ago_str += '0'
    six_months_ago_str += str(six_months_ago)
    six_months_ago_GI_col = f'2. GI_{six_months_ago_year}{six_months_ago_str}'

    full_pivot_df['ABS'] = full_pivot_df.loc[:, six_months_ago_GI_col:largest_gi].sum(axis=1).abs()

    print('Sum of DIFF:', full_pivot_df['DIFF'].sum())
    print(f'Sum of STOCK {latest_monthkey}:', full_pivot_df[f'STOCK {latest_monthkey}'].sum())
    print('Sum of ABS:', full_pivot_df['ABS'].sum())



    #12. Add kolom Remarks GI dengan formula if total GI lebih kecil dari 0 maka ada GI, dan sebaliknya
    full_pivot_df['Remarks GI'] = full_pivot_df['Total GI'].apply(lambda x: 'Ada GI' if x < 0 else 'Tidak ada GI')
    print('Ada GI:', len(full_pivot_df[full_pivot_df['Remarks GI'] == 'Ada GI']))
    print('Tidak ada GI:', len(full_pivot_df[full_pivot_df['Remarks GI'] == 'Tidak ada GI']))



    #13. Add kolom Stock = total GR + Total GI
    full_pivot_df['Stock'] = full_pivot_df.apply(lambda row: row['Total GR'] + row['Total GI'], axis=1)
    print('Sum of Stock:', full_pivot_df['Stock'].sum())



    #14. Add kolom Last GR (refer to step 7.3)
    reversed_gr_columns = gr_columns
    reversed_gr_columns.sort(reverse=True)

    for index, row in full_pivot_df.iterrows():
        monthkeys = pivot_101_102.loc[pivot_101_102['Key'] == row['Key2'], 'MonthKey']
        if len(monthkeys) > 0:
            full_pivot_df.loc[index, 'Last GR'] = max(monthkeys)
        else:
            for col in reversed_gr_columns:
                if not pd.isna(row[col]) and row[col] > 0:
                    full_pivot_df.loc[index, 'Last GR'] = col
                    break

    

    #15. create sheet baru utk data MB52 yg valuenya > 0 
    non_grgi_columns = [x for x in full_pivot_df.columns.tolist() if x not in gr_gi_columns]
    # new_df = full_pivot_df[non_grgi_columns][full_pivot_df['MB52'] > 0]
    new_df = full_pivot_df[non_grgi_columns][full_pivot_df['MB52'] > 0.99]
    new_df.reset_index(drop=True, inplace=True)

    columns_to_exclude = ['MB52', 'DIFF', 'STOCK 202410', 'ABS', 'Stock']
    new_df = new_df.drop(columns=columns_to_exclude)

    #15.1. add column price: vlookup dari mb51
    coil_pivot_df = pd.read_excel(mb52path, sheet_name='Pivot')
    new_df['Price'] = new_df['Key1'].map(coil_pivot_df.set_index('Key')['Price'])
    new_df['Total Value'] = new_df['Grand_Total'] * new_df['Price']

    #15.2. add column Slow Moving or not
    current_month = datetime.now().month
    six_months_ago = get_month_of_x_months_ago(6)
    six_months_ago_str = get_month_string(six_months_ago)
    year_of_six_months_ago = get_year_of_x_months_ago(6)
    six_months_ago_monthkey = f'{year_of_six_months_ago}{six_months_ago_str}'
    new_df['Slow Moving or not'] = new_df['Last GR'].apply(lambda x: 'Slow Moving' if x < six_months_ago_monthkey else 'Tidak Slow Moving')



    #16. pivot 
    pivot_table = pd.pivot_table(
        new_df,
        values='Total Value',
        index=['Plant', 'Remarks GI'],
        columns='Slow Moving or not',
        aggfunc='sum',
        fill_value=0
    )
    print(pivot_table)
