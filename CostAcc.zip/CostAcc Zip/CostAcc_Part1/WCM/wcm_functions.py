from datetime import datetime
import pandas as pd
import os

def get_current_month():
    return datetime.now().month

def get_current_year():
    return datetime.now().year

def get_month_str(month):
    return f'0{month}' if month < 10 else str(month)

def get_latest_date_of_month(month):
    if month in [4, 6, 9, 11]:
        return 30
    elif month == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    else:
        return 31


def wait_until_file_exists(filepath):
    while not os.path.isfile(filepath):
        pass

def check_substring(substr, str):
    return True if substr in str else False

