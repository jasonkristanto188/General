from wcm import *

maindirectory = r'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\WCM'
sap_downloads_directory = os.path.join(maindirectory, 'SAP Downloads')
mb51_path = os.path.join(sap_downloads_directory, '202411 MB51.xlsx')
ih08_path = os.path.join(sap_downloads_directory, '202411 IH08.xlsx')

# get_wcm_list(maindirectory)

pivot_mb51_excel(maindirectory, mb51_path, ih08_path)
