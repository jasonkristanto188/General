from wcm_functions import *

#1. =====================================================================

def get_start_posting_date():
    return f"01.{datetime.now().strftime('%m.%Y')}"

def get_end_posting_date():
    last_date = get_latest_date_of_month(datetime.now().month)

    return f"{last_date}.{datetime.now().strftime('%m.%Y')}"

#2. =====================================================================

def get_vin_list(maindirectory):
    path = os.path.join(maindirectory, 'List VIN WCM.xlsx')
    df = pd.read_excel(path)

    vinstr = ''
    for vin in df['VIN WCM'].values.tolist():
        vinstr += f'{vin}\n'
    
    return vinstr

#3. =====================================================================

def pivot_mb51_excel(maindirectory, mb51path, ih08path):
    #get data from MB51 and pivot it based on columns Material and Material Desc to get the sum of Quantity
    mb51_df = pd.read_excel(mb51path)
    pivot_mb51_df = mb51_df.groupby(['Material', 'Material Description'])['Quantity'].sum().reset_index()

    #get data from IH08 and pivot it
    ih08_df = pd.read_excel(ih08path)

    # Count the occurrences of each unique value in the 'Material' column
    pivot_ih08_df = ih08_df['Material'].value_counts().reset_index()
    pivot_ih08_df.columns = ['Material', 'Count']

    #get data from "Movement Finish Unit (WCM).xlsx"; sheetname: "1. Unit"
    main_sheet_name = '1. Unit'
    # unit_template_excel_path = os.path.join(maindirectory, 'Movement Finish Unit (WCM).xlsx')
    unit_excel_path = os.path.join(maindirectory, 'Movement Finish Unit (WCM) copy.xlsx')
    original_unit_data = pd.read_excel(unit_excel_path, sheet_name=main_sheet_name)

    column_no_material = original_unit_data.columns.tolist()[1] #column B
    column_AA = original_unit_data.columns.tolist()[26]
    column_export = original_unit_data.columns.tolist()[48] #column AW

    #make a copy dataframe and keep the original separated
    unit_template_df  = original_unit_data.copy()

    # for index, row in unit_template_df.iterrows():
    #     column_AA_value_list = pivot_mb51_df.loc[pivot_mb51_df['Material'] == row[column_no_material], 'Quantity'].values
    #     if len(column_AA_value_list) > 0:
    #         unit_template_df.loc[index, column_AA] = column_AA_value_list[0]
        
    #     export_value_list = pivot_ih08_df.loc[pivot_ih08_df['Material'] == row[column_no_material], 'Count'].values
    #     if len(export_value_list) > 0:
    #         unit_template_df.loc[index, column_export] = export_value_list[0]

    unit_template_df.columns = unit_template_df.iloc[6]
    unit_template_df = unit_template_df.iloc[8:, 1:]
    column_AA = unit_template_df.columns.tolist()[25]
    unit_template_df.reset_index(drop=True, inplace=True)

    for index, row in unit_template_df.iterrows():
        #update the values in column AA using data from MB51
        column_AA_value_list = pivot_mb51_df.loc[pivot_mb51_df['Material'] == row['No Material'], 'Quantity'].values
        if len(column_AA_value_list) > 0:
            unit_template_df.loc[index, column_AA] = column_AA_value_list[0]

        #update the values in column AW using data from IH08
        export_value_list = pivot_ih08_df.loc[pivot_ih08_df['Material'] == row['No Material'], 'Count'].values
        if len(export_value_list) > 0:
            unit_template_df.loc[index, 'Export'] = export_value_list[0]
    
    result_path = os.path.join(main_directory, 'result.xlsx')
    unit_template_df[['No Material', column_AA, 'Export']].to_excel(result_path, index=False)

    while not os.path.isfile(result_path):
        pass

    return result_path
