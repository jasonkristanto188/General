from acc_qcc import *

mainpath = r'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Acc QCC\Data\202407\D105'

excelfilepath1 = rf'{mainpath}\1. MC.1 202407 D104.xlsx'
excelfilepath2 = rf'{mainpath}\1. MC.1 202402 D104.xlsx'
# process_excel(excelfilepath2)
months_ago = 4
plant = 'D105'

# compare_path = compare_data(excelfilepath1, excelfilepath2, months_ago)
compare_path = rf'{mainpath}\2. Compare MC.1 202407.xlsx'
# check_DM(compare_path, months_ago, plant)

dmcheckpath = os.path.join(mainpath, '4. Potential Slow Moving 1 202407.xlsx')
mb51_path = rf'{mainpath}\5. Movement MB51 202407 D105.xlsx'
final_pivot(mb51_path, dmcheckpath, months_ago, plant)
