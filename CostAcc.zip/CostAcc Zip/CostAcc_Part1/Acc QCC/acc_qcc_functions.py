from datetime import datetime
import pandas as pd
import os

def get_month_str(month):
    return f'0{month}' if int(month) < 10 else str(month)

def get_last_date_of_month_x(x):
    if int(x) == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    return 30 if int(x) in [4, 6, 9, 11] else 31

def check_substring(string, substr):
    return True if substr in string else False

def wait_until_file_exists(filepath):
    while not os.path.isfile(filepath):
        pass

def clean_df(df):
    # Drop rows where all elements are NaN
    df.dropna(how='all', inplace=True)
    
    # Drop columns where all elements are NaN
    df.dropna(axis=1, how='all', inplace=True)

    df.reset_index(drop=True, inplace=True)

    index = 0
    col_fixed = False

    while not col_fixed:
        filtered_columns = [col for col in df.columns.tolist() if 'Unnamed:' not in col]

        if len(filtered_columns) == 0:
            df.columns = df.iloc[index]
            df = df.iloc[index + 1:]
            index += 1
        else:
            col_fixed = True
    
    df.reset_index(drop=True, inplace=True)

    return df

def remove_none_rows_and_cols(df):
    # Drop rows where all elements are NaN
    df.dropna(how='all', inplace=True)
    
    # Drop columns where all elements are NaN
    df.dropna(axis=1, how='all', inplace=True)

    df.reset_index(drop=True, inplace=True)
    return df
