from acc_qcc_functions import *

rootdir = r'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Acc QCC'
periode_path = rf'{rootdir}\Periode.xlsx'

def get_main_directory_old(months_ago, plant):
    month = get_month_of_x_months_ago(months_ago)
    monthstr = get_month_str(month)
    year = get_year_of_x_months_ago(months_ago)
    monthkey = f'{year}{monthstr}'
    
    main_directory = rf'{rootdir}\Data\{monthkey}'
    if not os.path.isdir(main_directory):
        os.mkdir(main_directory)

        while not os.path.isdir(main_directory):
            pass

    main_directory = os.path.join(main_directory, plant)
    if not os.path.isdir(main_directory):
        os.mkdir(main_directory)

        while not os.path.isdir(main_directory):
            pass
    
    return main_directory

def get_main_directory(plant):
    df = pd.read_excel(periode_path)
    month = df['month periode 2'].values[0]
    year = df['year periode 2'].values[0]

    monthstr = str(month) if month >= 10 else f'0{month}'
    monthkey = f'{year}{monthstr}'

    main_directory = rf'{rootdir}\Data\{monthkey}'
    if not os.path.isdir(main_directory):
        os.mkdir(main_directory)

        while not os.path.isdir(main_directory):
            pass

    main_directory = os.path.join(main_directory, plant)
    if not os.path.isdir(main_directory):
        os.mkdir(main_directory)

        while not os.path.isdir(main_directory):
            pass
    
    return main_directory

def get_mc1_periode_1():
    df = pd.read_excel(periode_path, sheet_name='MC1')
    month = df['month periode 1'].values[0]
    year = df['year periode 1'].values[0]

    return f'{get_month_str(month)}.{year}'

def get_mc1_periode_2():
    df = pd.read_excel(periode_path, sheet_name='MC1')
    month = df['month periode 2'].values[0]
    year = df['year periode 2'].values[0]

    return f'{get_month_str(month)}.{year}'

def get_mb51_periode_1():
    df = pd.read_excel(periode_path, sheet_name='MB51')
    month = df['month periode 1'].values[0]
    year = df['year periode 1'].values[0]

    month_periode_1 = month + 1
    year_periode_1 = year
    if month_periode_1 > 12:
        month_periode_1 = 1
        year_periode_1 += 1
    
    return f'01.{get_month_str(month)}.{year_periode_1}'

def get_mb51_periode_2():
    df = pd.read_excel(periode_path, sheet_name='MB51')
    month = df['month periode 2'].values[0]
    year = df['year periode 2'].values[0]

    return f'{get_last_date_of_month_x(month)}.{get_month_str(month)}.{year}'

def get_mb51_periode_2_monthkey():
    df = pd.read_excel(periode_path, sheet_name='MB51')
    month = df['month periode 2'].values[0]
    year = df['year periode 2'].values[0]

    return f'{year}{get_month_str(month)}'

# =================================================================================

def process_MC1(filepath):
    original_df = pd.read_excel(filepath, sheet_name='Sheet1')
    df = original_df

    #column material description dibelah 2
    df['Material Description'] = df['Material'].apply(lambda x: ' '.join(x.split()[1:]).strip())
    df['Material'] = df['Material'].apply(lambda x: x.split()[0].strip())

    #column storage location dibelah 3
    df['Area'] = df['Storage location'].apply(lambda x: x.strip().split()[0][:4])
    df['Sloc'] = df['Storage location'].apply(lambda x: x.strip().split()[0][4:8] if len(x.split()[0]) > 4 else 'BLANK')
    df['Sloc Description'] = df['Storage location'].apply(lambda x: x.strip().split()[1].strip() if len(x.split()) > 1 else 'BLANK')

    #rearrange posisi columns
    df_columns = df.columns.tolist()
    df_columns.remove('Material Description')
    df_columns.insert(2, 'Material Description')
    df_columns.remove('Area')
    df_columns.insert(3, 'Area')
    df_columns.remove('Sloc')
    df_columns.insert(4, 'Sloc')
    df_columns.remove('Sloc Description')
    df_columns.insert(5, 'Sloc Description')
    df_columns.remove('Storage location')
    df = df[df_columns]

    #rename some columns
    df = df.rename(columns={
        'ValStckVal': 'Amount', 'Val. stock': 'Quantity'
    })

    #pivot
    pivot_df = df
    pivot_df = pivot_df[pivot_df['Amount'] > 0]    #ambil Amount > 0 
    pivot_df = pivot_df[pivot_df['Quantity'] >= 0.5]    #Quantity lbh kecil dri 1 ditakeout
    pivot_df.reset_index(drop=True, inplace=True)
    
    pivot_df = pivot_df[['Material', 'Material Description', 'Area', 'Sloc', 'Sloc Description', 'Quantity', 'Amount']]
    pivot_df = pivot_df.groupby(['Material', 'Material Description', 'Area', 'Sloc', 'Sloc Description']).sum().reset_index()

    # Create a Pandas Excel writer using XlsxWriter as the engine
    with pd.ExcelWriter(filepath, engine='xlsxwriter') as writer:
        original_df.to_excel(writer, sheet_name='Sheet1', index=False)
        df.to_excel(writer, sheet_name='Sheet2', index=False)
        pivot_df.to_excel(writer, sheet_name='Sheet3', index=False)

def compare_data(excelpath, excelpath_2, plant):
    df = pd.read_excel(excelpath, sheet_name='Sheet3')
    six_months_ago_df = pd.read_excel(excelpath_2, sheet_name='Sheet3')

    monthkey_sfx = '_' + excelpath.split('\\')[-1].split()[2]
    six_months_ago_sfx = '_' + excelpath_2.split('\\')[-1].split()[2]

    merged_df = pd.merge(six_months_ago_df, df, on=['Material', 'Material Description', 'Area', 'Sloc', 'Sloc Description'], how='right', suffixes=(six_months_ago_sfx, monthkey_sfx))

    for col in merged_df.columns:
        print(col)
        merged_df[col] = merged_df[col].apply(lambda x: 0 if pd.isna(x) else x)

    merged_df_cols = merged_df.columns.tolist()
    merged_df_cols.insert(0, 'Key_10Digit')
    merged_df_cols.insert(0, 'Key_11Digit')
    merged_df_cols.insert(0, 'Key')
    for index, row in df.iterrows():
        merged_df.loc[index, 'Key'] = row['Material'] + row['Area'] + row['Sloc']
        merged_df.loc[index, 'Key_11Digit'] = row['Material'][:11] + row['Area']
        merged_df.loc[index, 'Key_10Digit'] = row['Material'][:10] + row['Area']

    merged_df = merged_df[merged_df_cols]
    merged_df['Quantity_Diff'] = merged_df[f'Quantity{monthkey_sfx}'] - merged_df[f'Quantity{six_months_ago_sfx}']
    merged_df['Amount_Diff'] = merged_df[f'Amount{monthkey_sfx}'] - merged_df[f'Amount{six_months_ago_sfx}']

    directory = get_main_directory(plant)
    filename = f"2. Compare MC.1 {get_mb51_periode_2_monthkey()}.xlsx"
    excelpath = os.path.join(directory, filename)
    merged_df.to_excel(excelpath, index=False)

    while not os.path.isfile(excelpath):
        pass

    return excelpath

def check_DM(comparisonpath, plant):
    maindf = pd.read_excel(comparisonpath)

    monthkey = get_mb51_periode_2_monthkey()
    mainpath = get_main_directory(plant)

    #ambil data DM
    # dm_directory = rf'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Acc QCC'
    # dm_file = [x for x in os.listdir(dm_directory) if x.startswith('3. Master DM Part List') and str(year) in x and monthstr in x and x.endswith('.xlsx')][0]
    # dm_path = os.path.join(dm_directory, dm_file)
    dm_path = os.path.join(dm_directory, '3. Master DM Part List.xlsx')
    df_11digit = pd.read_excel(dm_path, sheet_name='11 Digit')
    df_11digit = clean_df(df_11digit)
    df_10digit = pd.read_excel(dm_path, sheet_name='10 digit')
    df_10digit = clean_df(df_10digit)

    #data Run Out
    run_out_path = rf'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Acc QCC\3. Run Out Model {get_mb51_periode_2_monthkey()}.xlsx'
    df_run_out = pd.read_excel(run_out_path)
    df_run_out = remove_none_rows_and_cols(df_run_out)
    df_run_out.columns = df_run_out.iloc[0]
    df_run_out = df_run_out.iloc[1:, 1:]
    
    #check dengan data DM
    for index, row in maindf.iterrows():
        if row['Key_11Digit'] in df_11digit['Key'].values.tolist():
            maindf.loc[index, '11Digit_check'] = df_11digit.loc[df_11digit['Key'] == row['Key_11Digit'], 'Remarks'].values[0]
        else:
            maindf.loc[index, '11Digit_check'] = 'Tidak ada di BOM'

        if row['Key_10Digit'] in df_10digit['Key'].values.tolist():
            maindf.loc[index, '10Digit_check'] = df_10digit.loc[df_10digit['Key'] == row['Key_10Digit'], 'Remarks'].values[0]
        else:
            maindf.loc[index, '10Digit_check'] = 'Tidak ada di BOM'

        if row['Key_11Digit'] in df_run_out['Key'].values.tolist():
            maindf.loc[index, 'Run Out Model'] = df_run_out.loc[df_run_out['Key'] == row['Key_11Digit'], 'Model'].values[0]
        else:
            maindf.loc[index, 'Run Out Model'] = 'Tidak ada di Run Out Model'

    filename = f'4. Potential Slow Moving 1 {get_mb51_periode_2_monthkey()}.xlsx'
    newpath = os.path.join(mainpath, filename)
    maindf.to_excel(newpath, index=False)

    while not os.path.isfile(newpath):
        pass

    return newpath

def get_materials_not_in_BOM(path):
    maindf = pd.read_excel(path)

    #ambil material list utk digit check Tidak ada di BOM
    filtered_df = maindf[(maindf['11Digit_check'] == 'Tidak ada di BOM') & (maindf['10Digit_check'] == 'Tidak ada di BOM')]
    filtered_df.reset_index(drop=True, inplace=True)

    materiallist = filtered_df['Material'].unique().tolist()

    material_list_str = ''
    for material in materiallist:
        material_list_str += str(material) + '\n'
    
    return material_list_str

def get_excluded_movement_types():
    path = rf"{rootdir}\List movement type (exclude in MB51).xlsx"
    df = pd.read_excel(path)
    return df['Mov Type'].unique().tolist()

def merge_mb51_plant5(main_directory):
    mb51_files = [x for x in os.listdir(main_directory) if x.startswith('5. Movement MB51')]
    df = pd.DataFrame()

    for file in mb51_files:
        filepath = os.path.join(main_directory, file)
        tempdf = pd.read_excel(filepath)
        df = pd.concat([df, tempdf], ignore_index=True)
    
    return df

def final_pivot(mb51_check_path, dmcheckpath, plant):
    df = pd.read_excel(mb51_check_path)
    
    df['Storage location'] = df['Storage location'].apply(lambda x: 'BLANK' if pd.isna(x) else x)

    dmcheck_df = pd.read_excel(dmcheckpath)

    grouped_df = df.groupby(['Material', 'Plant', 'Storage location'])['Quantity'].sum().reset_index()
    for index, row in grouped_df.iterrows():
        key = f"{row['Material']}{row['Plant']}{row['Storage location']}"
        grouped_df.loc[index, 'Key'] = key
        grouped_df.loc[index, 'Check Movement'] = 'Ada movement' if key in dmcheck_df['Key'].values.tolist() else 'Tidak ada movement'

    mb51_check_path = mb51_check_path.replace('.xlsx', ' with PIVOT.xlsx')
    grouped_df.to_excel(mb51_check_path, sheet_name='Pivot', index=False)


    #add column Check Movement dan Remarks 
    for index, row in dmcheck_df.iterrows():
        if row['11Digit_check'] == 'BOM' or row['10Digit_check'] == 'BOM':
            dmcheck_df.loc[index, 'Check Movement'] = 'Tidak dicek di SAP'
        else:
            if row['Key'] in grouped_df['Key'].values.tolist():
                dmcheck_df.loc[index, 'Check Movement'] = 'Ada movement SAP'
            else:
                dmcheck_df.loc[index, 'Check Movement'] = 'Tidak ada movement SAP'
    
    condition1 = dmcheck_df['11Digit_check'] == 'Tidak ada di BOM'
    condition2 = dmcheck_df['10Digit_check'] == 'Tidak ada di BOM'
    condition3 = dmcheck_df['Check Movement'] == 'Tidak ada movement SAP'
    condition4 = dmcheck_df['Run Out Model'] != 'Tidak ada di Run Out Model'
    dmcheck_df['Remarks'] = 'No Potential Slow Moving'

    dmcheck_df.loc[(condition1 & condition2 & condition3) | condition4, 'Remarks'] = 'Potential Slow Moving'
    
    directory = get_main_directory(x_month_ago, plant)
    filename = f'6. Potential Slow Moving 2 {plant} {get_mb51_periode_2_monthkey()}.xlsx'
    filepath = os.path.join(directory, filename)
    dmcheck_df.to_excel(filepath, index=False)
