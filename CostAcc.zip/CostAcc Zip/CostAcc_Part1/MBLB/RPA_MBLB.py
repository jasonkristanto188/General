import sys
# sys.path.insert(1, r'D:\00. RPA Code')
sys.path.insert(1, r'D:\Users\jason.kristanto\Desktop\RPA Quick Files')

from datetime_custom import *
from creds import *
import time
import os
import pandas as pd

def check_substring_exists(substr, str):
    return True if substr in str else False

def wait_until_file_exists(filepath):
    while not os.path.isfile(filepath):
        time.sleep(1)

def process_excel(filepath):
    df = pd.read_excel(filepath)
    df['Material Description'] = None
    df = df[['Vendor', 'Name 1', 'City', 'Material', 'Material Description', 'Plant', 'Batch', 
             'Unrestricted', 'Base Unit of Measure', 'Total Value', 'Currency', 'District',	
             'Valuation area', 'Company Code', 'Valuation Type'
    ]]
    df.to_excel(filepath)