import os
import pandas as pd

path = r'D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\BeaMasuk\data.xlsx'

def get_username():
    df = pd.read_excel(path)
    return df['Username'].values[0]

def get_password():
    df = pd.read_excel(path)
    return df['Password'].values[0]

def get_user_input(message):
    return input(message)

def clearCMD():
    os.system('cls') if os.name == 'nt' else os.system('clear')