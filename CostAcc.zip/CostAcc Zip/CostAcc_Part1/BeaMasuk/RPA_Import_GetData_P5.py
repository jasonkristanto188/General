from datetime_custom import *
from creds import *
import pandas as pd
import shutil
import math
import time

def get_doc_header_text(path):
    df = pd.read_excel(path)
    df.drop(df.tail(1).index,inplace=True)  #drop the last row
    df.dropna(subset=['Document Header Text'], inplace=True)
    df['Amount in Doc. Curr.'] = df['Amount in Doc. Curr.'].apply(lambda x: 0 if math.isnan(x) else x)
    df['Amount in Local Currency'] = df['Amount in Local Currency'].apply(lambda x: 0 if math.isnan(x) else x)
    print(df[['Document Number', 'Amount in Doc. Curr.', 'Amount in Local Currency']])
    print(df.columns)

    # docheaders = list(dict.fromkeys(df['Document Header Text'].values.tolist()))
    docheaders = set(df['Document Header Text'].values.tolist())

    # G/L Account
    # Tanggal hari ini (DD.MM.YYYY)
    # Fiscal Month
    # Local Currency
    # Document Number
    longstr = ''
    currentdate = datetime.now().strftime('%d%m%Y')
    fiscalmonth = get_fiscal_month_of_month_x(datetime.now().month)

    for docheader in docheaders:
        tempdf = df[['Document Number', 'G/L Account', 'Document Header Text', 'Amount in Doc. Curr.', 'Amount in Local Currency', 'Local Currency']][df['Document Header Text'] == docheader]
        tempdf.reset_index(drop=True, inplace=True)

        doc_curr_sum = tempdf.loc[len(tempdf) - 1, ['Amount in Doc. Curr.']].values[0]
        loc_curr_sum = tempdf.loc[len(tempdf) - 1, ['Amount in Local Currency']].values[0]

        if doc_curr_sum == 0 and (loc_curr_sum <= 100 and loc_curr_sum >= -100):
            doc_num_list = tempdf['Document Number']
            tempdf.dropna(subset=['Document Number'], inplace=True)
            documentnumberlist = set(tempdf['Document Number'].values.tolist())

            for docnum in documentnumberlist:
                longstr += f"920002000\t{currentdate}\t{fiscalmonth}\t{tempdf['Local Currency'].values.tolist()[0]}\t{int(docnum)}\n"

    notepadpath = r'D:\Users\siswondo.siswondo\Downloads\clearingImport.txt'
    with open(notepadpath, 'w') as f:
        f.write(longstr)        
    
    time.sleep(3)
    
    newpath = r'\\adm-fs\ACC\ACC_BARU\RPA COST ACC\Data Download RPA\clearingImport.txt'
    shutil.copy(notepadpath, newpath)

def getDocHeaderTextOld(path):
    df = pd.read_excel(path)
    df.drop(df.tail(1).index,inplace=True)  #drop the last row
    df['Amount in Doc. Curr.'] = df['Amount in Doc. Curr.'].apply(lambda x: 0 if math.isnan(x) else x)
    df['Amount in Local Currency'] = df['Amount in Local Currency'].apply(lambda x: 0 if math.isnan(x) else x)
    print(df[['Document Number', 'Amount in Doc. Curr.', 'Amount in Local Currency']])

    docheaders = list(dict.fromkeys(df['Document Header Text'].values.tolist()))

    grand_document_number_list = []

    for docheader in docheaders:
        tempdf = df[df['Document Header Text'] == docheader]
        print(tempdf[['Document Header Text', 'Amount in Doc. Curr.', 'Amount in Local Currency']])
        
        amountlist = tempdf['Amount in Doc. Curr.'].values.tolist()
        amountinlocalcurrlist = tempdf['Amount in Local Currency'].values.tolist()

        if sum(amountlist) == 0 and (sum(amountinlocalcurrlist) <= 100 and sum(amountinlocalcurrlist) >= -100):
            print(docheader, sum(amountlist), sum(amountinlocalcurrlist))
            print('\n\n')

    #         docnumlist = list(dict.fromkeys(tempdf['Document Number'].values.tolist()))
    #         # docnumlist = tempdf['Document Number'].values.tolist()

    #         for x in docnumlist:
    #             print('docnum:', x)
    #             if not math.isnan(x):
    #                 print(int(x))
    #                 current_date = datetime.now().strftime('%d.%m.%Y')
    #                 currentmonth = datetime.now().month
    #                 templist = ['920002000', current_date, currentmonth, 'IDR']
    #                 templist.append(int(x))
    #                 grand_document_number_list.append(templist)

    # newdf = pd.DataFrame(grand_document_number_list, columns=['GL', 'TGL', 'Bln', 'Curr', 'Doc'])
    # print(newdf)
    
    # path = r'D:\Users\siswondo.siswondo\Downloads\clearingIntransit.xlsx'
    # newdf.to_excel(path, header=False, index=False)
    
    # return path