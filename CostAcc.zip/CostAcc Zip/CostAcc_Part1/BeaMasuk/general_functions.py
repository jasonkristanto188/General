import os
import time

def check_file_exists(filepath):
    while not os.path.isfile(filepath):
        time.sleep(1)

def check_substring_exists(substr, str):
    return True if substr in str else False