from datetime import datetime

def get_current_date_SAP():
    return datetime.now().strftime('%d.%m.%Y')

def get_current_date_yyyymmdd():
    return datetime.now().strftime('%Y%m%d')

def getMonthString(month):
    return f'0{month}' if int(month) < 10 else str(month)
 
def get_month_of_x_months_ago(x):
    pastXmonth = datetime.now().month - int(x)
    while pastXmonth <= 0:
        pastXmonth += 12
    return pastXmonth
 
def get_year_of_x_months_ago(x):
    pastXmonth = datetime.now().month - int(x)
    yearOfXMonthsAgo = datetime.now().year
    while pastXmonth <= 0:
        pastXmonth += 12
        yearOfXMonthsAgo -= 1
    return yearOfXMonthsAgo

def get_current_monthkey():
    return datetime.now().strftime('%Y%m')

def get_fiscal_month_of_month_x(x):
    return int(x) - 3 if int(x) >= 4 else int(x) + 9

def get_fiscal_year_of_month_x(x):
    return datetime.now().year if int(x) >= 4 else datetime.now().year - 1

def get_last_date_of_month_x(x):
    if int(x) == 2:
        return 29 if datetime.now().year % 4 == 0 else 28
    return 30 if int(x) in [4, 6, 9, 11] else 31
   
def get_first_date_of_prev_month():
    return f'01.{getMonthString(get_month_of_x_months_ago(1))}.{get_year_of_x_months_ago(1)}'
 
def get_last_date_of_prev_month():
    return f'{get_last_date_of_month_x(get_month_of_x_months_ago(1))}.{getMonthString(get_month_of_x_months_ago(1))}.{get_year_of_x_months_ago(1)}'
