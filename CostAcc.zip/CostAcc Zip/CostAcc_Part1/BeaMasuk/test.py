from clearing_bea_masuk import *

excelpath = r"D:\Users\jason.kristanto\Downloads\202404 BM.XLSX"
generate_txt(excelpath)
