from datetime_custom import *
import pandas as pd 
import numpy as np
import shutil
import time
import os

def check_file_exists(filepath):
    while not os.path.isfile(filepath):
        time.sleep(1)

def check_substring_exists(substr, str):
    return True if substr in str else False

def generate_pivot(excelpath):
    df = pd.read_excel(excelpath)
    df.columns = df.columns.str.strip()

    # Pivot the DataFrame
    pivot_df = pd.pivot_table(df, 
                            values='Amount in Local Currency', 
                            index=['Assignment'],   #row
                            columns=['Document Type'], 
                            aggfunc='sum')
    
    for index, row in pivot_df.iterrows():
        pivot_df.loc[index, 'Total'] = row['KX'] + row['WE']
        pivot_df.loc[index, 'Assignment'] = index
    pivot_df = pivot_df[(pivot_df['Total'] <= 100) & (pivot_df['Total'] >= -100)]
    pivot_df.reset_index(drop=True, inplace=True)

    #now get the necessary info only: G/L Account, Clearing Date, Fiscal Period, Local Currency, Document Number
    clearing_df = pd.merge(pivot_df, df[['Assignment', 'G/L Account', 'Local Currency', 'Document Number']], on='Assignment')
    clearing_df = clearing_df.drop_duplicates()
    clearing_df.reset_index(drop=True, inplace=True)
    
    clearing_df['G/L Account'] = clearing_df['G/L Account'].apply(lambda x: str(int(x)) if not pd.isna(x) else x)
    clearing_df['Document Number'] = clearing_df['Document Number'].apply(lambda x: str(int(x)) if not pd.isna(x) else x)
    clearing_df['Clearing Date'] = datetime.now().strftime('%d.%m.%Y')
    current_fiscal_month = datetime.now().month - 3
    if current_fiscal_month <= 0:
        current_fiscal_month += 12
    clearing_df['Fiscal Period'] = current_fiscal_month

    #generate the excel file
    clearing_df = clearing_df[['G/L Account', 'Assignment', 'Clearing Date', 'Fiscal Period', 'Local Currency', 'Document Number', 'KX', 'WE', 'Total']]
    xlsxpath = excelpath.replace('.xlsx', '_pivot.xlsx')
    clearing_df.to_excel(xlsxpath, index=False)

    check_file_exists(xlsxpath)

    return xlsxpath

def generate_txt_file(excelpath):
    txtdf = pd.read_excel(excelpath)
    txtdf = txtdf[['G/L Account', 'Clearing Date', 'Fiscal Period', 'Local Currency', 'Document Number']]
    txtdf = txtdf.drop_duplicates()
    txtpath = excelpath.replace('.xlsx', '.txt')
    txtdf.to_csv(txtpath, sep='\t', index=False, header=False)

    check_file_exists(txtpath)

    return txtpath

def get_assignment_numbers_for_clearing(excelpath):
    df = pd.read_excel(excelpath)
    return df['Assignment'].values.tolist()

def check_assignment_number(excelpath, assignment):
    df = pd.read_excel(excelpath)
    return True if assignment in df['Assignment'].values.tolist() else False

def get_doc_numbers_for_clearing(excelpath):
    df = pd.read_excel(excelpath)
    return df['Document Number'].unique()

def counter_check(counter):
    return True if counter % 10 == 0 else False

def inner_counter(counter):
    return counter % 10

def counter_check_for_process_items(counter):
    return True if counter > 0 and counter % 10 <= 9 else False
