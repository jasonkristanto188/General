import os
import sys

path = r'D:\Users\jason.kristanto\Desktop\RPA Quick Files'
sys.path.insert(1, path)

from creds import *
from datetime_custom import *
from general_functions import *



def get_excel_data(excelpath, sheetname):
    df = pd.read_excel(excelpath, sheet_name=sheetname)
    return df

def get_gl_account_list(gl_df):
    return gl_df['GL Account'].values.tolist()

def get_month_fullname(month):
    return datetime.strptime(str(month), '%m').strftime('%B')

def generate_F01_excel(df, excelpath):
    df.to_excel(excelpath, index=False)
    
    while not os.path.isfile(excelpath):
        pass

def create_df_from_2dlist(list_2d, collist):
    df = pd.DataFrame(list_2d)
    df.columns = collist
    return df

def process_excel(excelpath, temppath, pastmonthcolname):
    #used at the end of "Banding TB" keyword in "Analysis_FOH_Rendy.robot"

    #hasil download dri SAP
    maindf = pd.read_excel(excelpath)
    fullcollist = maindf.columns.tolist()

    # Downloaded data from SAP may have the month names cut, so we have to fix those names
    calendar = {
        'Short Name': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        'Full Name': ['January', 'February', 'March', 'April', 'May', 'June', 
        'July', 'August', 'September', 'October', 'November', 'December']
    }
    calendar_df = pd.DataFrame(calendar)

    for i, x in enumerate(fullcollist):
        if x[:3] in calendar_df['Short Name'].values.tolist():
            fullcollist[i] = calendar_df.loc[calendar_df['Short Name'] == x[:3], 'Full Name'].values[0]
    maindf.columns = fullcollist

    #split the dataframe into 2
    index = maindf.loc[maindf['Description'] == '***Total Depreciation'].index[0]
    df1 = maindf.loc[:index]
    df2 = maindf.loc[index + 1:]

    #hasil scrap dri SAP
    df = pd.read_excel(temppath)
    df[pastmonthcolname] = df[pastmonthcolname].apply(lambda x: int(str(x).strip().replace('.', '')) if not pd.isna(x) else x)
    df['Bus Area'] = df['Bus Area'].apply(lambda x: int(str(x).replace('0', '')) if not pd.isna(x) else x)

    sum = 0
    for index, row in df.iterrows():
        sum += int(row[pastmonthcolname])
    df.loc[len(df), pastmonthcolname] = sum
    df.loc[len(df) - 1, 'Description'] = 'Total'

    maindf = pd.concat([df1, df], ignore_index=True)
    maindf = pd.concat([maindf, df2], ignore_index=True)

    if 'YTD' in excelpath:
        fullcollist = maindf.columns
        collist = fullcollist[3:]
        for index, row in maindf.iterrows():
            sum = 0
            for col in collist:
                if col == pastmonthcolname:
                    sum += int(str(row[col]).replace('.', ''))
                elif not(row[col] == '' or pd.isna(row[col])):
                    sum += row[col]
            
            maindf.loc[index, 'Total'] = sum
            del sum
    
    excelpath = excelpath.replace('.xlsx', ' PROCESSED.xlsx')
    maindf.to_excel(excelpath, index=False)

    while not os.path.isfile(excelpath):
        pass

    return excelpath

def generate_sheet_data(prev_data_path, bulanan_df):
    #Goal: update sheet "Data"
    #
    #Steps:
    #1. copy data bulan -1 dan timpa di data bulan -2
    #2. copy data bulan skrng dan timpa di data bulan -1 
    #3. lakukan cek

    data_df = pd.read_excel(prev_data_path, sheet_name='Data')

    prev_month_df = data_df.iloc[:,4:8]

    #1a. get start and end index dari data bulan -1
    new_data_start_index = 0
    target_end_index = 0
    for index, row in prev_month_df.iterrows():
        if row['Unnamed: 6'] == 'Employee Compensation':
            new_data_start_index = index + 1
        
        if row['Unnamed: 6'] == 'Net Profit / Loss for the period':
            target_end_index = index + 2
            break

    #1b. get data bulan -1  
    data_to_be_copied = prev_month_df.iloc[new_data_start_index:target_end_index]
    data_to_be_copied.reset_index(drop=True, inplace=True)
    del prev_month_df, target_end_index

    #1c. get start row utk data bulan -2 (agar tau bisa ditimpa mulai dari row brp)
    original_start_index = 0
    for index, row in data_df.iterrows():
        if row['Unnamed: 2'] == 'Employee Compensation':
            original_start_index = index + 1
            break
    
    #1d. clear data bulan -2 (columns a - d)
    for index, row in data_df.iterrows():
        if index >= original_start_index:
            data_df.loc[index, 'Profit Loss'] = None
            data_df.loc[index, 'Unnamed: 1'] = None
            data_df.loc[index, 'Unnamed: 2'] = None
            data_df.loc[index, 'Unnamed: 3'] = None

    #1e. timpa ke data bulan -2 
    for index, row in data_to_be_copied.iterrows():
        data_df.loc[index + original_start_index, 'Profit Loss'] = row['Profit Loss.1']
        data_df.loc[index + original_start_index, 'Unnamed: 1'] = row['Unnamed: 5']
        data_df.loc[index + original_start_index, 'Unnamed: 2'] = row['Unnamed: 6']
        data_df.loc[index + original_start_index, 'Unnamed: 3'] = row['Unnamed: 7']
    
    #1f. update month key di area data lama
    data_df.iloc[3,3] = data_df.iloc[3,7]    #update monthkey (e.g. 2024 06 ---> 2024 07)
    # print(data_df.iloc[11:,4:8])

    #2a. clear data bulan -1 dari column e sampe h
    data_df_columns_e_to_h = data_df.columns.tolist()[4:8]
    for index, row in data_df.iterrows():
        if index >= new_data_start_index:
            for col in data_df_columns_e_to_h:
                data_df.loc[index, col] = None
    del data_df_columns_e_to_h

    #2b. timpa data bulan skrng ke data bulan -1
    for index, row in bulanan_df.iterrows():
        data_df.loc[index + new_data_start_index, 'Profit Loss.1'] = row['FS Item']
        data_df.loc[index + new_data_start_index, 'Unnamed: 5'] = row['Bus Area']
        data_df.loc[index + new_data_start_index, 'Unnamed: 6'] = row['Description']
        data_df.loc[index + new_data_start_index, 'Unnamed: 7'] = row[bulanan_df.columns[-1]]
    del bulanan_df
    
    #3a. clear data dari column j sampai end
    data_df_columns_j_to_end = data_df.columns.tolist()[8:]
    for index, row in data_df.iterrows():
        if index >= original_start_index:
            for col in data_df_columns_j_to_end:
                data_df.loc[index, col] = None
    del data_df_columns_j_to_end

    #3b. get data from sheet "Summary"
    summary_df = pd.read_excel(prev_data_path, sheet_name="Summary")
    summary_df = summary_df.iloc[6:,:]
    summary_df.reset_index(drop=True, inplace=True)
    descriptionlist = summary_df['Unnamed: 1'].values.tolist()

    for index, row in data_df.iterrows():
        if index >= original_start_index:
            if pd.isna(data_df.iloc[index, 1]):
                data_df.iloc[index, 9] = data_df.iloc[index, 2]
                data_df.iloc[index, 10] = None
            else:
                data_df.iloc[index, 9] = f"{data_df.iloc[index, 1]}{data_df.iloc[index, 2]}"

                if data_df.iloc[index, 2] in descriptionlist:
                    data_df.iloc[index, 10] = data_df.iloc[index, 2]
                else:
                    data_df.iloc[index, 10] = None

            if pd.isna(data_df.iloc[index, 5]):
                data_df.iloc[index, 12] = data_df.iloc[index, 6]
                data_df.iloc[index, 13] = None
            else:
                data_df.iloc[index, 12] = f"{data_df.iloc[index, 5]}{data_df.iloc[index, 6]}"

                if data_df.iloc[index, 6] in descriptionlist:
                    data_df.iloc[index, 13] = data_df.iloc[index, 2]
                    data_df.iloc[index, 17] = data_df.iloc[index, 2]
                else:
                    data_df.iloc[index, 13] = None
                    data_df.iloc[index, 17] = 'NOT FOUND'

    del summary_df, descriptionlist

    #4. save df
    collist = []
    for i in range(len(data_df.columns.tolist())):
        if i == 0 or i == 4:
            collist.append('Profit Loss')
        elif i == len(data_df.columns.tolist()) - 1:
            collist.append('END')
        else:
            collist.append('')
    data_df.columns = collist
    return data_df    



def get_pivot_bulanan_df(bulanan_path, pastmonthkey):
    bulanan_df = pd.read_excel(bulanan_path)
    bulanan_df = bulanan_df[~pd.isna(bulanan_df['Bus Area'])]
    bulanan_df['Bus Area'] = bulanan_df['Bus Area'].apply(lambda x: str(int(x)))
    bulanan_df.reset_index(drop=True, inplace=True)

    lastcol = bulanan_df.columns.tolist()[-1]
    bulanan_df[lastcol] = bulanan_df[lastcol].apply(lambda x: int(str(x).replace('.', '')))

    # bulanan_df = bulanan_df.pivot(index='Description', columns='Bus Area', values='July')
    bulanan_df = bulanan_df.pivot(index='Description', columns='Bus Area', values=lastcol)
    bulanan_df = bulanan_df.reset_index()

    for index, row in bulanan_df.iterrows():
        gl_account = row['Description'].split()[0]  #e.g. get 7110001001 from 7110001001 Employee Comp : salary
        bulanan_df.loc[index, 'Key'] = gl_account[:4]   #e.g. get 7110 from 7110001001
        bulanan_df.loc[index, 'GL Account'] = gl_account
        bulanan_df.loc[index, 'Description'] = row['Description'].replace(gl_account, '').strip()   #e.g. Employee Comp : salary

        sum = 0
        for col in [451, 452, 453, 454, 455]:
            if not pd.isna(row[str(col)]):
                sum += int(row[str(col)])
        bulanan_df.loc[index, f'Amount ({pastmonthkey})'] = sum
        del gl_account, sum

    #since 'Key' and 'GL Acc' are two new columns, rearrange them to the front of the column list
    columnlist = bulanan_df.columns.tolist()
    columnlist.remove('Key')
    columnlist.remove('GL Account')
    columnlist.insert(0, 'GL Account')
    columnlist.insert(0, 'Key')
    bulanan_df = bulanan_df[columnlist]

    return bulanan_df

def generate_sheet_data_YTD(prev_data_path, tahunan_df):
    #Goal: update sheet "Data YTD"
    #
    #Steps:

    data_df = pd.read_excel(prev_data_path, sheet_name='Data YTD')

    return data_df

    
def generate_excel_3(prev_data_path, bulanan_path, tahunan_path):
    bulanan_df = pd.read_excel(bulanan_path)
    tahunan_df = pd.read_excel(tahunan_path)

    #1. update sheet "data"
    data_df = generate_sheet_data(prev_data_path, bulanan_df)

    #2. update sheet "data YTD"
    data_YTD_df = generate_sheet_data_YTD(prev_data_path, tahunan_df)

    # result_excel_path = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Analysis FOH Rendy\Sample Data\Excel 3 - Copy.xlsx"
    # with pd.ExcelWriter(result_excel_path) as writer:
    #     data_df.to_excel(writer, sheet_name='Data', index=False)
    #     data_YTD_df.to_excel(writer, sheet_name='Data YTD', index=False)