import os
import sys
import pandas as pd
path = r'D:\Users\jason.kristanto\Desktop\RPA Quick Files'
sys.path.insert(1, path)
from datetime_custom import *


def generate_excel_files(pastmonth):
    prev_past_month = pastmonth - 1
    prev_past_month_str = get_month_string(prev_past_month)
    past_month_str = get_month_string(pastmonth)
    year_of_past_month = get_year_of_x_months_ago(pastmonth)
    year_of_prev_past_month = get_year_of_x_months_ago(prev_past_month)
    monthkey = f'{year_of_past_month}{past_month_str}'
    prev_monthkey = f'{year_of_prev_past_month}{prev_past_month_str}'

    maindirectory = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Analysis FOH Rendy"
    bulanan_path = rf"{maindirectory}\RPA Results\Profit or Loss 2024 {past_month_str}.xlsx"
    tahunan_path = rf"{maindirectory}\RPA Results\Profit or Loss 2024 {past_month_str} YTD.xlsx"
    new_bulanan_path = bulanan_path.replace('.xlsx', ' PROCESSED.xlsx')
    new_tahunan_path = tahunan_path.replace('.xlsx', ' PROCESSED.xlsx')

    prev_past_month_path = bulanan_path.replace(past_month_str, prev_past_month_str)
    prev_past_month_df = pd.read_excel(prev_past_month_path)

    past_month_df = pd.read_excel(new_bulanan_path)

    merged_df = pd.merge(prev_past_month_df, past_month_df, on=['FS Item', 'Bus Area', 'Description'], how='outer')
    print(merged_df)

    analysis_directory = os.path.join(maindirectory, 'Analysis FOH Results')
    filename = f"Analysis FOH {prev_monthkey}_{monthkey}.xlsx"
    filepath = os.path.join(analysis_directory, filename)
    merged_df.to_excel(filepath, index=False)

month_ago = 1
pastmonth = get_month_of_x_months_ago(month_ago)
generate_excel_files(pastmonth)