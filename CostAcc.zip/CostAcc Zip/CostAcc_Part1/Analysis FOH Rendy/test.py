from analysis_FOH_rendy import *

mainpath = r"D:\Users\jason.kristanto\Desktop\PROJECTS\AccountingRPA\CostAcc\Analysis FOH Rendy"
bulanan_path = rf"{mainpath}\RPA Results\Profit or Loss 2024 08.xlsx"
tahunan_path = rf"{mainpath}\RPA Results\Profit or Loss 2024 08 YTD.xlsx"
temp_bulanan_path = rf"{mainpath}\RPA Results\bulanan temp.xlsx"
temp_tahunan_path = rf"{mainpath}\RPA Results\tahunan temp.xlsx"

# new_bulanan_path = process_excel(bulanan_path, temp_bulanan_path, 'September')
# new_tahunan_path = process_excel(tahunan_path, temp_tahunan_path, 'September')

new_bulanan_path = bulanan_path.replace('.xlsx', ' PROCESSED.xlsx')
new_tahunan_path = tahunan_path.replace('.xlsx', ' PROCESSED.xlsx')
sample_excel_path = rf"{mainpath}\Sample Data\Excel 3.xlsx"
generate_excel_3(sample_excel_path, new_bulanan_path, new_tahunan_path)
# generate_sheet_summary_new(bulanan_path)